#!/usr/bin/env python3
"""
中国智算竞争格局周报HTML生成脚本 v3.1
- 基准骨架：../template/competition_skeleton.html（含{{占位符}}）
- 基准样式：../template/competition_template.css（纯CSS）
- 时间线/要闻表：按日期倒序（新到旧）排列
运行时读取骨架，注入CSS，填充本周数据，输出干净HTML
"""

import argparse
import json
import os
import re
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(__file__)
SKELETON_PATH = os.path.join(SCRIPT_DIR, "..", "template", "competition_skeleton.html")
CSS_PATH = os.path.join(SCRIPT_DIR, "..", "template", "competition_template.css")

# 读取纯CSS（文件本身已是纯CSS规则，不含HTML标签）
with open(CSS_PATH, "r", encoding="utf-8") as f:
    CSS_CONTENT = f.read()

# 读取骨架模板
with open(SKELETON_PATH, "r", encoding="utf-8") as f:
    SKELETON = f.read()


def build_data_cards(cards_data):
    """构建数据卡片组"""
    cards = []
    for card in cards_data:
        label = card.get("label", "")
        value = card.get("value", "—")
        unit = card.get("unit", "")
        change = card.get("change", "")
        tag_text = card.get("tag_text", "—")
        cards.append(
            f'<div class="data-card">\n'
            f'    <div class="label">{label}</div>\n'
            f'    <div class="value">{value}<span class="unit">{unit}</span></div>\n'
            f'    <div class="change">{tag_text} | {change}</div>\n'
            f'</div>'
        )
    return "\n".join(cards)


def build_market_table_rows(market_table):
    """构建周环比变化对比表行（tr.week-highlight 用于本周高亮行）"""
    rows = []
    for row in market_table:
        segment = row.get("segment", "")
        prev = row.get("prev", "—")
        curr = row.get("curr", "—")
        time_dim = row.get("time_dim", "周变化")
        change = row.get("change", "—")
        tag_class = row.get("tag_class", "change-flat")
        tag_text = row.get("tag_text", "—")
        analysis = row.get("analysis", "—")
        # 用 time_dim 内容决定是否加 week-highlight：包含"周变化"且无"暂无"则高亮
        is_week = "周变化" in time_dim and "暂无" not in analysis
        row_class = " class=\"week-highlight\"" if is_week else ""
        rows.append(
            f'<tr{row_class}>\n'
            f'    <td><strong>{segment}</strong></td>\n'
            f'    <td>{prev}</td>\n'
            f'    <td>{curr}</td>\n'
            f'    <td><span class="time-dim">{time_dim}</span></td>\n'
            f'    <td class="{tag_class}">{tag_text} {change}</td>\n'
            f'    <td>{analysis}</td>\n'
            f'</tr>'
        )
    return "\n".join(rows)


def build_timeline(timeline_data):
    """构建时间线（按日期倒序，新到旧）"""
    # 按日期字符串倒序排列（MM-DD格式，日期越新越靠前）
    sorted_data = sorted(timeline_data, key=lambda x: x.get("date", ""), reverse=True)
    items = []
    for item in sorted_data:
        date = item.get("date", "")
        title = item.get("title", "")
        source = item.get("source", "")
        impact = item.get("impact", item.get("content", ""))
        items.append(
            f'<div class="timeline-item">\n'
            f'    <div class="timeline-date">{date}</div>\n'
            f'    <div class="timeline-title">{title}</div>\n'
            f'    <div class="timeline-source">{source}</div>\n'
            f'    <div class="timeline-impact">{impact}</div>\n'
            f'</div>'
        )
    return "\n".join(items)


def build_news_table(news_items):
    """构建要闻汇总表（按日期倒序，新到旧；week-highlight 高亮重要度≥4星）"""
    # 按日期倒序排列（MM-DD格式，日期越新越靠前）
    sorted_items = sorted(news_items, key=lambda x: x.get("date", ""), reverse=True)
    header = (
        '<table>\n'
        '<thead>\n'
        '<tr>\n'
        '    <th>日期</th>\n'
        '    <th>事件</th>\n'
        '    <th>主体</th>\n'
        '    <th>规模/数据</th>\n'
        '    <th>重要度</th>\n'
        '</tr>\n'
        '</thead>\n'
        '<tbody>\n'
    )
    rows = []
    for item in sorted_items:
        importance = item.get("importance", 3)
        row_class = " class=\"week-highlight\"" if importance >= 4 else ""
        stars = "★" * importance
        rows.append(
            f'<tr{row_class}>\n'
            f'    <td>{item.get("date", "")}</td>\n'
            f'    <td>{item.get("event", "")}</td>\n'
            f'    <td>{item.get("subject", "")}</td>\n'
            f'    <td>{item.get("scale", "—")}</td>\n'
            f'    <td><span class="change-new">{stars}</span></td>\n'
            f'</tr>'
        )
    footer = '</tbody>\n</table>'
    return header + "\n".join(rows) + "\n" + footer


def build_sources(source_list):
    """构建来源标签"""
    tags = [f'<span class="source-tag">{s}</span>' for s in source_list]
    return "\n".join(tags)


def build_chapter_overview(overview_text):
    """构建本章关键概述卡片"""
    if not overview_text or overview_text.strip() == "":
        return ""
    return (
        '<div class="chapter-overview">\n'
        '<div class="overview-title">📋 本章关键概述</div>\n'
        '<div class="overview-text">\n'
        f'{overview_text}\n'
        '</div>\n'
        '</div>'
    )


def build_data_note(date_from, date):
    """构建数据说明条"""
    return (
        f'<strong>数据说明：</strong>本周报聚焦最近7天（{date_from}—{date}）竞争格局变化。数据均来自权威机构公开披露。<br>\n'
        '<strong>时间维度标注规则：</strong>\n'
        '<span class="time-dim" style="background:#c8e6c9;color:#1b5e20">周变化</span> = 本周内（≤7天）直接观测到的变化；\n'
        '<span class="time-dim" style="background:#fff9c4;color:#f57f17">月变化</span> = 最近一个月的数据对比；\n'
        '<span class="time-dim" style="background:#fce4ec;color:#c62828">季变化/年变化</span> = 季度或年度数据作为背景参考。'
    )


def main():
    parser = argparse.ArgumentParser(
        description="生成中国智算竞争格局周报HTML v3.1（骨架+CSS分离模式）"
    )
    parser.add_argument("--date", required=True, help="报告日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD（本周起始）")
    parser.add_argument("--week_number", default="第16期", help="周报期号")
    parser.add_argument("--data_cards_json", default="[]", help="数据卡片JSON")
    parser.add_argument("--market_table_json", default="[]", help="周对比数据JSON")
    parser.add_argument("--timeline_json", default="[]", help="时间线数据JSON")
    parser.add_argument("--news_json", default="[]", help="要闻JSON")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON")
    parser.add_argument("--chapter_overview", default="", help="本章关键概述文字（一段HTML）")
    parser.add_argument("--content_4_3", default="", help="4-3章节HTML（deep-event专题）")
    parser.add_argument("--content_4_4", default="", help="4-4章节HTML（芯片+图表）")
    parser.add_argument("--content_4_5", default="", help="4-5章节HTML（服务器+图表）")
    parser.add_argument("--content_4_6", default="", help="4-6章节HTML（云服务商）")
    parser.add_argument("--content_4_7", default="", help="4-7章节HTML（商业模式）")
    parser.add_argument("--output", required=True, help="输出HTML路径")
    args = parser.parse_args()

    # 解析JSON
    data_cards = json.loads(args.data_cards_json)
    market_table = json.loads(args.market_table_json)
    timeline_data = json.loads(args.timeline_json)
    news_items = json.loads(args.news_json)
    sources_list = json.loads(args.sources_json)

    # 以下字符串参数从子进程传入（含JSON编码），需反序列化
def decode_arg(s):
        """反序列化通过JSON编码传入的字符串参数；防御性清洗 \\n 两字符 + 残留外层引号

        LRN-20260821-001: subagent 误用 json.dump 写 HTML 内容文件，导致真换行 0x0A
        被 JSON 规范转义为 \\n 两字符；f.read() 读 JSON 文件时带入外层引号。
        decode_arg 防御性兜底：剥离外层引号 + 还原 \\n → 真实换行。
        """
        if not s:
            return ""
        try:
            result = json.loads(s)
        except Exception:
            result = s

        # 防御性清洗：消除 JSON 残留转义
        if isinstance(result, str):
            # 1. 剥离首尾多余引号（subagent 用 f.read() 读 JSON 文件时带入）
            if result.startswith('"') and result.endswith('"'):
                inner = result[1:-1]
                # 内部引号成对（偶数）才剥离
                if inner.count('\\"') % 2 == 0 and inner.count('"') % 2 == 0:
                    result = inner
            # 2. JSON 字符串内的 \\n 转义（两字符）→ 真实换行
            result = result.replace('\\n', '\n')

        return result
if __name__ == "__main__":
    main()
