# 官方渠道链接清单（广东智算中心建设数据源）

> ⚠️ **使用本技能时必须优先从此清单定向采集招标/中标/备案数据**，禁止泛关键词搜索自媒体、营销号。
> 本清单持续维护：发现新的有效官方渠道请补充，失效链接请更新后记录日期。

---

## 一、国家级平台

| 渠道 | 域名 | 主要入口/列表页 | 采集内容 |
|------|------|----------------|----------|
| **中国政府采购网** | `www.ccgp.gov.cn` | 采购公告：`www.ccgp.gov.cn/cggg/dfgg/`（地方）/ `zygg/`（中央） | 政府采购招标公告、中标（成交）公告 |
| **中国招标投标公共服务平台** | `www.cebpubservice.com` | 招标公告 / 中标公示 | 工程建设项目招标、中标公告 |
| **全国公共资源交易平台** | `www.ggzy.gov.cn` | 交易信息 | 全国公共资源交易公告（含广东） |

## 二、省级平台

| 渠道 | 域名 | 主要入口/列表页 | 采集内容 |
|------|------|----------------|----------|
| **广东政府采购智慧云平台** | `gdgpo.czt.gd.gov.cn` | 项目采购公告（省级 / 市级 / 县区级） | 广东政府采购招标、中标（成交）、更正公告 |
| **广东省公共资源交易平台** | `ggzy.gd.gov.cn` | 交易公开（可按城市切换至韶关等市） | 广东公共资源交易招标/中标公告 |

## 三、市级平台（重点城市）

> **LRN-20260821-004 更新**：标记每个市级平台的 **sandbox 网络可达性**。sandbox 不可访问的渠道需用 **Tavily 兑底**（Tavily 能搜到公网存在的链接）。

| 渠道 | 域名 | sandbox 状态 | 采集方式 | 主要入口 |
|------|------|---------------|----------|----------|
| **广州交易集团** | `www.gzexgrp.com` | ⚠️ 部分（首页可访问，招投标链接指向 gzggzy.cn） | curl + gzggzy.cn 跳转 | 建设工程交易 / 政府采购 |
| **广州公共资源交易中心（gzggzy.cn）** | `www.gzggzy.cn` / `gf.gzggzy.cn` / `jsgc.gzggzy.cn` | ✅ 可访问 | **curl 拿 PDF（100KB-1.4MB）/ HTML** | `/gz2/M00/.../xxx.pdf?fileId=xxx`（PDF公告） |
| **广州公共资源采购平台** | `www.gzmall.cn` | ✅ 可访问（Vue SPA） | curl 拿 HTML（需 JS 渲染后才有数据） | 招采公告 |
| **深圳公共资源交易中心（szggzy.com）** | `www.szggzy.com` | ✅ 可访问（stealthy 拿到 SPA） | curl 拿 HTML（395B SPA 占位页） | SPA `/dzzbtbjyxt/` `/jygg/details.html?contentId=xxx` |
| **深圳政府采购（zfcg.szggzy.com）** | `zfcg.szggzy.com:8081` / `:8084` | ✅ 可访问 | **curl 拿 HTML（3-148KB）** | `/gsgg/002001/.../xxx.html` |
| **韶关市公共资源交易一体化平台** | `portal.ythpt.sg.gov.cn` | ✅ 可访问 | **Playwright 长 wait（15-20s）拿 detail 页（4000-5000 字符）；curl 拿 PDF（1.4MB）** | `/detail?firstTab=06&category=Ggwz&id=xxx`（HTML）<br>`/api/common/download?domain=Ggwzfj&id=xxx`（PDF） |
| **惠州市公共资源交易中心** | `zyjy.huizhou.gov.cn` | ✅ 可访问 | **curl 拿 HTML（8-12KB 真实公告）** | `/ggfw/zbjh/.../post_xxx.html` |
| **佛山市公共资源交易中心** | `ggzy.foshan.gov.cn` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |
| **东莞市公共资源交易中心** | `dggzy.dg.gov.cn` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |
| **中山市公共资源交易中心** | `ggzy.zs.gov.cn` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |
| **江门市公共资源交易中心** | `ggzy.jiangmen.gov.cn` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |
| **肇庆市公共资源交易中心** | `zqggzy.com` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |
| **珠海市公共资源交易中心** | `ggzy.zhuhai.gov.cn` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |
| **汕头市公共资源交易中心** | `ggzy.shantou.gov.cn` | ❌ sandbox DNS 不解析 | Tavily 兑底 | 交易信息 |

**sandbox 网络层限制根因**：sandbox DNS 拦截部分 .gov.cn 域名的 A 记录查询。公网上这些平台均可用。

**🎯 sandbox 可访问的 4 个市级平台**（按 LRN-20260821-004 实测）：
1. **韶关 portal.ythpt.sg.gov.cn** —— Playwright 长 wait 拿到 detail 页 + PDF
2. **惠州 zyjy.huizhou.gov.cn** —— curl 拿 HTML
3. **广州 gzggzy.cn** —— curl 拿 PDF（推荐使用）
4. **深圳 zfcg.szggzy.com** —— curl 拿 HTML

**生产脚本**：`gov_query.py`（统一调用 4 个 sandbox 可访问平台 + Tavily 兜底）。

## 三-b 运营商采购平台（智算中心基建招标主渠道，必采）

> ⚠️ **关键：电信/移动/联通的数据中心基建招标（土建EPC、机电、外电、监理等）主要发布在各自的采购与招标网**，不在政府采购网上。之前检索漏掉大量项目的根因即未覆盖此渠道。**每次生成必须采集。**

| 渠道 | 域名 | 采集内容 |
|------|------|----------|
| **中国电信阳光采购网** | `caigou.chinatelecom.com.cn` | 中国电信土建EPC/机电/监理招标公告、中标公示（如韶关数据中心2.x期） |
| **中国移动采购与招标网** | `b2b.10086.cn` | 中国移动数据中心、机电、外电、集采招标公告（如惠州数据中心一期） |
| **中国联通采购与招标网** | `ecp.chinaunicom.cn` | 中国联通智算/数据中心采购公告 |

## 三-c 招标公告聚合平台（"各招标公告发布平台"，补充采集）

> 聚合平台转发运营商/央国企/政采的官方公告，可快速覆盖遗漏项；**命中条目仍需回溯原始官方公告核验**。

| 渠道 | 域名 | 说明 |
|------|------|------|
| **今日招标网** | `jrzb.com`（含 `sh.jrzb.com`、`shenzhen.jrzb.com` 等城市分站） | 抓取运营商/政采招标原文，含项目详情 |
| **乙方宝** | `yfbzb.com` | 广东各市招标分类（韶关/广州/深圳/惠州…），含电信/移动/联通分类 |
| **千里马招标网** | `qianlima.com` | 全国招标聚合 |
| **比地招标网** | `bidizhaobiao.com` | 全国招标聚合 |

## 四、信息核验

| 渠道 | 域名 | 用途 |
|------|------|------|
| **天眼查** | `www.tianyancha.com` | 备案信息、项目/企业信息核验 |

---

## 定向采集方式（scrapling 优先，替代 tavily）

> ⚠️ **采集优先级**：智算中心**基建类招标（土建EPC/机电/外电/监理）主要在运营商采购平台**（电信、移动、联通）及聚合平台（今日招标/乙方宝等）发布；**政府采购网/政采云主要覆盖政府采购类**（设备、算力、运维、规划咨询）。两类都要采集，基建类优先查运营商渠道。

**采集工具 = `scrapling-fetch` 技能**（Playwright 驱动，能抓 JS 渲染页 + 运营商采购网交互搜索）。

1. **运营商采购网交互搜索（首选，拿 tavily 搜不到的公告）**：`scrapling-fetch/scripts/operator_search.py` 对三大运营商采购网搜索 `算力中心`/`智算中心`/`数据中心`，自动填关键词+选广东+设时间窗+点查询：
   - 中国电信 `caigou.chinatelecom.com.cn/search?search=`（省份填"广东"）
   - 中国移动 `b2b.10086.cn/#/biddingProcurementBulletin`（省分选"广东"）
   - 中国联通 `www.chinaunicombidding.cn/bidInformation`（发布单位"广东分公司"）
   - ⚠️ 结果含**全国**公告，**必须过滤广东/韶关条目**
   - 实测(2026-08)：能提取电信韶关2.2期A3A4智算中心全过程咨询、移动广东韶关浈江横三路数据中心一期变电站、联通韶关数据中心4机电新建3个EPC
2. **乙方宝搜索页（捞政采云类小项目）**：`scrape.py "https://www.yfbzb.com/search/invitedBidSearch?defaultSearch=true&keyword=<关键词>&provinceId=5" --mode dynamic`。关键词换着搜：智算中心/算力中心/数据中心/机房改造/算力租赁/安全监管/征地。
3. **详情页抓正文**：命中公告 URL 用 `scrape.py <url> --mode dynamic --output text`。
4. **tavily 仅兜底**：仅当 scrapling 无法访问某站点时才用 `tavily_search` + `include_domains`。
5. **回溯原文**：每条数据必须能回溯到官方公告原文链接，来源标注**渠道名 + 日期**。
6. **去重与口径**：同一项目在多个渠道出现（如招标、中标分阶段）时合并为一条，按最新阶段更新；备案投资与中标金额分别标注口径。

## 检索关键词模板（每渠道）

```
"智算中心 招标公告 {CURRENT_YEAR}年{CURRENT_MONTH}"
"数据中心 中标公示 {CURRENT_YEAR}年{CURRENT_MONTH}"
"算力中心 备案 {CURRENT_YEAR}年{CURRENT_MONTH}"
"韶关 数据中心 土建EPC 招标"
"机电工程 招标 中标"
"智算中心 征地 用地"
```

> 注意：官方平台列表页常为 JS 渲染或需登录，若 `tavily_extract` 抓不到结构数据，回退为 `include_domains` 限定搜索；若某渠道连续两周无法采集，记录后改用其他官方渠道，不得用非官方来源替代。
