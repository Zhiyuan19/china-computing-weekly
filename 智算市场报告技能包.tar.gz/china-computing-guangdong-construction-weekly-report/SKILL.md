---
name: china-computing-guangdong-construction-weekly-report
description: 生成中国智能算力报告第八章（广东智算中心建设）周更/月更报告。当用户要求生成广东智算中心建设、智算中心招标、数据中心征地/土建/机电工程、韶关数据中心集群建设、城市智算中心项目进度周报/月报时自动调用。触发场景：(1) 用户要求生成广东智算中心建设报告；(2) 用户要求生成第八章建设周报；(3) 用户提到广东招标、征地、土建、机电工程、数据中心建设规模、智算中心项目落地等关键词。
metadata:
  clawdbot:
    emoji: 🏗️
    requires:
      anyBins:
        - python3
---

> ⚠️ **本 skill 的所有命令假设工作目录为 `~/.openclaw/workspace/`**（即 openclaw workspace 根目录）。如从其他目录运行，请先 `cd ~/.openclaw/workspace`。

# SKILL.md — 中国智算广东智算中心建设周报生成技能

## 核心定位

本技能生成中国智能算力报告**第八章：广东智算中心建设**的周更/月更HTML报告，聚焦广东省（韶关、广州、深圳、惠州、佛山、肇庆等城市）智算中心的**建设规模与工程进度**，覆盖**征地/用地、土建工程、机电工程**三个建设阶段，以及各城市重点项目的招标、备案、开工、投产动态。

**数据组织方式：** 报告采用"**招标/中标/备案信息表（按日期倒序）→ 按城市汇总 → 按招标类型汇总**"的层级结构组织建设数据。**所有招标/中标/备案数据必须来自官方渠道**（中国政府采购网、广东省政府采购中心、全国公共资源交易平台、天眼查、各招标公告发布平台等），禁止使用非官方来源。

**周更/月更双轨：** 报告支持周维度（近7天建设动态）与月维度（近30天累计建设规模）两种数据粒度，统一用时间维度标签（周变化/月变化/季变化/年变化/持续）标注，禁止混淆。

---

## ⚠️ 绝对禁令（强制）

以下行为**严禁**，违者报告视为不合格：
1. **禁用历史检索词**：不得使用过期月份作为检索词
2. **禁用模板数据**：不得从v_latest等模板文件复制数据直接填入
3. **禁用过时数据**：不得将2025年数据标为"本周"或"周变化（本周）"
4. **禁用跳过检索**：检索结果<3条时不得继续生成，必须扩展检索词
5. **禁用虚构项目**：不得编造不存在的招标项目、金额、日期；所有项目必须来自真实检索/数据源
6. **禁用口径混淆**：备案投资额（计划总投资）与中标金额（实际招标价）必须区分标注，禁止混为一谈
7. **禁用非官方来源**：招标/中标/备案数据必须来自中国政府采购网、广东省政府采购中心、全国公共资源交易平台、天眼查、各市公共资源交易中心等官方/权威渠道，禁止使用自媒体、营销号作为数据来源

---

## ⚠️ 文件写入策略（必须遵守）

**模型输出流截断阈值约1027字符**，超过后工具调用参数不完整。**禁止直接生成大段HTML作为write参数**，会因截断导致文件不完整。

**必须采用两阶段模式：**
```text
子agent步骤：
  1. write → /tmp/report_args.json（数据JSON，小文件<10KB，不会截断）
  2. write → /tmp/content_8_1.html 等（HTML片段，每个2-3KB，不会截断）
  3. exec → python3 scripts/generate_weekly_report.py（读取小文件→脚本生成完整HTML）
  4. 验证输出文件 > 20KB
```

**核心规则：** 写文件的是Python脚本，不是模型输出流。模型只负责写小文件+调用脚本。

**⚠️ 写入协议一致性（强制）：** JSON数据文件用 `json.dump()` 写 + `json.load()` 读；HTML内容文件用 `f.write()` 写纯文本 + `f.read()` 读。**禁止**对内容字符串再次 `json.dumps()` 编码后传参。
**⚠️ 防御性清洗（硬约束，LRN-20260821-001）：**

1. **HTML 内容文件严禁使用 `json.dump()` 写入** —— 会导致真实换行 0x0A 被 JSON 规范转义为 `\n` 两字符（JSON 字符串内转义）；后续通过 `f.read()` 读取后传入脚本会注入转义符
2. **禁止用 `f.read()` 读取 JSON 文件作为 `--content_X` 参数** —— JSON 文件首尾自带外层引号（`"..."`），`f.read()` 会带入；脚本 `decode_arg` 已升级兜底
3. **HTML 内容写入前必须自检**：
   ```bash
   grep -c '\\n' /tmp/content_*.html  # 真实合法 \\n 数为 0（必须用 <br> 标签代替）
   head -c 1 /tmp/content_*.html | grep -c '"'  # 首字符不为 "（0 = 正确）
   ```
4. **脚本 `decode_arg` 防御性兜底**（已升级，LRN-20260821-001）：自动剥离首尾多余引号 + 把 `\n` 两字符还原为真实换行。即便 subagent 错误使用 `json.dump` 写入，依然不污染 HTML


---

## 模板文件
报告为完整智算报告的第八章，章节编号从 **8-1、8-2…** 开始。
**周更/月更要求**：优先使用最新一周（≤7天）建设动态，若一周内无新动态则回退到月变化（≤30天）、季变化或年变化，但**必须明确标注时间维度**，禁止将非周变化数据误标为"本周"。

---

## 模板文件说明

**重要**：本章HTML样式与第六章（供应商与产业格局）一致，共用同一套CSS体系。

- **模板CSS参考**：`template/guangdong_template.html`（仅含CSS，供脚本提取）
- **骨架模板**：`template/guangdong_skeleton.html`（含占位符的报告外壳）
- **参考数据文件**：`广东智算中心招标信息2026.pdf` 等（⚠️ 仅供数据口径参考，必须重新检索本周/本月最新数据）

生成时通过脚本读取骨架，注入CSS，填充数据，输出干净HTML。

⚠️ **骨架结构说明**：8-1 至 8-6 各小节标题固定写在骨架中（如 `8-1 广东智算中心建设总体态势`），**所有小节内部的小标题与内容（含 `8-1-1 建设规模总览`）均由内容文件（`content_8_1`~`content_8_6`）直接提供**，骨架不再写死任何表格。内容文件应以 `<h4>8-1-1 …</h4>`、`<h4>8-1-2 …</h4>` 的层级组织（8-1 用 h4 起始），与 8-2~8-6 一致。

---

## 时间维度标注规则（强制）

时间维度分四档，颜色区分：

| 时间维度 | 颜色 | 样式 | 适用场景 |
|----------|------|------|----------|
| **周变化（≤7天）** | 绿色背景 | `<span class="time-dim" style="background:#c8e6c9;color:#1b5e20">周变化（本周）</span>` | 本周有明确招标/中标/开工/投产事件 |
| **月变化（8-30天）** | 黄色背景 | `<span class="time-dim" style="background:#fff9c4;color:#f57f17">月变化</span>` | 本月有项目备案/招标/建设进展 |
| **季变化/年变化** | 灰色背景 | `<span class="time-dim">季变化</span>` 或 `<span class="time-dim">年变化</span>` | 季度或年度统计数据，无周/月数据时使用 |
| **持续/无直接数据** | 白色背景 | `<span class="time-dim">持续</span>` | 长期建设规划无明确时间切点 |

**规则：**
1. 有本周新动态（招标公告、中标公示、开工、投产） → 标注"周变化（本周）"（绿色）
2. 无本周数据但有月度内新事件 → 标注"月变化"（黄色）
3. 季度/年度累计建设数据 → 标注"季变化"或"年变化"（灰色）
4. **严禁**将季度/年化数据标为"周环比"或"本周"
5. 每个表格**必须包含"时间维度"列"

---

## 输出规范

- **输出路径**：`report/广东智算中心建设分析报告.html`
- **报告命名**：`广东智算中心建设分析报告.html`
- **格式**：HTML，响应式布局
- **章节编号**：8-1、8-2、8-3、8-4、8-5、8-6（8-6为本周/本月建设深度分析专题）
- **文件大小**：>25KB（含完整内容）

---

## ✍️ 写作铁律（全章节通用：关键概述 / 8-1~8-6 / analysis-box）

✅ **用自然语句，编号只是辅助**：
> ① 8月7日中国电信粤港澳大湾区一体化数据中心2.2期EPC总承包开标，总建筑面积约7.31万㎡，工期297天，位于韶关浈江产业园智算中心集群。

❌ **禁机械堆叠**（任一即不合格）：
- 4个以上短语用 `+` 串联（如 `电信+移动+腾讯+万国数据`）
- 一段内连用 3 个以上 `/` 串联同类项（如 `EPC/土建/机电/设备`）
- 5个以上 `①②③④⑤` 编号堆叠且每条 < 15 字
- 整段几乎都是"括号+简写"无完整主谓宾

**判定标准：** 朗读出来像人话。破折号 `——` 可保留作解释，但每段必须至少一句完整的主谓宾。

---

## 报告结构

```text
8-1  广东智算中心建设总体态势
  - 本周/本月建设要闻速览（数据卡片）
  - 关键发现（从信息表提炼的要点：城市热点/规模/趋势）

8-2  招标/中标/备案信息表（按日期倒序）
  - 全量项目表：序号/项目名称/招标/业主单位/类型/金额/日期/城市/项目规模与备注（**不设时间维度列**）
  - 按日期倒序（新→旧）排列；备案项目标注"备案口径"（计划总投资），中标项目标注中标金额
  - 日期列使用完整日期 YYYY-MM-DD（如 2026-08-07）
  - ⚠️ **项目规模与备注列必须详尽**：不能只写"招标公告"这类标题复述，须写出项目的规模/内容实质（建筑面积、机柜数、算力规模、投资额、EPC范围、工期、中标人等可从采集结果提取的信息），缺信息时标注"未公示"。示例见下。
  - ⚠️ **表末深度分析必须按运营商/来源分点**（不是一段笼统描述），逐家分析各主体的智算中心建设情况。分点模板见下「8-2 深度分析分点规范」。

8-3  按城市汇总
  - 韶关/广州/深圳/惠州/佛山/肇庆 各城市项目数量、主要类型、代表项目

8-4  按招标类型汇总
  - EPC总承包/机电及施工总承包/设备采购/新建备案/规划研究/算力服务
  - 各类型项目数量与金额范围

8-5  征地、土建、机电工程分类动态
  - 征地/用地动态（地块面积/用途/批复）
  - 土建工程招标（EPC/施工，金额/工期/中标人）
  - 机电工程招标（外电/配电/暖通等）

8-6  本周/本月建设深度分析专题
  - 本周最具影响力的建设动态深度剖析
  - 建设规模、投资结构、工期节奏综合分析
```

---

## 数据获取流程

### 第零步：官方渠道采集（scrapling 直抓优先，替代 tavily）

**所有招标/中标/备案数据必须从官方渠道采集**，禁止用自媒体/营销号。**采集工具 = `scrapling-fetch` 技能**（Playwright 驱动，能抓 JS 渲染页 + 运营商采购网交互搜索）。

**三大平台 v2 升级（LRN-20260821-002）**：

| 平台 | 默认抓取模式 | WAF / SSL 风险 |
|------|---------------|---------------|
| 电信 caigou | Playwright headless | 阿里云 WAF + JS Challenge（暂待升级）|
| 移动 b2b | **API 模式**（Playwright + 浏览器内 fetch ES API）| OpenSSL 3.x 禁用 legacy renegotiation（用 Chromium BoringSSL 绕过）|
| 联通 chinaunicombidding | **StealthyFetcher 模式**（xvfb-run + headless=False）| SafeLine WAF + 412 TLS Challenge |

**1. 三大运营商采购网抓取（首选，`operator_search.py` v2）：**

```bash
# 默认 30 天 + 广东 + 智算中心 + 三平台一起
python3 skills/scrapling-fetch/scripts/operator_search.py --keyword "智算中心" --platform all --days 30

# 单独跑移动（API 模式，绕过 SSL + 获得丰富数据）
python3 skills/scrapling-fetch/scripts/operator_search.py --platform mobile --keyword "数据中心" --region 广东 --days 30

# 单独跑联通（StealthyFetcher 模式，绕过 SafeLine WAF）
python3 skills/scrapling-fetch/scripts/operator_search.py --platform unicom --keyword "数据中心" --region 广东 --days 30
```

**关键设计（v2）**：
- 默认参数：区域=广东（覆盖全省 21 地级市 + 关键园区）/天数=30（周报月报统一）/关键词=智算中心
- **广东后置过滤**：API 不支持 companyName 过滤，Python 端按 `companyTypeName` 字段过滤
- **API endpoint（移动）**：`POST https://b2b.10086.cn/api-b2b/api-sync-es/white_list_api/b2b/publish/queryList`
- **StealthyFetcher（联通）**：通过 xvfb-run + scrape.py --mode stealthy 间接调用，绕过 patchright 的 asyncio loop 限制

**2. 乙方宝搜索页（curl 版，`yfbzb_query.py` v2.1，**避免 Playwright 与 sandbox NAT 冲突**）：**

```bash
# 默认 30 天 + 广东 + 5 个关键词（排除“安全监管”“征地”易触发 SafeLine WAF）
python3 skills/scrapling-fetch/scripts/yfbzb_query.py --days 30
```

**优势（vs Playwright/Chromium）**：
- 100% 稳定 HTTP 200（连续 6 次测试都成功）
- 不触发 `net::ERR_NETWORK_CHANGED`（sandbox NAT 网络冲突）
- 不触发 SafeLine WAF 浏览器指纹检测

**v2.1 升级（LRN-20260821-004）**：
- 加 WAF 检测 + 指数退避（30s→60s→120s）
- 字段错位修复（name/notice_type/region 列顺序修正）
- SafeLine WAF 频率限制冷却后自动重试

⚠️ **乙方宝 SafeLine WAF 限制**：高频访问会触发长频率封禁（15-30 分钟）。建议每周使用频率 ≤ 2-3 次。

**⑤ Tavily 兜底（v2，重要）**：
- 实体面站不可访问时（sandbox 网络层拦截部分 .gov.cn 域名 DNS），用 Tavily 找链接 + 提取正文
- 適用场景：sandbox 不可访问的全国/省级/其他地级市平台（如 ccgp.gov.cn / ggzy.gov.cn / ggzy.foshan.gov.cn 等）
- 实现：见 `gov_query.py` 自动使用 Tavily + sandbox 可访问平台的 Playwright/curl 混合策略

**3. 广东省其他地级市公共资源平台（`gov_query.py` v1，**LRN-20260821-004 新增**）**：

```bash
# 默认 30 天 + 广东 + 智算中心（同时用 sandbox 可访问渠道 + Tavily 兜底）
python3 skills/scrapling-fetch/scripts/gov_query.py --days 30

# 周报模式
python3 skills/scrapling-fetch/scripts/gov_query.py --days 7

# 关闭 Tavily 兜底（仅用 sandbox 可访问平台）
python3 skills/scrapling-fetch/scripts/gov_query.py --no-tavily

# JSON 输出
python3 skills/scrapling-fetch/scripts/gov_query.py --output /tmp/gov_result.json
```

**覆盖渠道（sandbox 可访问 + Tavily 兑底）**：

| 平台 | sandbox 状态 | 抓取方式 |
|---|---|---|
| 韶关 `portal.ythpt.sg.gov.cn` | ✅ 可访问 | Playwright + networkidle + 15-20s wait |
| 韶关 `/api/common/download?domain=xxx&id=xxx` | ✅ | curl 直接拿 PDF（100KB-1.4MB） |
| 惠州 `zyjy.huizhou.gov.cn` | ✅ | curl 直接拿 HTML（8-12KB） |
| 广州 `gzggzy.cn`（gf.gzggzy.cn / jsgc.gzggzy.cn）| ✅ | curl 拿 PDF（100KB-1.4MB） |
| 深圳 `zfcg.szggzy.com:8081` / `8084` | ✅ | curl 拿 HTML（3-148KB） |

**sandbox 不可访问（需要 Tavily 兑底）**：
- `ggzy.gov.cn` / `ccgp.gov.cn` / `ggzy.gd.gov.cn` / `gdgpo.czt.gd.gov.cn` / `ggzy.foshan.gov.cn` / `zqggzy.com` / `ygyp.gdzwfw.gov.cn`（部分 .gov.cn 域名 DNS 被 sandbox 防火墙拦截）

**实测样本（LRN-20260821-004 验证）**：
- 韶关：北江智算中心（机电）项目 25000万元（2026-05-13）✅
- 韶关：粤港澳大湾区算力枢纽一体化安全 26000万元（2024-06-07）✅
- 惠州：粤港澳大湾区（惠州）数据产业园市政基础设施二期 ✅
- 广州：广东省交通集团主数据中心 IDC + 云平台 多 PDF ✅
- 深圳：南山区政务算力服务（公告/更正/合同）✅

**③ 具体公告详情页**：拿到 URL 后用 `scrape.py <url> --mode dynamic --output text` 抓正文（运营商采购网/乙方宝）或 Playwright 长 wait 渲染（韶关 portal）。

**④ 回溯与去重**：每条数据回溯到官方原文，来源标注**渠道名+日期**；同一项目招标/中标/备案分阶段合并，按最新阶段更新。

**⑤ tavily 仅兜底**：仅当 scrapling 无法访问某站点时，才用 `tavily_search` + `include_domains`。

**渠道清单（详见 `references/official_channels.md`）：**
- ⚠️ **运营商采购平台（智算中心基建招标主渠道，必采）**：中国电信阳光采购网 `caigou.chinatelecom.com.cn/search`、中国移动采购与招标网 `b2b.10086.cn/#/biddingProcurementBulletin`、中国联通采购与招标网 `www.chinaunicombidding.cn/bidInformation`
- 招标公告聚合平台：乙方宝 `yfbzb.com`、今日招标网 `jrzb.com`、千里马 `qianlima.com`、比地 `bidizhaobiao.com`
- 国家级：中国政府采购网 `ccgp.gov.cn`、全国公共资源交易平台 `ggzy.gov.cn`
- 省级：广东政府采购智慧云平台 `gdgpo.czt.gd.gov.cn`、广东省公共资源交易平台 `ggzy.gd.gov.cn`
- 市级：深圳 `szggzy.com`、广州 `gzexgrp.com`、韶关 `portal.ythpt.sg.gov.cn`、惠州 `zyjy.huizhou.gov.cn`、佛山、肇庆
- 核验：天眼查 `tianyancha.com`

### 第一步：用 scrapling 检索广东智算中心建设动态

**跑 scrapling 采集（替代旧 tavily 六路检索）：**

1. **运营商采购网**：`operator_search.py --platform all --days 30`（移动 API 模式 + 联通 StealthyFetcher 模式 + 电信 Playwright 默认模式）
2. **乙方宝搜索页**：`yfbzb_query.py --days 30`（curl 版，避 Playwright sandbox NAT 冲突；注意 SafeLine WAF 频率限制）
3. **广东省其他地级市**：`gov_query.py --days 30`（韶关 portal + 惠州 zyjy + 广州 gzggzy + 深圳 zfcg + Tavily 兑底）
4. **详情页补全**：对命中的公告 URL 用 `scrape.py --mode dynamic` 展开取金额、业主、工期等字段
5. **渠道清单兑底**：对运营商/乙方宝/政府平台未覆盖的（如备案、征地），用 `official_channels.md` 列出的其他公共资源/政采渠道补充

### 第二步：补充月/季度数据（当本周数据不足时）

如果本周检索结果不足（<3条有效记录），**禁止跳过本周直接用上月数据**，必须按以下顺序逐层回退：

1. **本周（≤7天）**：优先使用，标注<span style="background:#c8e6c9;color:#1b5e20">周变化（本周）</span>
2. **本月上旬（1-15日）**：有则用，标注<span style="background:#fff9c4;color:#f57f17">月变化</span>
3. **上月下旬（16-31日）**：有则用，标注<span style="background:#fff9c4;color:#f57f17">月变化</span>
4. **季度/年度数据**：最后手段，标注<span style="background:#e0e0e0;color:#555">季变化</span>或<span style="background:#e0e0e0;color:#555">年变化</span>

**⚠️ 严禁行为：**
- 不得将季度/年报数据标为"周变化（本周）"
- 不得在检索结果<3条的情况下继续生成报告
- 不得使用历史月份作为检索词
- 不得从模板/历史PDF文件复制数据直接填入（历史数据仅作口径参考）
- 不得将备案计划投资额标注为中标金额，必须区分标注

### 第三步：数据整合与时间维度标注（强制）

#### 时间维度判断决策树

**第一步：问自己——这条数据描述的是什么事件/变化？**

| 数据类型 | 判断标准 | 标注 |
|---------|---------|------|
| **本周内发生的招标公告/中标公示/开工/投产** | 数据本身就描述本周发生的事 | `周变化（本周）`（绿色） |
| **本周之前但属于本月内的项目动态** | 数据描述的事件在本月上中旬 | `月变化`（黄色） |
| **上月整月的数据/事件** | 数据描述的事件在上月 | `月变化`（黄色） |
| **季度粒度数据** | 数据来自季度统计/累计 | `季变化`（灰色） |
| **年度建设规划/年累计数据** | 数据来自年度计划/年度统计 | `年变化`（灰色） |
| **无明确时间节点的长期建设规划** | 数据描述持续性规划 | `持续`（白色） |

**第二步：区分"事件"和"规模/规划"**

- **事件型数据**（招标/中标/开工/投产/备案）：看事件发生在哪一天/哪一周
  - "8月7日 电信韶关2.2期EPC开标" → 周变化（本周）
  - "7月21日 广州职大智算中心设备中标" → 月变化
  - "2025年底 博晨算力中心EPC中标" → 年变化

- **规模型数据**（建筑面积/机柜数/投资额/算力规模）：看数据描述的是哪个时间点的状态
  - "2026年全省智算中心招标总额超500亿元" → 这是年度累计统计 → 年变化
  - "某项目规划8万个标准机柜" → 持续（规划中的规模，无时间切点）
  - "某园区预计2026年12月投产" → 这是未来预期 → 持续或月变化

- **混合型数据**（本周事件 + 历史规模对比）：先判断"本周事件是什么"，再看历史数据是作对比用还是主语
  - "8月7日电信韶关2.2期开标（总建面7.31万㎡），此前1.4期机电施工已于6月发包" → 2.2期开标标`周变化（本周）`，1.4期机电标`月变化`

#### ⚠️ 常见错误（必须避免）

| 错误 | 正确 |
|------|------|
| 2025年备案数据标`周变化（本周）` | 2025年数据只能标`年变化`或`季变化` |
| 备案计划投资额（如100亿）当成本周实际招标金额 | 备案投资=计划总投资标`月变化/年变化`，另标注"备案口径" |
| 长期建设规划（如"规划8万机柜"）标`周变化（本周）` | 标`持续` |
| 把"预计2026年底投产"当成已发生事件标`周变化（本周）` | 未来预期标`持续` |

#### 第四步：写入JSON时的 data_cards 结构（强制）

数据卡片 JSON 为**数组**，每张卡 5 个字段，**全部必填**（缺 label/value 会渲染成空卡）：

```json
[
  {
    "label": "运营商渠道新增公告",
    "value": "8项",
    "tag_class": "up",
    "tag_text": "月变化",
    "change": "近30天 电信2/移动2/联通4"
  },
  {
    "label": "信息表收录项目",
    "value": "22项",
    "tag_class": "up",
    "tag_text": "周变化（本周）",
    "change": "招标/中标/备案 按日期倒序"
  }
]
```

| 字段 | 必填 | 说明 |
|------|------|------|
| `label` | ✅ | 指标名（如"运营商渠道新增公告"） |
| `value` | ✅ | 核心数值（如"8项"、"22项"） |
| `tag_class` | ✅ | `up`（红/正）或 `down`（绿/负） |
| `tag_text` | ✅ | 时间维度标签，取值见下 |
| `change` | ✅ | 补充说明（口径/明细），可空字符串但字段必须存在 |

**`tag_text` 取值规范：**

| 取值 | 颜色 | 适用场景 |
|------|------|----------|
| `周变化（本周）` | 绿 | 本周（≤7天）内发生的招标/中标/开工/投产 |
| `月变化` | 黄 | 8-30天前的事件/数据 |
| `季变化` | 灰 | 本季度统计/月度累计 |
| `年变化` | 灰 | 上一年度统计数据 |
| `持续` | 白 | 长期规划/无明确时间节点 |

**推荐 5 张卡**（可增减）：①运营商渠道新增公告 ②信息表收录项目 ③本周/月新增土建/机电工程 ④韶关集群累计项目 ⑤覆盖城市。**卡片数 ≥3**，每张卡 label/value 非空。

---

## 生成调用方式（推荐）

使用新的生成脚本（基于骨架模板）。**`--data_cards_json` 必须填入 ≥3 张非空数据卡**（结构见上文"第四步"），禁止传 `[]` 空数组：

```bash
# 数据卡与来源 JSON 可先写到文件再引用，避免 shell 转义问题
python3 skills/china-computing-guangdong-construction-weekly-report/scripts/generate_weekly_report.py \
    --date "2026-08-11" \
    --date_from "2026-08-05" \
    --week_number "第33期" \
    --data_cards_json '[{"label":"运营商渠道新增公告","value":"8项","tag_class":"up","tag_text":"月变化","change":"近30天 电信2/移动2/联通4"},{"label":"信息表收录项目","value":"22项","tag_class":"up","tag_text":"周变化（本周）","change":"招标/中标/备案 按日期倒序"},{"label":"韶关集群智算项目","value":"23个","tag_class":"up","tag_text":"持续","change":"公开统计 总投资超1116亿元"}]' \
    --chapter_overview "本期...（本章关键概述，从采集结果提炼）" \
    --content_8_1 "" \
    --content_8_2 "" \
    --content_8_3 "" \
    --content_8_4 "" \
    --content_8_5 "" \
    --content_8_6 "" \
    --sources_json '["中国电信阳光采购网 caigou.chinatelecom.com.cn（scrapling/Playwright 直抓，2026-08）"]' \
    --output "report/广东智算中心建设分析报告.html"
```

> ⚠️ **两阶段写入**：数据量大时按"文件写入策略"先写 `/tmp/report_args.json`（含 data_cards_json 完整数组）与各 `/tmp/content_8_X.html`，再让脚本读取，**禁止在命令行硬编码超长 JSON**。

---

## 8-2 深度分析分点规范（强制）

8-2 信息表末尾的 `analysis-box` 深度分析**必须按主体/来源分点**（`<ol>` 有序列表），逐家分析各运营商、政府/事业单位的智算中心建设情况，禁止一段笼统概述。

**分点顺序（按信息表内条数从多到少）与模板：**

```html
<div class="analysis-box"><h4>深度分析（按运营商/来源分点）</h4>
<ol style="margin:8px 0 0 20px;padding:0;line-height:1.9;">
<li><strong>中国电信（N条）——"主标题"</strong><br>
  本点主体 N 条公告的共性特征与建设逻辑：按 ①土建 ②机电/配套 ③电力 ④运维等工序分小点（可少于4个），
  每个小点带具体项目名+金额/面积/日期，揭示该主体的发包节奏、区域布局、建设阶段。</li>
<li><strong>中国移动（N条）——"主标题"</strong><br>…</li>
<li><strong>中国联通（N条）——"主标题"</strong><br>…</li>
<li><strong>政府/事业单位及乙方宝政采渠道（N条）——"主标题"</strong><br>
  非运营商部分：①集群公共服务 ②政采类应用（算力租赁/机房改造/设备）③科研 ④外围大项目（如博晨35亿EPC）。</li>
</ol>
<p style="margin:8px 0 0;">总体看，…（一段总结：主战场+应用城市+外围布局）</p></div>
```

**规则：**
- 主体归类：按"招标/业主单位"列判断（含"电信/移动/联通"→对应运营商；否则归"政府/事业单位及乙方宝政采渠道"），条数从信息表实时统计
- 每个要点必须有**主标题**（概括该主体建设主线，如"韶关双园区+多期滚动"）＋ **①②③分小点**（按工序/区域/类型）
- 所有金额/面积/日期/中标人必须来自信息表真实记录，禁止编造
- 联通条数少（常仅2-3条）时允许单点集中描述，但仍是独立 `li`
- 末尾 `总体看` 总结段：主战场（韶关集群）+ 应用城市（广州政采）+ 外围多点布局

---

## 深度文字分析规范

每个数据表后**必须**包含80-150字深度分析，内容结构：
1. **数据本身**（时间维度 + 具体数字）
2. **变化原因**（为什么变化/为什么是这个规模）
3. **建设影响**（对广东算力布局、全国智算格局意味着什么）

> **8-2 表例外**：8-2 深度分析不受此限，必须用上文「8-2 深度分析分点规范」的分点结构（80-150字不适用，可更长）。

---

## HTML模板体系说明

本章HTML与第六章（供应商与产业格局）共用同一套CSS体系，核心样式规范：

| 元素 | CSS规范 |
|------|---------|
| 头部背景 | `linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)` |
| h2 | `color: #0f172a; border-bottom: 3px solid #0ea5e9` |
| h3 | `color: #1e3a5f; border-left: 3px solid #38bdf8; padding-left: 8px` |
| section | `background: white; border-radius: 10px; box-shadow: 0 2 12px rgba(0,0,0,0.05)` |
| 表格表头 | `background: #0f172a; color: white` |
| 斑马纹 | `tr:nth-child(even) td { background:#f8fafc; }` |
| box强调框 | `border-left: 4px solid` + 颜色（蓝`#0ea5e9`/绿`#22c55e`/黄`#f59e0b`/紫`#8b5cf6`/红`#ef4444`） |
| 全局背景 | `#f5f7fa` 浅灰蓝 |
| 全局字体 | `line-height: 1.8` |
| 表格字号 | `font-size: 0.7em` |
| 数据卡片 | 白底卡片 + `border-top: 3px solid #0ea5e9` |
| analysis-box | `background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white` |
| 全章导航 | `.all-chapters-nav` + `.chapter-tabs` 横向排列，active状态渐变紫色 |

---

## 验证清单

生成后验证：
- [ ] 文件大小 >25KB
- [ ] **数据卡片 ≥3 张且 label/value 非空**（`grep -c '<div class="label">'` 计数 ≥3，且无 `<div class="label"></div>` 空卡；若发现空卡须重建 data_cards_json 后重新生成）
- [ ] 章节 8-1 到 8-6 齐全
- [ ] 招标/中标/备案信息表（按日期倒序）存在，含序号/项目名称/招标/业主单位/类型/金额/日期/城市/项目规模与备注列（**无时间维度列**）
- [ ] **信息表"项目规模与备注"列每行详尽**（非标题复述，含规模/内容实质；抽查 8-2 表格，若多数行只是标题复述则不合格）
- [ ] **8-2 表末深度分析按运营商/来源分点**（`<ol>` 含"中国电信/中国移动/中国联通/政府事业单位"各 `li` 要点，每个要点带条数+主标题+①②③小点；若是一段笼统概述则不合格）
- [ ] 按城市汇总、按招标类型汇总两个表格存在
- [ ] 信息表日期列使用完整日期且按倒序排列；备案项目已标注"备案口径"
- [ ] 8-3/8-4/8-5 汇总表格保留"时间维度"列；8-2 信息表不设时间维度列
- [ ] `.time-dim` 标签数量 ≥10（8-3/8-4/8-5 中统计）
- [ ] `.analysis-box` 深度分析 ≥4处
- [ ] 无"周环比"误标
- [ ] 数据来源标注完整
- [ ] 全章目录导航栏（`.all-chapters-nav`）存在
- [ ] 要闻汇总表格（`.news-table`）**不**存在于本章
- [ ] 小节标题（如 8-2-1、8-3-1）**没有重复出现两次**
- [ ] 备案投资额与中标金额已区分标注

---

## 文件对应关系

| 文件 | 用途 |
|------|------|
| `SKILL.md` | 本技能说明文档 |
| `references/official_channels.md` | ⚠️ 官方渠道链接清单（数据采集首选，持续维护） |
| `template/guangdong_template.html` | 纯CSS参考模板 |
| `template/guangdong_skeleton.html` | 含占位符的报告骨架 |
| `scripts/generate_weekly_report.py` | HTML生成脚本 |
| `scripts/__pycache__/` | 脚本缓存目录 |
