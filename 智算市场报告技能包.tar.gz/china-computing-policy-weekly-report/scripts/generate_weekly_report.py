#!/usr/bin/env python3
"""
中国智算政策环境周报HTML生成脚本 v2
章节编号从 1-1 开始（第一章）
使用骨架模板 + .replace() 注入内容，内容通过JSON文件传递
"""

import argparse
import json
import re
from datetime import datetime, timedelta
import os

# 读取骨架模板（模块加载时读取一次）
SKELETON_PATH = os.path.join(os.path.dirname(__file__), '../template/policy_skeleton.html')
SKELETON = open(SKELETON_PATH, "r", encoding="utf-8").read()

def build_data_cards(cards_data):
    cards = []
    for cd in cards_data:
        label = cd.get("label", "")
        value = cd.get("value", "")
        sub = cd.get("sub", "")
        tag_class = cd.get("tag_class", "tag-continue")
        tag_text = cd.get("tag", "")
        tag_html = f'<span class="policy-tag {tag_class}">{tag_text}</span>' if tag_text else ""
        cards.append(f"""<div class="data-card">
    <div class="label">{label} {tag_html}</div>
    <div class="value">{value}</div>
    <div class="sub">{sub}</div>
</div>""")
    return "\n".join(cards)

def build_policy_table_rows(policy_data):
    rows = []
    for pd in policy_data:
        area = pd.get("area", "")
        prev = pd.get("prev", "—")
        change = pd.get("change", "")
        tag_class = pd.get("tag_class", "tag-continue")
        tag_text = pd.get("tag_text", "→ 延续")
        analysis = pd.get("analysis", "—")
        rows.append(f"""<tr>
    <td><strong>{area}</strong></td>
    <td>{prev}</td>
    <td>{change}</td>
    <td><span class="policy-tag {tag_class}">{tag_text}</span></td>
    <td>{analysis}</td>
</tr>""")
    return "\n".join(rows)

def parse_date(date_str):
    """解析各种日期格式为(月份, 日)元组，支持中文和英文格式"""
    s = date_str.strip()
    
    # 如果包含"月"字，提取中文月日格式（如"5月26日"）
    if '月' in s:
        m = re.match(r'(\d+)月(\d+)', s)
        if m:
            return (int(m.group(1)), int(m.group(2).rstrip('日')))
        return (0, 0)
    
    # YYYY-MM-DD 格式 (如 2026-05-26) - 提取月和日
    m = re.match(r'\d{4}[-](\d{1,2})[-](\d{1,2})', s)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    
    # MM-DD 或 M-D 格式 (如 05-26, 5-26)
    m = re.match(r'(\d{1,2})[-\.](\d{1,2})', s)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    
    return (0, 0)


def clean_html_fragment(html):
    """清洗HTML内容片段，去除外层div包装和多余缩进空白，自动包裹裸<ul>"""
    if not html:
        return html
    # 去除首尾空白
    html = html.strip()
    # 去除前导缩进（每行开头的空格/TAB）
    lines = html.split('\n')
    cleaned_lines = []
    for line in lines:
        cleaned_lines.append(line.lstrip())
    html = '\n'.join(cleaned_lines)
    # 去除首尾空行
    html = html.strip()
    
    # 去除最外层包裹的 <div class="section"> 或 <div class="section" id="...">
    first_div = html.find('<div')
    last_div_close = html.rfind('</div>')
    
    if first_div >= 0 and last_div_close > first_div:
        div_start = first_div
        div_end = html.find('>', div_start)
        if div_end > 0:
            opening_tag = html[div_start:div_end+1]
            if 'class' in opening_tag and 'section' in opening_tag:
                content_between = html[div_end+1:last_div_close]
                content_between = content_between.strip()
                html = content_between
    
    # 去除首尾空行
    html = html.strip()
    
    # 检测裸 <ul> 并自动包裹（1-5-2等章节的<ul>没有外层key-points包装）
    # 策略：在 </p> 后直接跟 <ul> 时，自动包裹 <div class="key-points">
    def wrap_naked_ul(match):
        before = match.group(1)  # </p> and whitespace
        ul_content = match.group(2)  # <ul>...</ul>
        return before + '<div class="key-points">' + ul_content + '</div>'
    
    # Pattern: </p> followed by <ul> (with possible whitespace/newlines between)
    html = re.sub(r'(</p>\s*)(<ul>.*?</ul>)', wrap_naked_ul, html, flags=re.DOTALL)
    
    return html


def build_timeline(timeline_data):
    # 按日期倒序排列（从新到旧）
    timeline_data = sorted(timeline_data, key=lambda x: parse_date(x.get("date", "")), reverse=True)
    items = []
    for item in timeline_data:
        date = item.get("date", "")
        title = item.get("title", "")
        source = item.get("source", "")
        impact = item.get("impact", "")
        tag_class = item.get("tag_class", "tag-continue")
        tag_text = item.get("tag_text", "")
        tag_html = f'<span class="policy-tag {tag_class}">{tag_text}</span>' if tag_text else ""
        items.append(f"""<div class="timeline-item">
    <div class="timeline-date">{date} {tag_html}</div>
    <div class="timeline-title">{title}</div>
    <div class="timeline-source">{source}</div>
    <div class="timeline-impact">{impact}</div>
</div>""")
    return "\n".join(items)

def build_news_table(news_items):
    # 按日期倒序排列（从新到旧）
    news_items = sorted(news_items, key=lambda x: parse_date(x.get("date", "")), reverse=True)
    header = """<table class="policy-table">
<thead>
<tr>
    <th>日期</th>
    <th>事件</th>
    <th>发布部门</th>
    <th>层级</th>
    <th>重要度</th>
</tr>
</thead>
<tbody>
"""
    rows = []
    for item in news_items:
        stars = "★" * item.get("importance", 3)
        rows.append(f"""<tr>
    <td>{item.get("date", "")}</td>
    <td>{item.get("event", "")}</td>
    <td>{item.get("department", "")}</td>
    <td>{item.get("level", "—")}</td>
    <td><span class="change-new">{stars}</span></td>
</tr>""")
    footer = """</tbody>
</table>"""
    return header + "\n".join(rows) + "\n" + footer

def build_sources(source_list):
    tags = [f'<span class="source-tag">{s}</span>' for s in source_list]
    return "\n".join(tags)

def data_note_html(date_from, date, prev_week_start, prev_week_end):
    return f"""<div class="data-note">
<strong>数据说明：</strong>本报告聚焦最近7天（{date_from}—{date}）中国智算相关政策动态，对比上周数据（{prev_week_start}—{prev_week_end}基准）进行周变化分析。数据均来自国务院、发改委、工信部、国家数据局等官方渠道及权威媒体。<br>
<strong>政策变化标注：</strong>↑ 新增政策（绿色） | → 政策延续（蓝色） | ↓ 政策收紧/废止（红色） | ☆ 重要政策（橙色）
</div>"""

def fill_skeleton(
    week_number, date, date_from,
    data_cards, policy_table_rows, timeline_html,
    content_1_3, content_1_4, content_1_5,
    content_1_6, content_1_7,
    news_table_html, sources_list,
    chapter_overview=""
):
    """将所有占位符替换为实际内容，生成最终HTML"""
    base_date = datetime.strptime(date, "%Y-%m-%d")
    prev_week_end = base_date - timedelta(days=1)
    prev_week_start = (prev_week_end - timedelta(days=6)).strftime("%Y-%m-%d")
    prev_week_end_str = prev_week_end.strftime("%Y-%m-%d")
    date_range = f"{date_from}—{date}"
    year = date[:4]

    replacements = {
        "{{WEEK_NUMBER}}": week_number,
        "{{DATE_RANGE}}": date_range,
        "{{DATA_NOTE}}": data_note_html(date_from, date, prev_week_start, prev_week_end_str),
        "{{DATA_CARDS}}": data_cards,
        "{{POLICY_TABLE_ROWS}}": policy_table_rows,
        "{{TIMELINE}}": timeline_html,
        "{{CHAPTER_OVERVIEW}}": chapter_overview or "<p>本周政策环境分析详见各章节。</p>",
        "{{CONTENT_1_3}}": clean_html_fragment(content_1_3) or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_1_4}}": clean_html_fragment(content_1_4) or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_1_5}}": clean_html_fragment(content_1_5) or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_1_6}}": clean_html_fragment(content_1_6) or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_1_7}}": clean_html_fragment(content_1_7) or "<p>本周无重大调整，维持上月预测。</p>",
        "{{NEWS_TABLE}}": news_table_html,
        "{{SOURCES_LIST}}": sources_list,
        "{{YEAR}}": year,
    }

    html = SKELETON
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html

def main():
    parser = argparse.ArgumentParser(description="生成中国智算政策环境周报HTML v2（基于骨架模板）")
    # 推荐：所有数据通过单个JSON文件传递
    parser.add_argument("--data_json", default="", help="完整数据JSON文件路径（推荐）")
    # 以下为兼容旧接口的单独参数
    parser.add_argument("--date", default=None, help="报告日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD")
    parser.add_argument("--week_number", default="第X期", help="周报期号")
    parser.add_argument("--data_cards_json", default="[]", help="数据卡片JSON")
    parser.add_argument("--policy_table_json", default="[]", help="政策对比表JSON")
    parser.add_argument("--timeline_json", default="[]", help="时间线JSON")
    parser.add_argument("--news_json", default="[]", help="要闻JSON")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON")
    parser.add_argument("--chapter_overview", default="", help="本章关键概述HTML")
    parser.add_argument("--content_json", default="{}", help="1-3到1-7章节内容JSON")
    parser.add_argument("--output", help="输出HTML路径")
    args = parser.parse_args()

    # 支持 --data_json 单文件模式（推荐）
    if args.data_json and os.path.exists(args.data_json):
        with open(args.data_json, 'r', encoding='utf-8') as f:
            all_data = json.load(f)
        date = all_data.get('date', args.date)
        date_from = all_data.get('date_from', args.date_from)
        week_number = all_data.get('week_number', args.week_number)
        cards_data = json.loads(all_data.get('data_cards_json', '[]'))
        policy_data = json.loads(all_data.get('policy_table_json', '[]'))
        timeline_data = json.loads(all_data.get('timeline_json', '[]'))
        news_items = json.loads(all_data.get('news_json', '[]'))
        sources_list = json.loads(all_data.get('sources_json', '[]'))
        chapter_overview = all_data.get('chapter_overview', '')
        content_data = json.loads(all_data.get('content_json', '{}'))
    else:
        # 兼容旧接口
        date = args.date
        date_from = args.date_from
        week_number = args.week_number
        cards_data = json.loads(args.data_cards_json)
        policy_data = json.loads(args.policy_table_json)
        timeline_data = json.loads(args.timeline_json)
        news_items = json.loads(args.news_json)
        sources_list = json.loads(args.sources_json)
        # 以下字符串参数从子进程传入（含JSON编码），需反序列化
def decode_arg(s):
        """反序列化通过JSON编码传入的字符串参数；防御性清洗 \\n 两字符 + 残留外层引号

        LRN-20260821-001: subagent 误用 json.dump 写 HTML 内容文件，导致真换行 0x0A
        被 JSON 规范转义为 \\n 两字符；f.read() 读 JSON 文件时带入外层引号。
        decode_arg 防御性兜底：剥离外层引号 + 还原 \\n → 真实换行。
        """
        if not s:
            return ""
        try:
            result = json.loads(s)
        except Exception:
            result = s

        # 防御性清洗：消除 JSON 残留转义
        if isinstance(result, str):
            # 1. 剥离首尾多余引号（subagent 用 f.read() 读 JSON 文件时带入）
            if result.startswith('"') and result.endswith('"'):
                inner = result[1:-1]
                # 内部引号成对（偶数）才剥离
                if inner.count('\\"') % 2 == 0 and inner.count('"') % 2 == 0:
                    result = inner
            # 2. JSON 字符串内的 \\n 转义（两字符）→ 真实换行
            result = result.replace('\\n', '\n')

        return result
if __name__ == "__main__":
    main()