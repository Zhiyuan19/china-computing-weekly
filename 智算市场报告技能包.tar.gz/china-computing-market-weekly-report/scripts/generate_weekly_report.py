#!/usr/bin/env python3
"""
中国智算市场规模周报HTML生成脚本 v4
基准骨架：../template/market_skeleton.html
基准样式：../template/market_template.html（仅提取CSS）
运行时读取骨架，填充本周数据，输出干净HTML
"""

import argparse
import json
import os
import re
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(__file__)
SKELETON_PATH = os.path.join(SCRIPT_DIR, "..", "template", "market_skeleton.html")
CSS_PATH = os.path.join(SCRIPT_DIR, "..", "template", "market_template.html")

# 从 market_template.html 提取纯CSS（<style>标签内容）
with open(CSS_PATH, "r", encoding="utf-8") as f:
    raw = f.read()
css_match = re.search(r'<style>(.*?)</style>', raw, re.DOTALL)
CSS_CONTENT = css_match.group(1) if css_match else ""

# 读取骨架模板
with open(SKELETON_PATH, "r", encoding="utf-8") as f:
    SKELETON = f.read()


def build_data_cards(data_cards_input):
    """生成数据卡片 HTML
    支持两种格式：
    1. data_table风格（dict，key=卡片标签）：遍历items，用vals里的prev/curr/unit/change/time_dim渲染
    2. data_cards风格（list of dict）：直接用每个dict的label/value/unit/change_str字段
    """
    cards = []
    if isinstance(data_cards_input, list):
        # 格式2：data_cards数组
        for item in data_cards_input:
            label = item.get("label", "")
            value = item.get("value", "")
            unit = item.get("unit", "")
            prev = item.get("prev", "—")
            change_str = item.get("change_str", item.get("change", "—"))
            cards.append(
                f'<div class="data-card">\n'
                f'    <div class="label">{label}</div>\n'
                f'    <div class="value">{value}<span class="unit">{unit}</span></div>\n'
                f'    <div class="change">上周 {prev} | {change_str}</div>\n'
                f'</div>'
            )
    else:
        # 格式1：data_table字典（key=卡片名，vals含prev/curr/unit/change）
        for key, vals in data_cards_input.items():
            prev = vals.get("prev", "—")
            curr = vals.get("curr", "—")
            change = vals.get("change", 0)
            unit = vals.get("unit", "")
            time_dim = vals.get("time_dim", "周环比")
            if isinstance(change, (int, float)):
                change_str = f"↑ +{change:.1f}%" if change > 0 else (f"↓ {change:.1f}%" if change < 0 else "— 持平")
            else:
                change_str = str(change) if change else "—"
            cards.append(
                f'<div class="data-card">\n'
                f'    <div class="label">{key}</div>\n'
                f'    <div class="value">{curr}<span class="unit">{unit}</span></div>\n'
                f'    <div class="change">上周 {prev} {unit} | {change_str}（{time_dim}）</div>\n'
                f'</div>'
            )
    return "\n".join(cards)


def build_data_table_rows(data_table):
    """生成周对比表 tbody 行
    data_table格式：dict{指标名: {prev, curr, time_dim, change_pct, unit, analysis}}
    """
    rows = []
    for key, vals in data_table.items():
        prev = vals.get("prev", "—")
        curr = vals.get("curr", "—")
        # 支持change_pct（SKILL.md规范）和change（旧格式）
        change = vals.get("change_pct", vals.get("change", 0))
        unit = vals.get("unit", "")
        time_dim = vals.get("time_dim", "周环比")
        analysis = vals.get("analysis", "—")
        if isinstance(change, (int, float)):
            if change > 5:
                change_str = f'<span class="change-up">↑ +{change:.1f}%</span>'
            elif change > 0:
                change_str = f'<span class="change-flat">↑ +{change:.1f}%</span>'
            elif change < 0:
                change_str = f'<span class="change-down">↓ {change:.1f}%</span>'
            else:
                change_str = '<span class="change-flat">— 持平</span>'
        else:
            change_str = str(change) if change else "—"
        rows.append(
            f"<tr>\n"
            f"    <td><strong>{key}</strong></td>\n"
            f"    <td>{prev} {unit}</td>\n"
            f"    <td>{curr} {unit}</td>\n"
            f"    <td>{change_str}（{time_dim}）</td>\n"
            f"    <td>{analysis}</td>\n"
            f"</tr>"
        )
    return "\n".join(rows)


def build_timeline(timeline_data):
    """生成时间线 HTML（按日期倒序）"""
    # 按日期倒序（新到旧）排列
    sorted_data = sorted(timeline_data, key=lambda x: x.get("date", ""), reverse=True)
    items = []
    for item in sorted_data:
        content = item.get("impact", "") or item.get("content", "")
        items.append(
            f'<div class="timeline-item">\n'
            f'    <div class="timeline-date">{item.get("date", "")}</div>\n'
            f'    <div class="timeline-title">{item.get("title", "")}</div>\n'
            f'    <div class="timeline-source">{item.get("source", "")}</div>\n'
            f'    <div class="timeline-impact">{content}</div>\n'
            f'</div>'
        )
    return "\n".join(items)


def build_news_table(news_items):
    """"生成要闻汇总表 HTML（按日期倒序）"""
    if not news_items:
        return '<p class="warning">⚠️ news数组为空，请检查JSON数据</p>'
    # 检查每条数据是否有必填字段
    required_keys = {"date", "event", "subject", "scale", "importance"}
    missing_warn = []
    for i, item in enumerate(news_items):
        missing = required_keys - set(item.keys())
        if missing:
            missing_warn.append(f'第{i+1}条缺少字段: {missing}，实际keys={list(item.keys())}')
    if missing_warn:
        print('⚠️ news字段警告:', missing_warn)
    # 按日期倒序
    sorted_data = sorted(news_items, key=lambda x: x.get("date", ""), reverse=True)
    rows = []
    for item in sorted_data:
        date = item.get("date", "")
        event = item.get("event", item.get("title", "[缺event字段]"))
        subject = item.get("subject", item.get("source", "—"))
        scale = item.get("scale", item.get("summary", item.get("规模", "—")))
        importance = item.get("importance", item.get("star", 3))
        stars = "★" * importance
        rows.append(
            f"<tr>\n"
            f"    <td>{date}</td>\n"
            f"    <td>{event}</td>\n"
            f"    <td>{subject}</td>\n"
            f"    <td>{scale}</td>\n"
            f"    <td><span class=\"change-new\">{stars}</span></td>\n"
            f"</tr>"
        )
    header = (
        '<table class="policy-table">\n<thead>\n<tr>\n'
        '    <th>日期</th><th>事件</th><th>主体</th><th>规模/数据</th><th>重要度</th>\n'
        '</tr>\n</thead>\n<tbody>\n'
    )
    return header + "\n".join(rows) + "\n</tbody>\n</table>"


def build_sources(source_list):
    """生成来源标签 HTML"""
    return "\n".join(f'<span class="source-tag">{s}</span>' for s in source_list)


def data_note_html(date_from, date, prev_week_start, prev_week_end):
    return (
        f'<div class="data-note">\n'
        f'<strong>数据说明：</strong>本周报聚焦最近7天（{date_from}—{date}）市场规模变化，'
        f'对比上周数据（{prev_week_start}—{prev_week_end}基准）进行周变化分析。数据均来自权威机构公开披露。<br>\n'
        f'<strong>周变化说明：</strong>周变化 = 本周数据 - 上周基准；变化率 = （本周-上周）/ 上周 × 100%；'
        f'变化率 &gt; 5% 为"显著变化"（标绿）；1%-5% 为"一般变化"；&lt; 1% 为"持平"。\n'
        f'</div>'
    )


def fill_skeleton(
    week_number, date, date_from,
    data_cards, data_table_rows, timeline_html,
    content_2_3, content_2_4, content_2_5,
    content_2_6, content_2_7,
    news_table_html, sources_list,
    chapter_overview=""
):
    """将所有占位符替换为实际内容，生成最终HTML"""
    # 日期范围
    base_date = datetime.strptime(date, "%Y-%m-%d")
    prev_week_end = base_date - timedelta(days=1)
    prev_week_start = (prev_week_end - timedelta(days=6)).strftime("%Y-%m-%d")
    prev_week_end_str = prev_week_end.strftime("%Y-%m-%d")
    date_range = f"{date_from}—{date}"
    year = date[:4]

    replacements = {
        "{{WEEK_NUMBER}}": week_number,
        "{{DATE_RANGE}}": date_range,
        "{{CHAPTER_OVERVIEW}}": chapter_overview or "<p>本周市场规模分析详见各章节。</p>",
        "{{DATA_NOTE}}": data_note_html(date_from, date, prev_week_start, prev_week_end_str),
        "{{DATA_CARDS}}": data_cards,
        "{{DATA_TABLE_ROWS}}": data_table_rows,
        "{{TIMELINE}}": timeline_html,
        "{{CONTENT_2_3}}": content_2_3 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_2_4}}": content_2_4 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_2_5}}": content_2_5 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_2_6}}": content_2_6 or "<p>本周无重大事件需深度分析。</p>",
        "{{CONTENT_2_7}}": content_2_7 or "<p>本周无重大调整，维持上月预测。</p>",
        "{{NEWS_TABLE}}": news_table_html,
        "{{SOURCES_LIST}}": sources_list,
        "{{YEAR}}": year,
    }

    html = SKELETON
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    # 注入 CSS
    html = html.replace("{{STYLE_CSS}}", CSS_CONTENT)

    return html


def main():
    parser = argparse.ArgumentParser(description="生成中国智算市场规模周报HTML v4（基于骨架模板）")
    parser.add_argument("--date", required=True, help="报告日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD")
    parser.add_argument("--week_number", default="第X期", help="周报期号")
    parser.add_argument("--data_table_json", default="{}", help="周对比数据JSON")
    parser.add_argument("--timeline_json", default="[]", help="时间线数据JSON")
    parser.add_argument("--news_json", default="[]", help="要闻JSON")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON")
    parser.add_argument("--content_2_3", default="", help="2-3章节HTML内容")
    parser.add_argument("--content_2_4", default="", help="2-4章节HTML内容")
    parser.add_argument("--content_2_5", default="", help="2-5章节HTML内容")
    parser.add_argument("--content_2_6", default="", help="2-6章节HTML内容")
    parser.add_argument("--content_2_7", default="", help="2-7章节HTML内容")
    parser.add_argument("--chapter_overview", default="", help="本章关键概述段落")
    parser.add_argument("--output", required=True, help="输出HTML路径")
    args = parser.parse_args()

    # 解析JSON
    data_table = json.loads(args.data_table_json)
    timeline_data = json.loads(args.timeline_json)
    news_items = json.loads(args.news_json)
    sources_list = json.loads(args.sources_json)

    # 以下字符串参数从子进程传入（含JSON编码），需反序列化
def decode_arg(s):
        """反序列化通过JSON编码传入的字符串参数；防御性清洗 \\n 两字符 + 残留外层引号

        LRN-20260821-001: subagent 误用 json.dump 写 HTML 内容文件，导致真换行 0x0A
        被 JSON 规范转义为 \\n 两字符；f.read() 读 JSON 文件时带入外层引号。
        decode_arg 防御性兜底：剥离外层引号 + 还原 \\n → 真实换行。
        """
        if not s:
            return ""
        try:
            result = json.loads(s)
        except Exception:
            result = s

        # 防御性清洗：消除 JSON 残留转义
        if isinstance(result, str):
            # 1. 剥离首尾多余引号（subagent 用 f.read() 读 JSON 文件时带入）
            if result.startswith('"') and result.endswith('"'):
                inner = result[1:-1]
                # 内部引号成对（偶数）才剥离
                if inner.count('\\"') % 2 == 0 and inner.count('"') % 2 == 0:
                    result = inner
            # 2. JSON 字符串内的 \\n 转义（两字符）→ 真实换行
            result = result.replace('\\n', '\n')

        return result
if __name__ == "__main__":
    main()
