---
name: china-computing-market-weekly-report
description: 中国智算市场规模周更报告生成技能。当用户要求生成智算/算力/AI芯片/数据中心等行业的周度市场规模分析报告、市场周报、市场追踪报告时调用。本技能专注于检索最新一周（7-14天）内的市场规模数据变化，进行深度对比分析，生成结构化的HTML周报报告。报告为某完整智算报告的第二章（市场规模分析），因此所有章节编号均从2-1、2-2开始。
metadata:
  clawdbot:
    emoji: 📈
    requires:
      anyBins:
        - python3
---

# 中国智能算力市场规模周更报告生成技能

## 核心定位

**骨架文件**：`template/market_skeleton.html`
**样式文件**：`template/market_template.html`
**生成脚本**：`scripts/generate_weekly_report.py`

---

## ⚠️ 绝对禁令

以下内容严禁直接写入最终报告：
- `SKILL.md` 中的任何数据
- 骨架/样式文件中的任何数据

所有数字必须来自本次 Tavily 检索。

---

## 文件写入策略（强制）

```
1. write → /tmp/ch2_data.json（必须严格遵循本文档规定的JSON格式）
2. exec → 创建临时包装脚本（读取 /tmp/ch2_data.json → 通过命名参数调用 generate_weekly_report.py）
3. 验证输出 > 25KB
```

**核心规则**：写文件的是Python脚本，不是模型输出流。子agent 生成 JSON 时必须严格使用本文档规定的字段名，不得自创字段。


- **JSON数据文件**（data_table/timeline/news等）→ 用 `json.dump()` 写 + `json.load()` 读
- **HTML内容文件**（content_2_3等）→ 用 `f.write()` 写纯文本，读入后通过命名参数传入脚本
- **禁止**对内容字符串再次 `json.dumps()` 编码后再传参

---

## 数据时效性规范（强制）

| 类型 | 定义 | 适用场景 |
|------|------|---------|
| 周环比 | 本周 vs 上周（7天） | 价格、规模小幅波动 |
| 月环比 | 本周 vs 4周前 | 季度内变化 |
| 年同比 | 本周 vs 去年同期 | 大规模数据确认 |
| 年内变化 | 2026年某月 vs 2026年初 | H100价格等持续追踪指标 |

**标注规则**：
- 每行数据的 `time_dim` 字段必须填"周环比/月环比/年同比"之一
- 严禁将年度数据标注为"周环比"
- 周环比<1%时，分析段必须说明"为何无显著变化"

---

## 数据JSON格式规范（严格按此填写）

> ⚠️ **字段名必须严格匹配，不得使用同义词或自创字段。以下所有字段名均为脚本直接读取的key，字段名错误将导致数据无法注入。**

```json
{
  "date": "{REPORT_DATE}",
  "date_from": "{PERIOD_START}",
  "week_number": "{WEEK_NUMBER}",

  "chapter_overview": "（string，本章概述>200字，支持<strong><em>标签）",

  "data_table": {
    "指标名": {
      "prev": "上周数据（具体数字+单位）",
      "curr": "本周数据（具体数字+单位）",
      "time_dim": "周环比",
      "change_pct": 3.07,  // 示例：正数=上涨，负数=下跌
      "unit": "单位",
      "analysis": ">100字的深度分析，必须有具体数字、原因、影响"
    }
  },

  "timeline": [
    {
      "date": "05-09",
      "title": "事件标题",
      "source": "来源：机构名，05-09",
      "impact": ">80字的影响分析，说明对市场规模/价格/格局的具体影响"
    }
  ],

  "news": [
    {
      "date": "2026-05-09",
      "event": "事件名称（完整一句）",
      "subject": "涉及主体",
      "scale": "规模数据或—",
      "importance": 4
    }
  ],

  "sources": ["来源1", "来源2", "..."],

  "content_2_3": "<h3>2-3-1标题</h3><p>200字+分析...</p><h3>2-3-2标题</h3><p>200字+...</p>",
  "content_2_4": "<h3>2-4-1标题</h3><p>200字+...</p><h3>2-4-2标题</h3><p>200字+...</p>",
  "content_2_5": "<h3>2-5-1标题</h3><p>200字+...</p><h3>2-5-2标题</h3><p>200字+...</p>",
  "content_2_6": "<div class='deep-event'><div class='deep-event-title'>专题标题</div><h4>核心背景</h4><p>100-200字</p><h4>关键数据</h4><p>数字+出处</p><h4>深度分析</h4><p>100字+要点1...</p><p>100字+要点2...</p><h4>下周预判</h4><p>80字+</p></div>",
  "content_2_7": "<div class='forecast-grid'><div class='forecast-card'><div class='year'>预报项</div><div class='value'>预测值</div><div class='note'>说明</div></div></div><h3>重点关注事项</h3><p>3-5条，每条>80字</p><h3>市场综述</h3><p>>200字</p>"
}
```

### 字段逐条说明（必须遵守）

#### `news` 数组（2-8要闻表）
| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `date` | string | 日期，MM-DD格式 | `"05-09"` |
| `event` | string | 事件名称，完整一句 | `"腾讯云AI算力价格上调5%"` |
| `subject` | string | 涉及主体 | `"腾讯云"` |
| `scale` | string | 规模数据，无则`"—"` | `"5%涨幅"` |
| `importance` | int | 重要度1-5 | `4` |

#### `timeline` 数组（2-2时间线）
| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `date` | string | MM-DD格式 | `"05-09"` |
| `title` | string | 事件标题 | `"腾讯云调价5%"` |
| `source` | string | 格式：`来源：机构名，MM-DD` | `"来源：腾讯云官网，05-09"` |
| `impact` | string | >80字影响分析 | `"..."` |

#### `data_table` 对象（2-1对比表）
| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| `prev` | string | 上周数据含单位 | `"$28,500/卡"` |
| `curr` | string | 本周数据含单位 | `"$29,500/卡"` |
| `time_dim` | string | 三选一 | `"周环比"` |
| `change_pct` | float | 变化率数值 | `3.51` |
| `unit` | string | 单位 | `"$/卡"` |
| `analysis` | string | >100字深度分析 | `"..."` |

---

## 报告结构（全部小节必须完整）

```
2-1 本周核心数据速览
  - data_table（data_cards由脚本根据data_table自动生成，每行analysis>100字，time_dim必填）

2-2 一周市场动态综述（timeline，≥5条，每条impact>80字）

2-3 市场规模驱动因素周变化分析
  - 2-3-1 市场规模整体分析（>200字）
  - 2-3-2 芯片供应链与价格分析（>200字）
  - 2-3-3 需求结构变化分析（>200字）
  - 2-3-4 区域市场分化分析（>200字）

2-4 细分市场周度数据对比
  - 2-4-1 按算力类型：训练vs推理（>200字）
  - 2-4-2 按地域：东部vs西部（>200字）
  - 2-4-3 按应用场景（>200字）

2-5 竞争格局周度动态
  - 2-5-1 云服务商动态（>200字）
  - 2-5-2 专业算力服务商（>200字）
  - 2-5-3 智算中心（>200字）

2-6 本周重大事件深度分析
  - 至少1个deep-event专题，每专题>400字

2-7 市场规模预测更新
  - 预报网格（4张卡片）
  - 重点关注事项（3-5条，每条>80字）
  - 市场综述（>200字）

2-8 一周要闻汇总表（news数组，≥8条）
```

---

## 检索规范（强制）

**本周周期：{CURRENT_PERIOD}**（提示：按运行日期自动计算最新期数）

检索词（必须用当月）：
```
"H100 GPU 价格 {CURRENT_YEAR}年{CURRENT_MONTH}"
"阿里云 算力 涨价 {CURRENT_YEAR}年{CURRENT_MONTH}"
"智算中心 新建 投产 {CURRENT_YEAR}年{CURRENT_MONTH}"
"AI Token 消耗量 {CURRENT_YEAR}年{CURRENT_MONTH}"
"英伟达 GPU 供应 {CURRENT_YEAR}年{CURRENT_MONTH}"
"算力市场规模 {CURRENT_YEAR}年{CURRENT_MONTH}"
"国产AI芯片 昇腾 {CURRENT_YEAR}年{CURRENT_MONTH}"
"算电协同 试点 {CURRENT_YEAR}年{CURRENT_MONTH}"
```

**本周必有的4类数据（不能跳过）：**
1. H100/H200/A100实时价格
2. ≥2家云厂商调价公告
3. 本周新开工/投产项目
4. 本周新政策发布

---

## 常见错误与防范

### 错误1：字段名自创（最常见Bug）
**现象**：`news`数组写了`{title, star, summary}`，导致2-8表空
**防范**：严格按上表字段名填写，不得使用title/star/summary等自创字段

### 错误2：时间维度混淆
**现象**：年度数据标"周环比+40%"
**防范**：`time_dim`字段三选一

### 错误3：子章节内容空洞
**现象**：2-5-2等小节只有一两句话
**防范**：`content_2_X`参数每个h3小节>200字

### 错误4：analysis字数不足
**现象**：data_table每行只有一句话
**防范**：每行analysis>100字，必须有数字+原因+影响

### 错误5：检索词用旧月份
**现象**：检索词使用了过期月份（如未更新为当前月）
**防范**：每次生成前更新检索词为当前月

### 错误6：data_table中value/prev字段带单位，unit字段又重复填单位
**现象**：value="约6.5万元/月/卡"，unit="万元/月/卡"，渲染出来是"约6.5万元/月/卡万元/月/卡"（单位重复）
**防范**：unit字段只填单位符号（如"$/卡"、"EFLOPS"、"亿元/季度"），value/prev只填数值部分，数值里的前缀符号（如"约"、"突破"）写在value里但不要把完整单位重复写进去

### 错误7：data_cards风格 vs data_table风格混用导致字段名错误
**防范**：严格区分两种风格

**风格A：data_table（用于2-1对比表，脚本自动从中提取生成data-cards）**
```json
{
  "data_table": {
    "H100 GPU租赁价格（国产）": {
      "prev": "约5.8",
      "curr": "约6.5",
      "unit": "万元/月/卡",
      "change_pct": 12.1,
      "time_dim": "周环比",
      "analysis": "本周国产H100价格持续上涨..."
    },
    "中国智能算力规模": {
      "prev": "1010.0",
      "curr": "1037.3",
      "unit": "EFLOPS",
      "change_pct": 2.7,
      "time_dim": "月环比",
      "analysis": "..."
    }
  }
}
```
**⚠️ 注意：prev/curr只写纯数字或带"约/突破/超"等前缀词，绝不包含unit里的单位文字！**

**风格B：data_cards（独立数据卡片，用于特殊展示）**
```json
{
  "data_cards": [
    {
      "label": "H100 GPU租赁价格（国产）",
      "value": "约6.5",
      "unit": "万元/月/卡",
      "prev": "约5.8",
      "change_str": "↑ +12.1%（周环比）"
    }
  ]
}
```
**⚠️ 注意：value只写数值部分，unit只写单位文字，两者绝不重叠！**

### 错误8：unit单位书写错误或不完整
**防范**：unit字段必须是完整的、可直接渲染的单位字符串
- ✅ unit: "万元/月/卡"（正确，渲染出来是"约6.5<span class='unit'>万元/月/卡</span>"）
- ❌ unit: "万/月/卡"（缺失"元"）
- ❌ unit: "万元/月"（缺失"卡"）
- ❌ unit: "元/卡/月"（顺序错误，应是"万元/月/卡"）

---

## 验证输出

- 文件 > 25KB
- 章节2-1~2-8全部存在
- 所有h3小节有内容（不是空的）
- data_table每行analysis>100字
- news数组每条有event/subject/scale（不是空的）
- 无"暂无重大更新"等空洞表述

**⚠️ 防御性清洗（硬约束，LRN-20260821-001）：**

1. **HTML 内容文件严禁使用 `json.dump()` 写入** —— 会导致真实换行 0x0A 被 JSON 规范转义为 `\n` 两字符（JSON 字符串内转义）；后续通过 `f.read()` 读取后传入脚本会注入转义符
2. **禁止用 `f.read()` 读取 JSON 文件作为 `--content_X` 参数** —— JSON 文件首尾自带外层引号（`"..."`），`f.read()` 会带入；脚本 `decode_arg` 已升级兜底
3. **HTML 内容写入前必须自检**：
   ```bash
   grep -c '\\n' /tmp/content_*.html  # 真实合法 \\n 数为 0（必须用 <br> 标签代替）
   head -c 1 /tmp/content_*.html | grep -c '"'  # 首字符不为 "（0 = 正确）
   ```
4. **脚本 `decode_arg` 防御性兜底**（已升级，LRN-20260821-001）：自动剥离首尾多余引号 + 把 `\n` 两字符还原为真实换行。即便 subagent 错误使用 `json.dump` 写入，依然不污染 HTML
