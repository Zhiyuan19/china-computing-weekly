---
name: china-computing-technology-weekly-report
description: 生成中国智能算力报告第五章（技术趋势分析）周更报告。当用户要求生成智算/算力/AI芯片/数据中心等技术趋势周报时自动调用。触发场景：(1) 用户要求生成技术趋势分析报告；(2) 用户要求生成第五章技术趋势周报；(3) 用户提到芯片技术对比、超节点、液冷、推理场景等技术关键词。
metadata:
  clawdbot:
    emoji: 🔬
    requires:
      anyBins:
        - python3
---

> ⚠️ **本 skill 的所有命令假设工作目录为 `~/.openclaw/workspace/`**（即 openclaw workspace 根目录）。如从其他目录运行，请先 `cd ~/.openclaw/workspace`。

# 中国智算技术趋势周报生成技能

## 核心定位

**骨架模板文件：**
```
skills/china-computing-technology-weekly-report/template/chapter5_skeleton.html
```

---

## ⚠️ 文件写入策略（必须遵守）

**模型输出流截断阈值约1027字符**，超过后工具调用参数不完整。**禁止直接生成大段HTML作为write参数**，会因截断导致文件不完整。

**必须采用两阶段模式：**
```
子agent步骤：
  1. write → /tmp/report_args.json（数据JSON，小文件<10KB，不会截断）
  2. write → /tmp/content_5_1.html 等（HTML片段，每个2-3KB，不会截断）
  3. exec → python3 scripts/generate_chapter5_report.py（读取小文件→脚本生成完整HTML）
  4. 验证输出文件 > 20KB
```

**核心规则：** 写文件的是Python脚本，不是模型输出流。模型只负责写小文件+调用脚本。

**⚠️ 写入协议一致性（强制）：** JSON数据文件用 `json.dump()` 写 + `json.load()` 读；HTML内容文件用 `f.write()` 写纯文本 + `f.read()` 读。**禁止**对内容字符串再次 `json.dumps()` 编码后传参。
**⚠️ 防御性清洗（硬约束，LRN-20260821-001）：**

1. **HTML 内容文件严禁使用 `json.dump()` 写入** —— 会导致真实换行 0x0A 被 JSON 规范转义为 `\n` 两字符（JSON 字符串内转义）；后续通过 `f.read()` 读取后传入脚本会注入转义符
2. **禁止用 `f.read()` 读取 JSON 文件作为 `--content_X` 参数** —— JSON 文件首尾自带外层引号（`"..."`），`f.read()` 会带入；脚本 `decode_arg` 已升级兜底
3. **HTML 内容写入前必须自检**：
   ```bash
   grep -c '\\n' /tmp/content_*.html  # 真实合法 \\n 数为 0（必须用 <br> 标签代替）
   head -c 1 /tmp/content_*.html | grep -c '"'  # 首字符不为 "（0 = 正确）
   ```
4. **脚本 `decode_arg` 防御性兜底**（已升级，LRN-20260821-001）：自动剥离首尾多余引号 + 把 `\n` 两字符还原为真实换行。即便 subagent 错误使用 `json.dump` 写入，依然不污染 HTML


---

> ⚠️ **HTML布局排版规范：** 每周生成的报告 HTML 必须与 `chapter5_skeleton.html` 保持100%一致。骨架文件包含完整 HTML/CSS 结构，所有数据插槽以 `{{CONTENT_5_1}}`、`{{TIMELINE}}` 等占位符标注，由脚本运行时填充。CSS 样式已内嵌在骨架文件中，不得自行修改样式规则。模板文件单独保存在 `template/` 目录，报告目录只存放每周生成的报告 HTML 文件。

---

本技能生成**完整报告第五章的技术趋势分析周报**，章节序号从 **5-1、5-2、5-3…** 开始。HTML 格式骨架基准为 `template/chapter5_skeleton.html`，严格保持结构一致。

**本技能的核心原则：**
- 优先使用最新一周（≤7天）数据，若一周内无新数据则回退到月变化（≤30天）、季变化或年变化，但**必须明确标注时间维度**
- 每个技术方向都要交代清楚：**当前技术状态、为什么变化、对竞争格局意味着什么**
- 时间维度标注是强规则，详见下方规范

---

## 时间维度标注规则（强制）

时间维度分四档，颜色区分：

| 时间维度 | 颜色 | 样式 | 适用场景 |
|----------|------|------|----------|
| **周变化（≤7天）** | 绿色背景 | `<span class="time-dim" style="background:#c8e6c9;color:#1b5e20">周变化（本周）</span>` | 本周有明确事件/价格/发布 |
| **月变化（8-30天）** | 黄色背景 | `<span class="time-dim" style="background:#fff9c4;color:#f57f17">月变化</span>` | 本月有发布/数据，季度数据对比 |
| **周变化（≤7天）** | 浅绿背景 + 深绿字 | `<span class="time-dim" style="background:#c8e6c9;color:#1b5e20">周变化（本周）</span>` | 本周有明确事件/价格/发布 |
| **月变化（8-30天）** | 浅黄背景 + 橙色字 | `<span class="time-dim" style="background:#fff9c4;color:#f57f17">月变化</span>` | 本月有发布/数据，季度数据对比 |
| **季变化/年变化** | 浅红背景 + 深红字 | `<span class="time-dim" style="background:#fce4ec;color:#c62828">季变化</span>` 或 `<span class="time-dim" style="background:#fce4ec;color:#c62828">年变化</span>` | 季度或年度统计数据，无周数据时使用 |
| **持续/无直接数据** | 深灰背景 + 白字 | `<span class="time-dim" style="background:#888;color:#fff">持续</span>` | 长期趋势无明确时间切点 |

**规则：**
1. 有本周新数据 → 标注"周变化（本周）"（绿色）
2. 无本周数据但有月度内新事件 → 标注"月变化"（黄色）
3. 季度数据/年度统计 → 标注"季变化"或"年变化"（灰色）
4. **严禁**将季度/年化数据标为"周环比"或"本周"
5. 每个表格**必须包含"时间维度"列**

---

## 骨架模板占位符说明

`chapter5_skeleton.html` 中各占位符含义：

| 占位符 | 含义 | 格式说明 |
|--------|------|---------|
| `{{WEEK_NUMBER}}` | 周报期号 | 如"第16期" |
| `{{DATE}}` | 报告日期 | YYYY-MM-DD |
| `{{CHAPTER_OVERVIEW}}` | 本章关键概述 | 一段HTML文字 |
| `{{DATA_NOTE}}` | 数据说明条 | 由脚本自动生成 |
| `{{TIMELINE}}` | 本周技术时间线 | 8条以内，`build_timeline()` 格式 |
| `{{CONTENT_5_1}}` | 5-1章节正文 | HTML片段 |
| `{{CONTENT_5_2}}` | 5-2章节正文 | HTML片段 |
| `{{CONTENT_5_3}}` | 5-3章节正文 | HTML片段 |
| `{{CONTENT_5_4}}` | 5-4章节正文 | HTML片段 |
| `{{CONTENT_5_5}}` | 5-5章节正文 | HTML片段 |
| `{{CONTENT_5_6}}` | 5-6章节正文 | HTML片段（本周深度专题） |
| `{{NEWS_TABLE}}` | 要闻汇总表格行 | `build_news_table()` 格式 |
| `{{SOURCES}}` | 数据来源列表 | `build_sources()` 格式 |

---

## 报告结构

```
5-1  AI芯片技术发展趋势
  - 训练芯片 vs 推理芯片 vs 训推一体
  - 推理算力占比趋势（66%预测背景）
  
5-2  国际 vs 国产 AI 芯片技术矩阵对比
  - NVIDIA产品代际（B200/H200/H100/A100/L40S参数表，含时间维度）
  - 中国特供芯片（H20/L20规格对比）
  - 国产芯片全矩阵（昇腾910B/910C/950、寒武纪590/370、燧原L600、沐曦C600等）
  - 深度文字分析（100-150字/表）

5-3  超节点技术演进
  - 国际主流超节点（GB200 NVL72、DGX SuperPOD）
  - 国产超节点（昇腾Atlas 950 SuperPoD、燧原ESL32/64）
  - 深度文字分析

5-4  数据中心冷却技术
  - 风冷 vs 冷板式液冷 vs 浸没式液冷（PUE对比表）
  - 本周液冷动态（如有）
  - 深度文字分析

5-5  推理场景深度分析与芯片选择
  - 五类场景：云端大模型推理 / AI Agent / 多模态 / 边缘推理 / 垂直行业
  - 各场景芯片选择表（含时间维度标注）

5-6  本周技术深度分析专题（每周核心亮点）
  - 本周最具影响力的技术事件深度剖析
  - 基于本周检索的最新动态
```

---

## 数据获取流程

### 第一步：并行检索最新一周技术动态（6个检索并发）

```python
queries = [
    "AI芯片技术突破 {CURRENT_YEAR}年{CURRENT_MONTH}",
    "英伟达/华为/寒武纪芯片发布 {CURRENT_YEAR}年{CURRENT_MONTH}",
    "超节点技术液冷技术动态 {CURRENT_YEAR}年{CURRENT_MONTH}",
    "推理芯片市场格局变化 {CURRENT_YEAR}年{CURRENT_MONTH}",
    "国产AI芯片进展 DeepSeek适配 {CURRENT_YEAR}年{CURRENT_MONTH}",
    "智算中心技术选型趋势 {CURRENT_YEAR}年{CURRENT_MONTH}",
]
```

使用 `tavily_search` 并行执行，`max_results=5`，`search_depth="advanced"`，`time_range="week"`。

### 第二步：补充月/季度数据（当本周数据不足时）

- 周变化（≤7天）：直接使用，标注绿色
- 月变化（8-30天）：使用最近一个月内有明确时间的数据，标注黄色
- 季变化/年变化：使用IDC/厂商财报/年报数据，标注灰色

### 第三步：数据整合与时间维度标注

示例：
- ✅ "本周DeepSeek V4适配昇腾950PR，周变化（本周）"
- ⚠️ "浪潮服务器份额约40%，季变化（IDC 2025Q4数据）——本周无直接周数据"
- ❌ "英伟达中国份额55%，周环比+5%"（严禁将季度数据标为周变化）

---

## 生成调用方式

```bash
python3 skills/china-computing-technology-weekly-report/scripts/generate_chapter5_report.py \
    --date "{REPORT_DATE}" \
    --date_from "{PERIOD_START}" \
    --week_number "{WEEK_NUMBER}" \
    --chapter_overview "本周是国产算力生态破局的历史性节点..." \
    --timeline_json '[{"date":"04-21","title":"DeepSeek V4适配昇腾950PR","source":"财经","impact":"..."}]' \
    --news_json '[{"date":"04-21","event":"...","subject":"DeepSeek/华为","importance":5}]' \
    --sources_json '["来源1","来源2"]' \
    --content_5_1 "<h3>5-1-1...</h3><p>...</p>..." \
    --content_5_2 "..." \
    --content_5_3 "..." \
    --content_5_4 "..." \
    --content_5_5 "..." \
    --content_5_6 "<div class=\"deep-event\">...</div>" \
    --output "report/技术趋势发展分析报告.html"
```

### 推荐方式：文件+脚本两阶段模式

由于模型输出流限制，大段内容分两步传递：

```python
import json, sys
sys.path.insert(0, 'skills/china-computing-technology-weekly-report/scripts')
import generate_chapter5_report as g

with open('/tmp/ch5_week_data.json') as f:
    d = json.load(f)

html = g.fill_skeleton(
    week_number=d['week_number'],
    date=d['date'],
    date_from=d['date_from'],
    timeline_html=g.build_timeline(d['timeline']),
    sources_list_html=g.build_sources(d['sources']),
    content_5_1=d['content_5_1'],
    content_5_2=d['content_5_2'],
    content_5_3=d['content_5_3'],
    content_5_4=d['content_5_4'],
    content_5_5=d['content_5_5'],
    content_5_6=d['content_5_6'],
    news_table_html=g.build_news_table(d['news']),
    chapter_overview=d.get('overview', ''),
)
```

---

## 深度文字分析规范

每个数据表后**必须**包含80-150字深度分析：

```html
<div class="analysis-box">
<h4>驱动力（时间维度标注）</h4>
<p>本周[数据源]显示[具体数字]，[时间维度明确标注]。[变化原因]。[对竞争格局的影响]。</p>
</div>
```

---

## 技能文件清单

```
china-computing-technology-weekly-report/
├── SKILL.md                          ← 本说明文件
├── template/
│   └── chapter5_skeleton.html        ← HTML骨架模板（约10KB，{{}}占位符）
└── scripts/
    ├── generate_chapter5_report.py   ← 生成脚本（v5，骨架驱动）
    └── __pycache__/
```

---

## 验证清单

生成后验证：
- [ ] 文件大小 >25KB
- [ ] 章节 5-1 到 5-6 齐全，H2 标题正确
- [ ] 每个表格有"时间维度"列
- [ ] `.time-dim` 标签数量 ≥10
- [ ] `.analysis-box` 深度分析 ≥4处
- [ ] 无"周环比"误标（季度数据标为季变化而非周变化）
- [ ] `.chapter-nav` 翻页导航正常
- [ ] 旧数据（上周内容）无残留
- [ ] `{{` 占位符无残留
