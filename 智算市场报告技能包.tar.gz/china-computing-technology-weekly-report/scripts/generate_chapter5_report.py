#!/usr/bin/env python3
"""
中国智算技术趋势周报HTML生成脚本 v5
骨架模板：../template/chapter5_skeleton.html（CSS已内嵌，{{}}占位符精确替换）
运行时读取骨架，填充本周数据，输出干净HTML
"""

import argparse, json, os, re
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(__file__)
SKELETON_PATH = os.path.join(SCRIPT_DIR, "..", "template", "chapter5_skeleton.html")

with open(SKELETON_PATH, "r", encoding="utf-8") as f:
    SKELETON = f.read()


def build_timeline(tl_data):
    """构建时间线 HTML，按日期降序（最新优先）"""
    # 按日期降序排列：最新日期排在最前
    sorted_data = sorted(tl_data, key=lambda x: x.get("date", ""), reverse=True)
    items = []
    for item in sorted_data:
        impact = item.get("impact") or item.get("content", "")
        date = item.get("date", "")
        title = item.get("title", "")
        source = item.get("source", "")
        items.append(
            f'<div class="timeline-item">'
            f'<div class="timeline-date">{date}</div>'
            f'<div class="timeline-title">{title}</div>'
            f'<div class="timeline-source">来源：{source}</div>'
            f'<div class="timeline-impact">{impact}</div>'
            f'</div>'
        )
    return "\n".join(items)


def build_news_table(news_data):
    """构建要闻汇总表格行，按日期降序（最新优先）"""
    sorted_data = sorted(news_data, key=lambda x: x.get("date", ""), reverse=True)
    rows = []
    for n in sorted_data:
        stars = "★" * n.get("importance", 1)
        date = n.get("date", "")
        event = n.get("event", "")
        subject = n.get("subject", "")
        rows.append(
            f'<tr>'
            f'<td>{date}</td>'
            f'<td>{event}</td>'
            f'<td>{subject}</td>'
            f'<td style="color:#f59e0b">{stars}</td>'
            f'</tr>'
        )
    return "\n".join(rows)


def build_sources(sources_list):
    """构建数据来源列表项"""
    items = []
    for s in sources_list:
        items.append(
            f'<li style="padding:5px 0;font-size:12px;color:#555;border-bottom:1px solid #f0f0f0;">{s}</li>'
        )
    return "\n".join(items)


def data_note_html(date_from, date):
    """生成数据说明条"""
    return (
        f'<div class="data-note">'
        f'<strong>数据说明：</strong>本章聚焦最近7天（{date_from}—{date}）技术趋势变化，'
        f'对比上月/季度数据（<span class="time-dim" style="background:#fff9c4;color:#f57f17">月变化</span>）及年度数据（<span class="time-dim" style="background:#fce4ec;color:#c62828">年变化</span>）进行对照分析。'
        f'时间维度标注：绿色=本周有直接数据；黄色=月内数据；灰色=季度/年度数据。'
        f'</div>'
    )


def fill_skeleton(
    week_number, date, date_from,
    timeline_html,
    content_5_1, content_5_2, content_5_3,
    content_5_4, content_5_5, content_5_6,
    news_table_html, sources_list_html,
    chapter_overview=""
):
    """将所有占位符替换为实际内容，生成最终HTML"""
    replacements = {
        "{{WEEK_NUMBER}}": week_number,
        "{{DATE}}": date,
        "{{CHAPTER_OVERVIEW}}": chapter_overview or "<p>本章关键技术趋势分析详见各章节。</p>",
        "{{DATA_NOTE}}": data_note_html(date_from, date),
        "{{TIMELINE}}": timeline_html or "",
        "{{CONTENT_5_1}}": content_5_1 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_5_2}}": content_5_2 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_5_3}}": content_5_3 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_5_4}}": content_5_4 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_5_5}}": content_5_5 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_5_6}}": content_5_6 or "<p>本周无重大技术事件需深度分析。</p>",
        "{{NEWS_TABLE}}": news_table_html,
        "{{SOURCES}}": sources_list_html,
    }

    html = SKELETON
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html


def main():
    parser = argparse.ArgumentParser(description="生成中国智算技术趋势周报HTML v5（基于骨架模板）")
    parser.add_argument("--date", required=True, help="报告日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD")
    parser.add_argument("--week_number", default="第X期", help="周报期号")
    parser.add_argument("--timeline_json", default="[]", help="时间线JSON：date/title/source/impact")
    parser.add_argument("--news_json", default="[]", help="要闻JSON：date/event/subject/importance(1-5)")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON")
    parser.add_argument("--chapter_overview", default="", help="本章关键概述段落HTML")
    parser.add_argument("--content_5_1", default="", help="5-1章节HTML内容")
    parser.add_argument("--content_5_2", default="", help="5-2章节HTML内容")
    parser.add_argument("--content_5_3", default="", help="5-3章节HTML内容")
    parser.add_argument("--content_5_4", default="", help="5-4章节HTML内容")
    parser.add_argument("--content_5_5", default="", help="5-5章节HTML内容")
    parser.add_argument("--content_5_6", default="", help="5-6章节HTML内容")
    parser.add_argument("--output", required=True, help="输出HTML路径")

    args = parser.parse_args()

    # 日期范围
    base_date = datetime.strptime(args.date, "%Y-%m-%d")
    prev_week_end = base_date - timedelta(days=1)
    prev_week_start = (prev_week_end - timedelta(days=6)).strftime("%Y-%m-%d")
    date_from = args.date_from or prev_week_start

    # 以下字符串参数从子进程传入（含JSON编码），需反序列化
def decode_arg(s):
        """反序列化通过JSON编码传入的字符串参数；防御性清洗 \\n 两字符 + 残留外层引号

        LRN-20260821-001: subagent 误用 json.dump 写 HTML 内容文件，导致真换行 0x0A
        被 JSON 规范转义为 \\n 两字符；f.read() 读 JSON 文件时带入外层引号。
        decode_arg 防御性兜底：剥离外层引号 + 还原 \\n → 真实换行。
        """
        if not s:
            return ""
        try:
            result = json.loads(s)
        except Exception:
            result = s

        # 防御性清洗：消除 JSON 残留转义
        if isinstance(result, str):
            # 1. 剥离首尾多余引号（subagent 用 f.read() 读 JSON 文件时带入）
            if result.startswith('"') and result.endswith('"'):
                inner = result[1:-1]
                # 内部引号成对（偶数）才剥离
                if inner.count('\\"') % 2 == 0 and inner.count('"') % 2 == 0:
                    result = inner
            # 2. JSON 字符串内的 \\n 转义（两字符）→ 真实换行
            result = result.replace('\\n', '\n')

        return result
if __name__ == "__main__":
    main()
