#!/usr/bin/env python3
"""
中国智算供应商与产业格局周报HTML生成脚本 v5
基准骨架：../template/suppliers_skeleton.html
基准样式：../template/suppliers_template.html（仅提取CSS）
运行时读取骨架，填充本周数据，输出干净HTML
"""

import argparse
import json
import os
import re
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(__file__)
SKELETON_PATH = os.path.join(SCRIPT_DIR, "..", "template", "suppliers_skeleton.html")
CSS_PATH = os.path.join(SCRIPT_DIR, "..", "template", "suppliers_template.html")

# 从 suppliers_template.html 提取纯CSS（<style>标签内容）
with open(CSS_PATH, "r", encoding="utf-8") as f:
    raw = f.read()
css_match = re.search(r'<style>(.*?)</style>', raw, re.DOTALL)
CSS_CONTENT = css_match.group(1) if css_match else ""

# 读取骨架模板
with open(SKELETON_PATH, "r", encoding="utf-8") as f:
    SKELETON = f.read()


def build_data_cards(cards):
    """生成数据卡片 HTML"""
    html = ''
    for c in cards:
        tag_class = c.get('tag_class', 'up')
        tag_text = c.get('tag_text', '周变化')
        change = c.get('change', '')
        html += (
            f'<div class="data-card">\n'
            f'    <div class="label">{c.get("label", "")}</div>\n'
            f'    <div class="value">{c.get("value", "")}</div>\n'
            f'    <div class="tag {tag_class}">{tag_text}</div>'
            f'    <div class="tag-note">{change}</div>\n'
            f'</div>\n'
        )
    return html


def build_timeline(timeline_data):
    """生成时间线 HTML（按日期倒序）"""
    # 按日期倒序（新到旧）排列
    sorted_data = sorted(timeline_data, key=lambda x: x.get("date", ""), reverse=True)
    items = []
    for item in sorted_data:
        impact_text = item.get('impact') or item.get('content', '')
        date_text = item.get('date', '')
        title_text = item.get('title', '')
        source_text = item.get('source', '')
        items.append(
            f'<div class="timeline-item">'
            f'<div class="timeline-date">{date_text}</div>'
            f'<div class="timeline-title">{title_text}</div>'
            f'<div class="timeline-source">来源：{source_text}</div>'
            f'<div class="timeline-impact">{impact_text}</div>'
            f'</div>'
        )
    return '\n'.join(items)


def build_sources(sources):
    """生成来源列表 HTML"""
    return '\n'.join(f'<li>{s}</li>' for s in sources)


def fill_skeleton(
    week_number, date, date_range,
    data_cards, timeline_html,
    chapter_overview,
    content_6_1, content_6_2, content_6_2_hbm,
    content_6_3, content_6_3_b,
    content_6_4, content_6_4_b,
    content_6_5, content_6_6,
    sources_list
):
    """将所有占位符替换为实际内容，生成最终HTML"""
    year = date[:4]

    replacements = {
        "{{WEEK_NUMBER}}": week_number,
        "{{DATE}}": date,
        "{{DATE_RANGE}}": date_range,
        "{{CHAPTER_OVERVIEW}}": chapter_overview or "<p>本章关键概述详见各章节分析。</p>",
        "{{DATA_CARDS}}": data_cards,
        "{{TIMELINE}}": timeline_html,
        "{{CONTENT_6_1}}": content_6_1 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_2}}": content_6_2 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_2_HBM}}": content_6_2_hbm or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_3}}": content_6_3 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_3_B}}": content_6_3_b or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_4}}": content_6_4 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_4_B}}": content_6_4_b or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_5}}": content_6_5 or "<p>本周暂无重大更新。</p>",
        "{{CONTENT_6_6}}": content_6_6 or "<p>本周暂无重大更新。</p>",
        "{{SOURCES}}": build_sources(sources_list),
        "{{YEAR}}": year,
    }

    html = SKELETON
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    # 注入 CSS
    html = html.replace("{{STYLE_CSS}}", CSS_CONTENT)

    return html


def main():
    parser = argparse.ArgumentParser(description="生成中国智算供应商与产业格局周报HTML v5（基于骨架模板）")
    parser.add_argument("--date", required=True, help="报告日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD")
    parser.add_argument("--week_number", default="第X期", help="周报期号")
    parser.add_argument("--data_cards_json", default="[]", help="数据卡片JSON列表")
    parser.add_argument("--timeline_json", default="[]", help="时间线JSON列表")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON列表")
    parser.add_argument("--chapter_overview", default="", help="本章关键概述段落")
    parser.add_argument("--content_6_1", default="", help="6-1章节HTML内容")
    parser.add_argument("--content_6_2", default="", help="6-2芯片章节HTML内容")
    parser.add_argument("--content_6_2_hbm", default="", help="6-2 HBM章节HTML内容")
    parser.add_argument("--content_6_3", default="", help="6-3云厂商章节HTML内容")
    parser.add_argument("--content_6_3_b", default="", help="6-3算力租赁章节HTML内容")
    parser.add_argument("--content_6_4", default="", help="6-4供应链挑战章节HTML内容")
    parser.add_argument("--content_6_4_b", default="", help="6-4国产化章节HTML内容")
    parser.add_argument("--content_6_5", default="", help="6-5章节HTML内容")
    parser.add_argument("--content_6_6", default="", help="6-6深度专题章节HTML内容")
    parser.add_argument("--output", required=True, help="输出HTML路径")
    args = parser.parse_args()

    # 解析JSON
    data_cards = json.loads(args.data_cards_json)
    timeline_data = json.loads(args.timeline_json)
    sources_list = json.loads(args.sources_json)

    # 以下参数从JSON字符串传入（shell转义会破坏Unicode），统一用json.loads解码
def decode_arg(s):
        """反序列化通过JSON编码传入的字符串参数；防御性清洗 \\n 两字符 + 残留外层引号

        LRN-20260821-001: subagent 误用 json.dump 写 HTML 内容文件，导致真换行 0x0A
        被 JSON 规范转义为 \\n 两字符；f.read() 读 JSON 文件时带入外层引号。
        decode_arg 防御性兜底：剥离外层引号 + 还原 \\n → 真实换行。
        """
        if not s:
            return ""
        try:
            result = json.loads(s)
        except Exception:
            result = s

        # 防御性清洗：消除 JSON 残留转义
        if isinstance(result, str):
            # 1. 剥离首尾多余引号（subagent 用 f.read() 读 JSON 文件时带入）
            if result.startswith('"') and result.endswith('"'):
                inner = result[1:-1]
                # 内部引号成对（偶数）才剥离
                if inner.count('\\"') % 2 == 0 and inner.count('"') % 2 == 0:
                    result = inner
            # 2. JSON 字符串内的 \\n 转义（两字符）→ 真实换行
            result = result.replace('\\n', '\n')

        return result
if __name__ == "__main__":
    main()