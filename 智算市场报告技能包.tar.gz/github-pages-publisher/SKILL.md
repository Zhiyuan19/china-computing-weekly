---
name: github-pages-publisher
description: 将中国智算市场周报HTML报告推送至GitHub Pages。当用户要求推送报告到GitHub、发布周报、上传报告到GitHub Pages时使用。
---

# GitHub Pages 推送技能

## 配置信息

- **仓库**：`https://github.com/Zhiyuan19/china-computing-weekly`
- **分支**：`main`
- **报告目录**：`/home/clawhelper/.openclaw/workspace/report/`
- **Token**：环境变量 `GITHUB_TOKEN`（需 `Contents: Read and write` 权限）

## 使用方式

```bash
export GITHUB_TOKEN=ghp_你的token
python3 /home/clawhelper/.openclaw/workspace/skills/github-pages-publisher/scripts/push_github.py
```

## 前置条件（GitHub 仓库侧，只需配一次）

打开 https://github.com/Zhiyuan19/china-computing-weekly/settings/pages

- **Source**：`Deploy from a branch`
- **Branch**：`main` / `(root)`
- **仓库 Settings → Actions → General → Workflow permissions**：`Read and write permissions`（虽然不跑 Actions，但保留以便未来扩展）

## 功能说明

- 通过 GitHub Contents API 直接推送文件到 main 分支，无需 git-remote-https
- **自动发现文件**：扫描报告目录下所有文件，无需手动维护推送列表
- **自动创建 `.nojekyll`**：跳过 Jekyll 渲染，避免复杂 HTML 导致构建卡死
- **自动更新**：推送前先获取 SHA，已存在则更新
- **失败立即报错**：任一文件失败则进程退出码非零
- 访问地址：`https://zhiyuan19.github.io/china-computing-weekly/`

## 故障排查

| 现象 | 原因 | 解决 |
|---|---|---|
| 网站内容是旧版本 | Pages build 没完成 / 卡住 | 等 1-2 分钟；或加 `.nojekyll` 后重推 |
| HTTP 200 但 last-modified 是几天前 | 仓库未触发 build | 任意改一个文件并 push 触发 |
| `Page build failed` | Jekyll 渲染失败 | 确认 `.nojekyll` 已推送 |
| 推送全 401 | Token 无效或过期 | 重新生成 token |

## 文件结构

```
github-pages-publisher/
├── SKILL.md
└── scripts/
    └── push_github.py   # 唯一推送脚本
```

> 旧版本曾有 `publish.sh`（推送 gh-pages 分支）和 `config.sh`，与 GitHub Actions 模式冲突，已废弃删除。