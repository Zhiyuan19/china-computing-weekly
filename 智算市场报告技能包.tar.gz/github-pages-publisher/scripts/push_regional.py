#!/usr/bin/env python3
"""push_regional.py — 单独推送区域算力发展分析报告到独立 GitHub Pages。

与 push_github.py 的区别：
- 目标仓库独立：Zhiyuan19/china-computing-regional（区别于完整版 china-computing-weekly）
- 单文件推送：仅 区域算力发展分析报告.html（不污染完整版基线）
- 额外生成 index.html + README.md，让根路径可访问
- 仓库 + Pages 配置一体化
"""
import base64, os, sys, json
from pathlib import Path

REPO = "china-computing-regional"
OWNER = "Zhiyuan19"
BRANCH = "main"
DESCRIPTION = "中国智算市场周报·区域算力发展分析（单独部署版）"
SOURCE_HTML = Path("/home/clawhelper/.openclaw/workspace/report/区域算力发展分析报告.html")
README_MD = Path("/home/clawhelper/.openclaw/workspace/report/区域算力发展分析报告.README.md")

API_REPO = f"https://api.github.com/repos/{OWNER}/{REPO}"
API_USER_REPOS = "https://api.github.com/user/repos"
API_PAGES = f"https://api.github.com/repos/{OWNER}/{REPO}/pages"


def auth_headers(token: str) -> dict:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "AI-Agent/regional-pages/1.0",
    }


def req(method: str, url: str, headers: dict, json_body: dict | None = None,
        timeout: int = 30):
    import requests
    if json_body is not None:
        r = requests.request(method, url, headers=headers, json=json_body, timeout=timeout)
    else:
        r = requests.request(method, url, headers=headers, timeout=timeout)
    return r


def ensure_repo(token: str, headers: dict) -> tuple[int, str]:
    """创建仓库（已存在则跳过），返回 (status, message)。"""
    r = req("GET", API_REPO, headers)
    if r.status_code == 200:
        return 200, "仓库已存在"
    if r.status_code != 404:
        return r.status_code, f"GET repo failed: {r.text[:300]}"
    payload = {
        "name": REPO,
        "description": DESCRIPTION,
        "private": False,
        "auto_init": False,
        "has_issues": False,
        "has_projects": False,
        "has_wiki": False,
    }
    r = req("POST", API_USER_REPOS, headers, payload, timeout=45)
    return r.status_code, r.text[:300] if r.status_code not in (201, 202) else "OK"


def put_file(headers: dict, path_in_repo: str, content_bytes: bytes,
             commit_msg: str) -> tuple[int, str]:
    """PUT /contents/{path}，含 SHA 获取与更新逻辑。"""
    sha = None
    r = req("GET", f"{API_REPO}/contents/{path_in_repo}?ref={BRANCH}", headers)
    if r.status_code == 200:
        sha = r.json().get("sha")
    elif r.status_code != 404:
        return r.status_code, f"GET sha failed: {r.text[:300]}"

    payload = {
        "message": commit_msg,
        "content": base64.b64encode(content_bytes).decode(),
        "branch": BRANCH,
    }
    if sha:
        payload["sha"] = sha

    r = req("PUT", f"{API_REPO}/contents/{path_in_repo}", headers, payload)
    return r.status_code, r.text[:300] if r.status_code not in (200, 201) else "OK"


def ensure_pages(headers: dict) -> tuple[int, str]:
    """启用 Pages，Source = main 分支 /root。"""
    r = req("GET", API_PAGES, headers)
    if r.status_code == 200:
        return 200, "Pages 已启用"
    payload = {"source": {"branch": BRANCH, "path": "/"}}
    r = req("POST", API_PAGES, headers, payload, timeout=45)
    return r.status_code, r.text[:300] if r.status_code not in (200, 201) else "OK"


def main() -> int:
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("❌ 请先 export GITHUB_TOKEN=***", file=sys.stderr)
        return 2
    if not SOURCE_HTML.exists():
        print(f"❌ 源文件不存在: {SOURCE_HTML}", file=sys.stderr)
        return 2

    headers = auth_headers(token)
    html_bytes = SOURCE_HTML.read_bytes()
    readme_bytes = README_MD.read_bytes() if README_MD.exists() else b"# China Computing Regional\n"

    print(f"=== 单独部署区域算力报告到 {OWNER}/{REPO} ===\n")

    # Step 1: 确保仓库存在
    print("[1/4] 创建/确认仓库…")
    status, msg = ensure_repo(token, headers)
    print(f"    {status} {msg}")
    if status not in (200, 201, 202):
        return 1

    # Step 2: 推送 4 个文件
    files = [
        ("区域算力发展分析报告.html", html_bytes, "Upload regional computing report"),
        ("index.html", html_bytes, "Mirror as index.html for root access"),
        (".nojekyll", b"", "Add .nojekyll to bypass Jekyll"),
        ("README.md", readme_bytes, "Add README.md"),
    ]
    print(f"[2/4] 推送 {len(files)} 个文件…")
    failed = []
    for name, content, msg in files:
        print(f"    >>> {name} ({len(content)} bytes)")
        status, m = put_file(headers, name, content, msg)
        print(f"        PUT {status} {m if status not in (200, 201) else 'OK'}")
        if status not in (200, 201):
            failed.append(name)

    if failed:
        print(f"\n❌ {len(failed)} 个文件失败: {', '.join(failed)}", file=sys.stderr)
        return 1

    # Step 3: 启用 Pages
    print("[3/4] 启用 Pages…")
    status, msg = ensure_pages(headers)
    print(f"    {status} {msg}")
    if status not in (200, 201):
        return 1

    # Step 4: 输出访问地址
    print(f"\n[4/4] 部署完成")
    pages_url = f"https://{OWNER}.github.io/{REPO}/"
    print(f"✅ 仓库：https://github.com/{OWNER}/{REPO}")
    print(f"✅ 根访问（index.html）：{pages_url}")
    print(f"✅ 原文件名访问：{pages_url}区域算力发展分析报告.html")
    print(f"⏱  Pages 部署约 1-2 分钟生效")
    return 0


if __name__ == "__main__":
    sys.exit(main())