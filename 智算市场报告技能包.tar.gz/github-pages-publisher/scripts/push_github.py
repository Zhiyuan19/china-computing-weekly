#!/usr/bin/env python3
"""push_github.py — 推送周报报告到 GitHub Pages (china-computing-weekly)。

自动发现 /home/clawhelper/.openclaw/workspace/report/ 下的所有文件，
并自动创建 .nojekyll（避免 Jekyll 渲染卡死）。
"""
import base64, os, sys
from pathlib import Path

REPO = "Zhiyuan19/china-computing-weekly"
BRANCH = "main"
API = f"https://api.github.com/repos/{REPO}"
REPORT_DIR = Path("/home/clawhelper/.openclaw/workspace/report")


def auth_headers(token: str) -> dict:
    return {
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github.v3+json",
        "User-Agent": "AI-Agent/1.0",
    }


def put_file(headers: dict, path_in_repo: str, content_bytes: bytes) -> tuple[int, str]:
    """PUT /contents/{path}，含 SHA 获取与更新逻辑。返回 (status_code, message)。"""
    import requests

    sha = None
    r = requests.get(f"{API}/contents/{path_in_repo}?ref={BRANCH}", headers=headers, timeout=15)
    if r.status_code == 200:
        sha = r.json().get("sha")
    elif r.status_code != 404:
        return r.status_code, f"GET sha failed: {r.text[:200]}"

    payload = {
        "message": f"Update {path_in_repo}",
        "content": base64.b64encode(content_bytes).decode(),
        "branch": BRANCH,
    }
    if sha:
        payload["sha"] = sha

    r = requests.put(f"{API}/contents/{path_in_repo}", headers=headers, json=payload, timeout=30)
    return r.status_code, r.text[:200] if r.status_code not in (200, 201) else "OK"


def collect_files(report_dir: Path) -> list[tuple[str, Path]]:
    """收集推送文件列表：report_dir 下所有文件 + .nojekyll。"""
    items: list[tuple[str, Path]] = []
    if report_dir.exists():
        for p in sorted(report_dir.iterdir()):
            if p.is_file():
                items.append((p.name, p))
    items.append((".nojekyll", Path(".nojekyll")))
    return items


def main() -> int:
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        print("❌ 请先 export GITHUB_TOKEN=ghp_xxx", file=sys.stderr)
        return 2

    if not REPORT_DIR.exists():
        print(f"❌ 报告目录不存在: {REPORT_DIR}", file=sys.stderr)
        return 2

    headers = auth_headers(token)
    files = collect_files(REPORT_DIR)
    print(f"=== 推送 {len(files)} 个文件到 {REPO}@{BRANCH} ===")
    print(f"    源目录: {REPORT_DIR}\n")

    failed: list[str] = []
    for name, local_path in files:
        print(f">>> {name}")
        if name == ".nojekyll":
            content = b""
        elif local_path.exists():
            content = local_path.read_bytes()
        else:
            print(f"    SKIP (本地不存在)")
            continue

        status, msg = put_file(headers, name, content)
        if status in (200, 201):
            print(f"    PUT {status} OK")
        else:
            print(f"    PUT {status} FAILED: {msg}")
            failed.append(name)

    print()
    if failed:
        print(f"❌ {len(failed)} 个文件失败: {', '.join(failed)}", file=sys.stderr)
        return 1
    print(f"✅ 全部成功！访问 https://{REPO.replace('/', '.github.io/')}/")
    print("   Pages 部署由 GitHub 自动触发，约 1-2 分钟生效")
    return 0


if __name__ == "__main__":
    sys.exit(main())