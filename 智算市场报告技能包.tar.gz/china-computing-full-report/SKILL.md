---
name: china-computing-full-report
description: 生成中国智能算力市场完整版HTML周报（9章全报告）。当用户要求生成完整版智算市场报告周报、一键生成全报告、生成9章完整报告时调用。核心功能：(1) 串行生成第1-8章——每次只启动1个子agent生成1个章节HTML，完成并验证后才启动下一个；(2) 主agent验证通过才结束子agent，不通过则复用同一session催促继续；(3) 8章全部完成后生成第九章结论与建议。
metadata:
  clawdbot:
    emoji: 📑
    requires:
      anyBins:
        - python3
---

> ⚠️ **本 skill 的所有命令假设工作目录为 `~/.openclaw/workspace/`**（即 openclaw workspace 根目录）。如从其他目录运行，请先 `cd ~/.openclaw/workspace`。

# 中国智能算力市场完整版报告生成技能

## 核心定位

本技能生成中国智能算力市场**完整版HTML周报**（9章），核心流程：

```
串行生成第1-8章（每次只启动1个subagent，验证通过才启动下一个）
→ 8章全部验证通过后生成第9章结论与建议
```

**输出文件（9个HTML）：**
```
report/政策环境分析报告.html（第1章）
report/市场规模发展分析报告.html（第2章）
report/区域算力发展分析报告.html（第3章）
report/竞争格局发展分析报告.html（第4章）
report/技术趋势发展分析报告.html（第5章）
report/供应商与产业格局分析报告.html（第6章）
report/应用场景分析报告.html（第7章）
report/广东智算中心建设分析报告.html（第8章）
report/结论与建议报告.html（第9章）
```

## 串行执行规则（核心规则一）

**每次只启动1个subagent生成1个章节HTML，该章节验证通过（文件>20KB）后，才启动下一个subagent生成下一章。**

```
第1章 → 验证通过 → 第2章 → 验证通过 → 第3章 → … → 第8章 → 验证通过 → 第9章
```

**规则：严禁同时启动多个subagent，严禁同一章节开启新的subagent session。**

- 同一章节只能用同一个subagent session完成
- 验证不通过→向该session发消息催促继续→不得新建session
- 某章节卡住连续3次催促无进展→记录警告→继续下一章→后续单独重试

## 子agent验证与异常处理（核心规则二、三）

**规则二：子agent完成时必须向主agent发送`[CHAPTER_X_DONE]`消息（X为章节号）**

subagent任务末尾强制指令：
```
完成所有内容生成后，你必须向主agent发送一条消息，消息内容只需包含：
"[CHAPTER_X_DONE]"
（其中X为章节号，如第1章则发送"[CHAPTER_1_DONE]"）

禁止不发消息直接退出。
```

**规则三：主agent收到`[CHAPTER_X_DONE]`后立即验证文件**

```python
def handle_chapter_done(chapter):
    """收到子agent [CHAPTER_X_DONE] 后立即调用此函数"""
    report_path = REPORT_PATHS[chapter]

    if os.path.exists(report_path) and os.path.getsize(report_path) >= 20000:
        # 文件存在且大小正常，标记完成，结束该session
        mark_completed(chapter)
        print(f"✅ 第{chapter}章验证通过，文件大小：{os.path.getsize(report_path)} bytes")
        return True
    else:
        # 文件缺失或过小，复用现有session继续执行，不创建新session
        actual_size = os.path.getsize(report_path) if os.path.exists(report_path) else 0
        print(f"⚠️ 第{chapter}章文件异常（{actual_size} bytes），催促继续执行")
        return False
```

**规则四：文件验证不通过时，向同一session发消息催促继续**

```python
def nudge_session(session_key, chapter):
    """向已有session发消息催促继续，不新建session"""
    sessions_send(session_key, f"你的任务尚未完成。第{chapter}章报告文件未生成或大小不足20KB，请检查输出路径并确保报告已保存到 report/ 下的正确位置，然后继续执行直到完成。")
```

**规则五：某章节连续3次催促无进展，记录警告，继续下一章**

```python
warn_count = {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0}

def on_nudge(session_key, chapter):
    warn_count[chapter] += 1
    if warn_count[chapter] >= 3:
        log(f"⚠️ 第{chapter}章连续3次催促无进展，记录警告，继续下一章")
        # 标记跳过，后续单独重试
        # 继续推进：启动下一章subagent
        return True  # 表示继续下一章
    return False  # 表示继续等当前章节
```

## 完整工作流程

### 阶段1 — 串行生成第1-8章

**总体流程：**
主agent按章节顺序（第1章→第2章→第3章…→第8章）依次启动subagent生成报告。每章流程完全相同，具体步骤如下：

**第N章生成步骤（N = 1~8）：**
1. 主agent启动一个subagent，将对应章节的任务要求（task）传递给它
2. subagent开始生成该章节的HTML报告
3. 主agent等待subagent回复，收到 `[CHAPTER_N_DONE]` 消息后进入验证
4. 主agent检查 `report/` 下的对应文件是否存在且大小>20KB
5. **验证通过**：该章节结束，主agent开始生成下一章（返回步骤1）
6. **验证不通过**：向同一subagent session发消息催促继续，subagent继续执行直到再次发送 `[CHAPTER_N_DONE]`，主agent再次验证
7. 连续3次催促仍无进展：记录警告，标记该章节跳过，继续下一章（后续单独重试）

**章节任务分配：**
- 第1章（政策环境分析）→ skill: `china-computing-policy-weekly-report`
- 第2章（市场规模分析）→ skill: `china-computing-market-weekly-report`
- 第3章（区域算力分析）→ skill: `regional-computing-report`
- 第4章（竞争格局分析）→ skill: `china-computing-competition-weekly-report`
- 第5章（技术趋势分析）→ skill: `china-computing-technology-weekly-report`
- 第6章（供应商与产业格局）→ skill: `china-computing-suppliers-weekly-report`
- 第7章（应用场景分析）→ skill: `china-computing-applications-weekly-report`
- 第8章（广东智算中心建设）→ skill: `china-computing-guangdong-construction-weekly-report`

**一个关键约束：** 每次只运行1个subagent，完成一个章节的验证后，才启动下一个subagent。同一章节的subagent session一旦创建，无论发生什么异常都不能新建，必须复用该session完成任务。

### 阶段2 — 生成第九章结论与建议

**前置条件：** 第1-8章全部验证通过（每个文件>20KB）

**操作步骤：**
1. 主agent依次读取前八章HTML文件内容，提取关键数据点（市场总量、政策要点、竞争格局、技术趋势、供应商变化、应用热点、广东建设规模）
2. 主agent启动一个subagent，将前八章关键数据作为输入，要求其生成第九章HTML报告
3. subagent输出到 `report/结论与建议报告.html`
4. 主agent验证文件>20KB，如不通过则向同一session催促继续（不复用新session）
5. 验证通过后，全部9章报告生成完毕

**第九章生成要求（主agent告知subagent的内容）：**
- 总结本周市场核心变化（3-5个要点）
- 分析下阶段趋势（政策/技术/市场/建设四个维度）
- 提出针对性建议（3-5条）
- HTML格式与前八章保持一致（深蓝渐变header、数据卡片、时间线等）
- 完成后subagent必须发送 `[CHAPTER_9_DONE]`

**第九章验证流程：** 与前述各章完全相同——收到完成消息 → 检查文件>20KB → 通过则结束，不通过则催促同一session继续

---

### 端到端总览

```
启动 ch1 → 等待完成 → 验证 → 通过则启动 ch2 → 不通过则催促继续（同一session）
    ↓
ch2 → 等待完成 → 验证 → 通过则启动 ch3 → 不通过则催促继续（同一session）
    ↓
ch3 → ch4 → ch5 → ch6 → ch7 → ch8（依次串行）
    ↓
ch8验证通过
    ↓
阶段2：生成第9章 → 验证 → 完成
```

## 报告文件路径映射

| 章节 | 报告文件名 | 对应skill |
|------|-----------|---------|
| 第1章 | `政策环境分析报告.html` | china-computing-policy-weekly-report |
| 第2章 | `市场规模发展分析报告.html` | china-computing-market-weekly-report |
| 第3章 | `区域算力发展分析报告.html` | regional-computing-report |
| 第4章 | `竞争格局发展分析报告.html` | china-computing-competition-weekly-report |
| 第5章 | `技术趋势发展分析报告.html` | china-computing-technology-weekly-report |
| 第6章 | `供应商与产业格局分析报告.html` | china-computing-suppliers-weekly-report |
| 第7章 | `应用场景分析报告.html` | china-computing-applications-weekly-report |
| 第8章 | `广东智算中心建设分析报告.html` | china-computing-guangdong-construction-weekly-report |
| 第9章 | `结论与建议报告.html` | china-computing-conclusions-weekly-report |

## 输出目录

所有报告输出至：`report/`

## 验证清单

生成完成后验证9个文件：
- [ ] `政策环境分析报告.html` > 20KB
- [ ] `市场规模发展分析报告.html` > 20KB
- [ ] `区域算力发展分析报告.html` > 20KB
- [ ] `竞争格局发展分析报告.html` > 20KB
- [ ] `技术趋势发展分析报告.html` > 20KB
- [ ] `供应商与产业格局分析报告.html` > 20KB
- [ ] `应用场景分析报告.html` > 20KB
- [ ] `广东智算中心建设分析报告.html` > 20KB
- [ ] `结论与建议报告.html` > 20KB

## 关键规则（务必遵守）

1. **串行执行，严禁并行**：每次只启动1个subagent，完成并验证后才启动下一个
2. **同一章节复用同一session**：不管发生什么异常，都**不新建**同一章节的subagent session
3. **子agent必须回复主agent**：`[CHAPTER_X_DONE]`是完成信号，不发消息=未完成
4. **文件验证>消息验证**：subagent说"完成"≠文件已生成，必须验证文件大小>20KB
5. **连续3次催促无进展则跳过**：记录警告，继续下一章，后续单独重试
6. **第九章依赖前八章**：结论与建议必须读取前八章内容，不能凭空生成
7. **报告日期（动态）**：报告日期 = 指令发出当日；周期 = 往前倒7天。同一批报告中所有9章必须使用相同的报告日期和周期
