---
name: report-homepage
description: 中国智算周报首页生成技能。当用户要求生成智算市场8章周报的首页摘要、执行摘要、目录导航、KPI卡片总览时调用。本技能从8章HTML报告中提取6个KPI卡片（智能算力总规模/算力市场规模/国产AI芯片份额/DeepSeek Token/AI应用市场规模/万卡集群），结合AI生成的600-800字执行摘要（8 主题每章一个要点），生成统一的报告首页（report_index.html）。
metadata:
  clawdbot:
    emoji: 🏠
    requires:
      anyBins:
        - python3
---

> ⚠️ **本 skill 的所有命令假设工作目录为 `~/.openclaw/workspace/`**（即 openclaw workspace 根目录）。如从其他目录运行，请先 `cd ~/.openclaw/workspace`。

# 中国智算周报首页生成 Skill

## 功能说明

生成中国智能算力周报（8章）的**首页摘要 + 目录导航**，以 `skeleton.html` 为骨架，数据来自 `extract_summary.py` 的 JSON 输出。

---

## 输入

周报HTML文件目录：`report/`

| 章节 | 文件名 | 标题 |
|------|--------|------|
| 1 | 政策环境分析报告.html | 一、政策环境分析 |
| 2 | 市场规模发展分析报告.html | 二、市场规模分析 |
| 3 | 区域算力发展分析报告.html | 三、区域算力发展分析 |
| 4 | 竞争格局发展分析报告.html | 四、竞争格局分析 |
| 5 | 技术趋势发展分析报告.html | 五、技术趋势分析 |
| 6 | 供应商与产业格局分析报告.html | 六、供应商与产业格局 |
| 7 | 应用场景分析报告.html | 七、应用场景分析 |
| 8 | 结论与建议报告.html | 八、结论与建议 |

---

## 输出文件

- `report_index.html` — 首页（执行摘要置顶 + 目录每条一行 + 6个KPI卡片）

---

## 首页骨架（skeleton.html）

文件路径：`skills/report-homepage/skeleton.html`

以最新 `report_index.html` 为模板，剔除内容后保留占位符：

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{{PERIOD}}` | 期号 | `第 {WEEK_NUMBER} 期 · {REPORT_DATE}` |
| `{{DATE_RANGE}}` | 数据周期 | `{PERIOD_START} — {REPORT_DATE}` |
| `{{KPI_CARDS}}` | 6个KPI卡片HTML | 整段 HTML 片段 |
| `{{SUMMARY_TEXT}}` | 执行摘要段落 | 600-800字自然段落 |
| `{{CHAPTER_ITEMS}}` | 8条目录项HTML | 整段 HTML 片段 |
| `{{FOOTER}}` | 页脚版本信息 | `中国智算市场周报 · 第{WEEK_NUMBER}期 · ...` |

**骨架 HTML/CSS 布局（固定不变）：**

```html
<!-- 头部：深蓝渐变 -->
<div class="header">
    <div class="header-period">{{PERIOD}}</div>
    <h1>🖥️ 中国智能算力市场深度分析周报</h1>
    <div class="header-subtitle">China AI Computing Market Intelligence Weekly</div>
    <div class="header-modules"><!-- 8个模块标签横排 --></div>
    <div class="header-period-bottom">数据周期：{{DATE_RANGE}}</div>
</div>

<!-- 数据说明条：蓝底左边框 -->
<div class="data-note"><strong>数据说明：</strong>...</div>

<!-- KPI网格：3×2 -->
<div class="kpi-grid">{{KPI_CARDS}}</div>

<!-- 执行摘要：白底卡片 -->
<div class="summary-box"><p class="summary-text">{{SUMMARY_TEXT}}</p></div>

<!-- 目录列表：白底卡片，每条一行 -->
<div class="toc-box"><ul class="toc-list">{{CHAPTER_ITEMS}}</ul></div>

<!-- 页脚 -->
<div class="footer">{{FOOTER}}</div>
```

**CSS 颜色体系（固定不变）：**
- Header背景：`linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)`
- 数据说明：`#e8f4fd` 背景，`#2196F3` 左边框
- KPI数值颜色：`#667eea`（算力规模）、`#0ea5e9`（市场规模）、`#10b981`（国产芯片）、`#f59e0b`（Token）、`#8b5cf6`（应用市场）、`#ef4444`（万卡集群）
- 目录序号：`#667eea`
- Hover：`#0ea5e9`

---

## 执行流程

### Step 1：提取数据并生成提示词
```bash
python3 skills/report-homepage/extract_summary.py
```
工作目录：`~/.openclaw/workspace`

**输出：**
- `/tmp/summary_data.json` — KPI数据 + 章节文本摘要 + 元数据（期号/日期范围/页脚）
- `/tmp/summary_prompt.txt` — AI写作提示词 + 全部章节文本

### Step 2：AI生成执行摘要
1. 读取 `/tmp/summary_prompt.txt`
2. AI综合分析8章内容，撰写 **600-800字执行摘要**（自然段落，**8 主题每章一个要点**，每主题以「主题 + 最新事件（日期）+ 关键数字 + 意义」结构展开）
3. 将摘要写入 `/tmp/summary_ai.txt`（纯文本，无任何标记）

---

## 摘要写作规范（2026-08-13 老板指示）

**核心结构：8 主题每章一个要点**（不再使用旧的"7 大主题"结构）。

每个主题对应前 8 章周报中的 1 章，**一一映射**：

| 主题编号 | 对应章节 | 章节名称 | 关键数据要素 |
|---------|---------|---------|------------|
| ①政策重磅 | 第 1 章 | 政策环境分析 | 政策窗口期/重大政策文件 |
| ②市场涨价 | 第 2 章 | 市场规模分析 | 算力服务签约/Token/H100涨价 |
| ③区域扩张 | 第 3 章 | 区域算力发展分析 | 万P/万卡/亿元级项目 |
| ④竞争格局 | 第 4 章 | 竞争格局分析 | 国产AI芯片/超节点/集采 |
| ⑤技术趋势 | 第 5 章 | 技术趋势分析 | 推理算力/超节点/液冷/光互联 |
| ⑥供应链 | 第 6 章 | 供应商与产业格局 | HBM/HBF/光模块/液冷 |
| ⑦应用商业化 | 第 7 章 | 应用场景分析 | Robotaxi/医疗AI/具身智能 |
| **⑧广东智算** | **第 8 章** | **广东智算中心建设** | **信息表项目数/三大运营商+政府分点/关键节点事件** |

### ⑧广东智算（第 8 章）写作硬约束

**必含要素**（缺一项即不合格）：
1. **信息表总项目数**：本期信息表收录 N 条（按日期倒序 8.7-8.13）
2. **运营商+政府分点**：三大运营商合计 N 条（电信 X + 移动 X + 联通 X）+ 政府 N 条 = 总数
3. **关键节点事件**（至少 3 条）：
   - 联通粤港澳枢纽（韶关）4栋数据中心签约锁定 / DC1 号楼租售突破 60% / 年底园区破 20000P
   - 电信浈江 2.2 期（A3A4）工程 EPC 总承包 4.04 亿启动
   - 联通数据中心 4 机电 3 个 EPC 集中释放
   - 武江龙归扩区一期配套同步定标（含 4094 亩规划）
   - 中国移动浈江横三路 + 韶塘变电站接入技术咨询中选

**禁止**：
- 不得用"第八章"字样作为主题标签（避免冗余）：主题标签只写 `⑧广东韶关集群` 或 `⑧广东智算中心建设`
- 不得出现双冒号（`：**`）格式错误
- 不得简化"40条"为"约40条"或"40+条"——必须精确
- 不得忽略政府/事业单位 25 条配套信息

### 输出格式（必须严格遵守）

格式：**①主题名**：正文...
示例：**①政策重磅**：数据产权登记制度7月6日正式生效...
反例：❌ **政策与市场**（缺少序号①~⑧，首页将无法渲染颜色标签）
警告：不按此格式则首页渲染报错，必须严格遵循。
- 每点独立成段，段内文字连贯
- 事件描述中必须包含日期（如"8月12日发改委重磅表态"）
- 总字数：**600-800 字**（较旧版 400-600 上调，原因：8 主题信息密度更高）

**序号后禁止加章节注释**（LRN-20260814-001）：
- ✅ 正确：**①政策重磅**：...
- ❌ 错误：**①政策重磅（第1章）**：...
- 主题序号①~⑧已隐含章节映射，重复写"（第X章）"属冗余，**必须删除**

**第 8 章关键节点格式**（同 LRN-20260814-001）：
- 禁止在要点内部嵌套子序号（① ② ③ ④ ⑤），会和主题序号视觉冲突
- 推荐用「分号 ；」分隔 5 个关键节点，串成一句；如需项目化用「·」点号
- ✅ 正确：「关键节点：8.13联通粤港澳枢纽...；8.12电信浈江2.2期...；8.10联通数据中心4机电...；8.13武江龙归扩区...；8.8移动浈江横三路...」
- ❌ 错误：「关键节点：①8.13联通粤港澳枢纽...；②8.12电信浈江2.2期...；③8.10联通...」

### Step 3：生成首页
```bash
python3 skills/report-homepage/gen_report_index.py
```
读取 `skeleton.html` + `/tmp/summary_data.json` + `/tmp/summary_ai.txt`，输出 `report_index.html`

---

## KPI卡片数据来源

| KPI | 来源章节 | 说明 |
|-----|---------|------|
| 智能算力总规模 | 市场规模章节 | data-card 提取，单位 EFLOPS |
| 算力市场规模 | 市场规模章节 | data-card 提取，单位亿元 |
| 国产AI芯片份额 | 竞争格局章节 | 全文正则匹配 `国产AI芯片份额从年初不足5%升至XX%` |
| DeepSeek相关Token | 竞争格局/应用场景章节 | data-card 提取，单位万亿Token/日 |
| AI应用市场规模 | 应用场景章节 | data-card 提取（金融AI/医疗AI），单位亿元 |
| 万卡智算集群 | 竞争格局/区域章节 | 全文正则匹配万卡集群名称 |

---

## 完整工作流（适用于 cron 或手动触发）

```bash
# 1. 提取数据和提示词
cd ~/.openclaw/workspace
python3 skills/report-homepage/extract_summary.py

# 2. AI生成摘要 → 写入 /tmp/summary_ai.txt
# （此步需人工/大模型读取提示词文件并生成摘要）

# 3. 生成首页
python3 skills/report-homepage/gen_report_index.py
```

---

## 脚本说明

### extract_summary.py
读取全部8章HTML，提取：
- KPI数据卡片（6项固定指标）
- 章节纯文本（前3000字/章）
- 章节提示词文件（供AI综合分析）
- 元数据（期号、日期范围、页脚）

### gen_report_index.py
读取：
- `skeleton.html` — 骨架构图
- `/tmp/summary_data.json` — KPI + 元数据
- `/tmp/summary_ai.txt` — AI执行摘要

输出：`report_index.html`

---

## 关键规则

- **骨架文件不变**：首页的 HTML/CSS 布局完全由 `skeleton.html` 定义，任何布局改动必须先修改骨架
- **内容数据分离**：排版在骨架，内容在 JSON/TXT，互不耦合
- **目录项固定**：8章顺序和文件名硬编码在 `gen_report_index.py` 的 `chapters` 列表中
- **KPI 颜色固定**：颜色根据指标名称映射，非动态生成

