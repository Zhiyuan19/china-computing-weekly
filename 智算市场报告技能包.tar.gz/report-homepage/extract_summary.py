#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
extract_summary.py - AI综合写作法生成执行摘要

工作流程：
1. 读取全部8章HTML，提取：
   - 时间线数据（timeline，按日期倒序，越新越靠前）
   - data-card（KPI卡片）
   - 章节纯文本（参考背景）
2. 将时间线数据 + 章节文本写入 /tmp/summary_data.json
3. 生成 /tmp/summary_prompt.txt（**时间线优先**的AI写作提示词）
4. AI根据提示词综合分析，生成自然段落执行摘要

输出 /tmp/summary_data.json：
  - timelines: [{chapter, date, title, source, impact}]  ← 时间线（按日期倒序）
  - chapter_texts: {文件名: 纯文本}                      ← 参考背景
  - summary_text: str                                      ← AI写作摘要（由外部AI调用生成后回填）
  - data_cards: [...]                                     ← KPI卡片原始数据

执行：python3 extract_summary.py
"""

import re, os, json
from pathlib import Path

REPORT_DIR = "/home/clawhelper/.openclaw/workspace/report"
OUTPUT_JSON = "/tmp/summary_data.json"
PROMPT_FILE = "/tmp/summary_prompt.txt"

CHAPTER_FILES = [
    "政策环境分析报告.html",
    "市场规模发展分析报告.html",
    "区域算力发展分析报告.html",
    "竞争格局发展分析报告.html",
    "技术趋势发展分析报告.html",
    "供应商与产业格局分析报告.html",
    "应用场景分析报告.html",
    "广东智算中心建设分析报告.html",
    "结论与建议报告.html",
]

CHAPTER_TITLES = {
    "政策环境分析报告.html": "一、政策环境分析",
    "市场规模发展分析报告.html": "二、市场规模分析",
    "区域算力发展分析报告.html": "三、区域算力发展分析",
    "竞争格局发展分析报告.html": "四、竞争格局分析",
    "技术趋势发展分析报告.html": "五、技术趋势分析",
    "供应商与产业格局分析报告.html": "六、供应商与产业格局",
    "应用场景分析报告.html": "七、应用场景分析",
    "广东智算中心建设分析报告.html": "八、广东智算中心建设",
    "结论与建议报告.html": "九、结论与建议",
}


def strip_html(html):
    """去除HTML标签，保留纯文本（参考WebClip._stripHtml逻辑）"""
    return html \
        .replace('<script'[:6].lower(), '<script') \
        .replace('</script>', '') \
        .replace('<style'[:6].lower(), '<style') \
        .replace('</style>', '') \
        .replace('<nav'[:4].lower(), '<nav') \
        .replace('</nav>', '') \
        .replace('<footer'[:7].lower(), '<footer') \
        .replace('</footer>', '') \
        .replace('<header'[:7].lower(), '<header') \
        .replace('</header>', '') \
        .replace('<', ' <').replace('>', '> ') \
        .replace('&nbsp;', ' ').replace('&amp;', '&') \
        .replace('&lt;', '<').replace('&gt;', '>') \
        .replace('&ldquo;', '"').replace('&rdquo;', '"') \
        .replace('&lsquo;', "'").replace('&rsquo;', "'") \
        .replace('&mdash;', '—').replace('&ndash;', '–') \
        .replace('&#8220;', '"').replace('&#8221;', '"') \
        .replace('&#8216;', "'").replace('&#8217;', "'") \
        .replace('&#160;', ' ').replace('&quot;', '"') \
        .replace('\n', ' ')


def clean_text(text):
    """进一步清理纯文本：去除多余空白、残留标签碎片"""
    text = re.sub(r'<[^>]{1,30}>', ' ', text)          # 短残留标签
    text = re.sub(r'\s+', ' ', text)                    # 多空格→单空格
    text = re.sub(r' {2,}', ' ', text)                  # 两空格→单空格
    text = text.strip()
    return text


def extract_all_cards(html):
    """提取所有 data-card"""
    results = []
    pattern = re.compile(
        r'<div class="label">([^<]+)</div>\s*'
        r'<div class="value">(.*?)</div>',
        re.DOTALL
    )
    for m in pattern.finditer(html):
        label = m.group(1).strip()
        raw_value = m.group(2).strip()
        value = re.sub(r'<[^>]+>', '', raw_value).strip()
        rest = html[m.end():m.end()+300]
        change_m = re.search(r'<div class="change">([^<]+)</div>', rest)
        change = change_m.group(1).strip() if change_m else ""
        results.append({"label": label, "value": value, "change": change})
    return results


def extract_timelines(html, chapter_label):
    """提取时间线数据（.timeline-item），按日期倒序排列。
    
    时间线是各章最重要的事件脉络，按日期排序后越新的事件越靠前。
    """
    results = []
    # 匹配每个 timeline-item
    item_pattern = re.compile(
        r'<div class="timeline-item">'
        r'(.*?)'
        r'</div>\s*</div>\s*(?=<div class="timeline-item">|<!-- |<div class="section">)',
        re.DOTALL
    )
    for item_m in item_pattern.finditer(html):
        item_html = item_m.group(1)
        
        # 提取日期（支持 MM-DD 和中文 X月X日 两种格式）
        date_str = "00-00"
        date_m = re.search(r'<div class="timeline-date">\s*([\d]{2}-[\d]{2})', item_html)
        if date_m:
            date_str = date_m.group(1)
        else:
            cn_m = re.search(r'<div class="timeline-date">\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', item_html)
            if cn_m:
                date_str = f"{int(cn_m.group(1)):02d}-{int(cn_m.group(2)):02d}"
        
        # 提取标题
        title_m = re.search(r'<div class="timeline-title">\s*([^<\n]+)', item_html)
        title = title_m.group(1).strip() if title_m else ""
        
        # 提取来源
        source_m = re.search(r'<div class="timeline-source">\s*([^<\n]+)', item_html)
        source = source_m.group(1).strip() if source_m else ""
        
        # 提取影响分析
        impact_m = re.search(r'<div class="timeline-impact">\s*([^<]+)', item_html)
        impact = impact_m.group(1).strip() if impact_m else ""
        if not impact:
            # 尝试多行匹配
            impact_m = re.search(r'<div class="timeline-impact">(.*?)</div>', item_html, re.DOTALL)
            impact = re.sub(r'<[^>]+>', '', impact_m.group(1)).strip() if impact_m else ""
        
        if title:  # 只保留有标题的条目
            results.append({
                "chapter": chapter_label,
                "date": date_str,
                "title": title,
                "source": source,
                "impact": impact[:300] if impact else "",  # 截断超长impact
            })
    
    # 按日期倒序排列（最新日期在前）
    def parse_date_key(item):
        # MM-DD 格式，转换为 (月, 日) 数值用于排序
        parts = item["date"].split("-")
        try:
            return (int(parts[0]), int(parts[1]))
        except:
            return (0, 0)
    
    results.sort(key=parse_date_key, reverse=True)
    return results


# ============================================================
# KPI 提取（智能选卡，不依赖固定关键字）
# ============================================================

def _score_card(card):
    """给单个卡片打分，越高越值得展示。"""
    score = 0
    label = card.get("label", "")
    value = card.get("value", "")
    change = card.get("change", "")

    # 有变化信息 +2
    if change and change.strip():
        score += 2

    # value 是有效数字 +1
    if re.search(r'\d', value):
        score += 1

    # 数值看起来有意义（有单位关键词） +1
    meaningful_units = ["亿", "万", "EFLOPS", "PetaFLOPS", "PF",
                        "%", "%%", "Token", "万亿", "美元", "元",
                        "GB", "TB", "PB", "万卡", "万P", "万台",
                        "卡时", "亿美元", "亿元", "万亿美元"]
    if any(u in value for u in meaningful_units):
        score += 1

    # 排除纯比率类英文标签（干扰项）
    if re.match(r'^[a-zA-Z]{2,5}$', label):
        score -= 5

    # 排除太短的 label（往往是干扰项）
    if len(label) < 4:
        score -= 3

    return score


def _clean_value(value):
    """清理重复单位，如 "28.85亿元亿元/季" → "28.85亿元" """
    # 找数字开头部分
    m = re.match(r'^[~约]?([\d,.]+)(.*)', value)
    if m:
        num = m.group(1)
        suffix = m.group(2)
        # 如果 suffix 前后完全重复（e.g. "亿元亿元"），取一半
        half = len(suffix) // 2
        if half > 0 and suffix == suffix[:half] * 2:
            suffix = suffix[:half]
        return num + suffix
    return value


def extract_kpis(all_data):
    """从全部8章的 data-card 中智能选取得分最高的6张卡片。

    策略：
    1. 收集全部卡片（含来源章节信息）
    2. 过滤掉无数字的干扰卡
    3. 按 _score_card 打分
    4. 选最高6张（避免完全重复label）
    5. 每张卡片清理 value（去除重复单位）
    """
    chapter_map = {
        "政策环境分析报告.html": "第1章",
        "市场规模发展分析报告.html": "第2章",
        "区域算力发展分析报告.html": "第3章",
        "竞争格局发展分析报告.html": "第4章",
        "技术趋势发展分析报告.html": "第5章",
        "供应商与产业格局分析报告.html": "第6章",
        "应用场景分析报告.html": "第7章",
        "广东智算中心建设分析报告.html": "第8章",
        "结论与建议报告.html": "第9章",
    }

    # ① 收集全部卡片
    all_cards = []
    for fname, chapter_info in chapter_map.items():
        cards = all_data.get(fname, {}).get("cards", [])
        for c in cards:
            c = dict(c)  # 复制，避免修改原数据
            c["chapter"] = chapter_info
            c["source_file"] = fname
            all_cards.append(c)

    # ② 过滤：去除无数字的干扰卡
    filtered = [c for c in all_cards if re.search(r'\d', c.get("value", ""))]

    # ③ 评分
    scored = [(c, _score_card(c)) for c in filtered]
    scored.sort(key=lambda x: x[1], reverse=True)

    # ④ 选Top6（每章最多2张，避免某章垄断）
    selected = []
    used_labels = set()
    used_per_chapter = {ch: 0 for ch in chapter_map.values()}
    MAX_PER_CHAPTER = 2
    for card, score in scored:
        if len(selected) >= 6:
            break
        label = card.get("label", "")
        chapter = card.get("chapter", "")
        if label in used_labels:
            continue
        if used_per_chapter.get(chapter, 0) >= MAX_PER_CHAPTER:
            continue
        used_labels.add(label)
        used_per_chapter[chapter] = used_per_chapter.get(chapter, 0) + 1
        clean_val = _clean_value(card.get("value", ""))
        selected.append({
            "label": label,
            "value": clean_val,
            "unit": "",
            "change": card.get("change", ""),
            "chapter": chapter,
        })

    return selected[:6]


# ============================================================
# AI写作提示词
# ============================================================

SUMMARY_PROMPT = """你是一位专业的中国智算市场研究报告编辑。请根据以下8章周报的**时间线数据**（已按日期倒序排列，越新越靠前）撰写执行摘要。

【核心原则：时间线优先，越新越重要】
- **时间线是本周最重要的事件脉络**，请以时间线为主要素材
- 日期越新（如05-26、05-25）的事件优先级越高，优先在摘要中体现
- 每章只取最新3条时间线，避免堆砌
- 各章纯文本仅作背景参考，时间线才是摘要的核心骨架

【写作要求 - 8 主题每章一个要点（2026-08-13 老板指示）】
- **必须包含 8 个主题**，每个主题对应前 8 章周报中的 1 章（一 一映射）：
  - ①政策重磅 ← 第1章政策环境
  - ②市场涨价 ← 第2章市场规模
  - ③区域扩张 ← 第3章区域算力
  - ④竞争格局 ← 第4章竞争格局
  - ⑤技术趋势 ← 第5章技术趋势
  - ⑥供应链博弈 ← 第6章供应商与产业格局
  - ⑦应用商业化 ← 第7章应用场景
  - **⑧广东智算中心建设 ← 第8章广东智算**
- 每点以「主题 + 最新事件（日期）+ 关键数字 + 意义」结构展开
- 数据用具体数字，不用"显著增长"等模糊词
- 各点之间语言连贯，但格式清晰分点
- **优先引用时间线中的impact分析**，再结合背景补充
- 语言风格：专业财经媒体（如《财经》/《21世纪经济报道》）

【⑧广东智算（第8章）必含要素】（缺一项即不合格）
- 信息表总项目数：本期信息表收录 N 条（按日期倒序 8.7-8.13）
- 运营商+政府分点：三大运营商合计 N 条（电信 X + 移动 X + 联通 X）+ 政府 N 条
- 关键节点事件（至少 3 条）：
  - 联通粤港澳枢纽（韶关）4栋数据中心签约锁定 / DC1 号楼租售突破 60% / 年底园区破 20000P
  - 电信浈江 2.2 期（A3A4）工程 EPC 总承包 4.04 亿启动
  - 联通数据中心 4 机电 3 个 EPC 集中释放
  - 武江龙归扩区一期配套同步定标（含 4094 亩规划）
  - 中国移动浈江横三路 + 韶塘变电站接入技术咨询中选

【8大主题关键词】（用于校验是否覆盖到位）
①政策重磅：1.755万亿/发改委/工信部/专项行动/Stanford报告
②市场涨价：Token/140万亿/H100涨价/廉价算力终结/智谱涨价83%
③区域扩张：万P/万卡/签约/竣工/亿元/内蒙古增18%/芜湖/中卫245亿
④国产突破：DeepSeek V4/昇腾950PR/字节阿里腾讯预订/英伟达份额下滑
⑤推理主导：推理占比/LPU芯片/液冷/%/英维克股价
⑥供应链博弈：LTA/DRAM翻倍/HBM/三星/SK海力士/存储产业
⑦应用商业化：Robotaxi/L4/AI应用/月活用户/国务院政策
⑧广东智算：信息表项目数/三大运营商+政府分点/韶关集群/联通粤港澳/电信A3A4/联通数据中心4/武江龙归/移动浈江横三路

【输出格式 — 必须严格遵守】
格式：**①主题名**：正文...
示例：**①政策重磅**：数据产权登记制度7月6日正式生效...
反例：❌ **政策与市场**（缺少序号①~⑧，首页将无法渲染颜色标签）
警告：不按此格式则首页渲染报错，必须严格遵循。
- 每点独立成段，段内文字连贯
- 事件描述中必须包含日期（如"5月22日发改委重磅表态"）
- 总字数：**600-800 字**（较旧版 400-600 上调，原因：8 主题信息密度更高）
"""


# ============================================================
# 主流程
# ============================================================

def run():
    all_data = {}

    print("读取8章内容...")
    for fname in CHAPTER_FILES:
        path = os.path.join(REPORT_DIR, fname)
        if not os.path.exists(path):
            print(f"SKIP {fname}")
            continue
        with open(path, "r", encoding="utf-8") as f:
            html = f.read()

        raw_text = clean_text(strip_html(html))
        cards = extract_all_cards(html)

        all_data[fname] = {
            "text": raw_text,
            "cards": cards,
        }
        title = CHAPTER_TITLES.get(fname, fname)
        preview = raw_text[:500].replace('\n', ' ').strip()
        print(f"OK {fname}: {len(raw_text)}字 | {preview[:80]}...")

    # 提取KPI（智能选卡）
    kpis = extract_kpis(all_data)
    print(f"\n========== KPI数据卡片 ==========")
    for i, kpi in enumerate(kpis, 1):
        ch = f" | 变化: {kpi['change']}" if kpi['change'] else ""
        src = f" [{kpi.get('chapter','')}]" if kpi.get('chapter') else ""
        print(f"{i}. {kpi['label']}: {kpi['value']}{kpi['unit']}{ch}{src}")

    # 提取各章时间线（按日期倒序，越新越靠前）
    chapter_map = {
        "政策环境分析报告.html": "一、政策环境分析",
        "市场规模发展分析报告.html": "二、市场规模分析",
        "区域算力发展分析报告.html": "三、区域算力发展分析",
        "竞争格局发展分析报告.html": "四、竞争格局分析",
        "技术趋势发展分析报告.html": "五、技术趋势分析",
        "供应商与产业格局分析报告.html": "六、供应商与产业格局",
        "应用场景分析报告.html": "七、应用场景分析",
        "广东智算中心建设分析报告.html": "八、广东智算中心建设",
        "结论与建议报告.html": "九、结论与建议",
    }
    all_timelines = []
    for fname in CHAPTER_FILES:
        if fname not in all_data:
            continue
        path = os.path.join(REPORT_DIR, fname)
        if not os.path.exists(path):
            continue
        with open(path, "r", encoding="utf-8") as f:
            html = f.read()
        chapter_label = chapter_map.get(fname, fname.replace(".html", ""))
        timelines = extract_timelines(html, chapter_label)
        all_timelines.extend(timelines)
        print(f"\n========== {chapter_label} 时间线（倒序） ==========")
        for t in timelines[:5]:
            print(f"  [{t['date']}] {t['title'][:50]}")

    print(f"\n共提取 {len(all_timelines)} 条时间线")

    # 组装提示词文件（时间线优先）
    prompt_content = SUMMARY_PROMPT + "\n\n"

    # ★★★ 时间线优先展示（按日期全局倒序，取最新前30条）
    prompt_content += "\n" + "=" * 60 + "\n"
    prompt_content += "【各章时间线 · 按日期倒序 · 越新越靠前】\n"
    prompt_content += "（每章最多取最新3条，全局取最新30条）\n"
    prompt_content += "=" * 60 + "\n\n"

    # 全局按日期倒序
    def parse_date_key(item):
        parts = item["date"].split("-")
        try:
            return (int(parts[0]), int(parts[1]))
        except:
            return (0, 0)
    sorted_timelines = sorted(all_timelines, key=parse_date_key, reverse=True)
    
    # 按章节分组，每章最多3条
    by_chapter = {}
    for t in sorted_timelines:
        ch = t["chapter"]
        if ch not in by_chapter:
            by_chapter[ch] = []
        if len(by_chapter[ch]) < 3:
            by_chapter[ch].append(t)
    
    for chapter_label, items in by_chapter.items():
        prompt_content += f"\n■ {chapter_label}\n"
        for t in items:
            impact_preview = t["impact"][:150] + "..." if len(t.get("impact", "")) > 150 else t.get("impact", "")
            prompt_content += f"  [{t['date']}] {t['title']}\n"
            prompt_content += f"    来源：{t['source']}\n"
            if impact_preview:
                prompt_content += f"    影响：{impact_preview}\n"
        prompt_content += "\n"

    # 背景纯文本（供参考，不强制使用）
    prompt_content += "\n" + "=" * 60 + "\n"
    prompt_content += "【各章纯文本 · 仅供参考背景】\n"
    prompt_content += "=" * 60 + "\n\n"
    for fname in CHAPTER_FILES:
        if fname not in all_data:
            continue
        title = CHAPTER_TITLES.get(fname, fname)
        text = all_data[fname]["text"]
        text = text[:2000]  # 纯文本压缩到2000字
        prompt_content += f"\n{'='*40}\n【{title}】\n{'='*40}\n{text}\n"
    for fname in CHAPTER_FILES:
        if fname not in all_data:
            continue
        title = CHAPTER_TITLES.get(fname, fname)
        text = all_data[fname]["text"]
        text = text[:2500]
        prompt_content += f"\n{'='*40}\n【{title}】\n{'='*40}\n{text}\n"

    with open(PROMPT_FILE, "w", encoding="utf-8") as f:
        f.write(prompt_content)
    print(f"\n提示词文件已生成：{PROMPT_FILE}")
    print(f"请将AI生成的摘要写入 /tmp/summary_ai.txt，然后运行 gen_report_index.py")

    # 提取期号和日期范围（从章节文件data-note读取，保持一致）
    from datetime import datetime
    today_str = datetime.now().strftime("%Y.%m.%d")
    date_str = datetime.now().strftime("%Y-%m-%d")

    period_num = None
    date_range = f"{date_str} — {date_str}"  # 默认

    for fname in CHAPTER_FILES:
        fpath = os.path.join(REPORT_DIR, fname)
        if os.path.exists(fpath):
            with open(fpath, "r", encoding="utf-8") as f:
                chapter_html = f.read()
            # 提取期号
            if period_num is None:
                m = re.search(r'\u7b2c(\d+)\u671f', chapter_html)
                if m:
                    period_num = int(m.group(1))
            # 从 data-note 提取日期范围，如 "最近7天（2026-05-09—2026-05-15）"
            dm = re.search(r'(\d{4}-\d{2}-\d{2})[—–]+(\d{4}-\d{2}-\d{2})', chapter_html)
            if dm:
                date_range = f"{dm.group(1)} — {dm.group(2)}"
            if period_num is not None and date_range != (f"{date_str} — {date_str}"):
                break  # 两样都找到了就停止

    if period_num is None:
        period_num = 1

    # 用数据周期截止日作为期号标注日期（格式 YYYY.MM.DD）
    # 注意：date_range 格式为 "2026-05-22 — 2026-05-28"，取最后一个日期（截止日）
    parts = date_range.split(" — ")
    period_end = parts[-1] if len(parts) > 1 else parts[0]
    period_date_fmt = period_end.replace("-", ".")
    period = f"第 {period_num} 期 · {period_date_fmt}"
    footer = f"中国智算市场周报 · {period} · 每周三更新 · {date_range.split(' — ')[0]} 至 {date_range.split(' — ')[1]} 数据"

    output = {
        "timelines": all_timelines,
        "chapter_texts": {fname: all_data.get(fname, {}).get("text", "")[:3000] for fname in CHAPTER_FILES},
        "summary_text": "",
        "data_cards": kpis,
        "period": period,
        "date_range": date_range,
        "footer": footer,
    }

    with open(OUTPUT_JSON, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print(f"\n中间数据已保存：{OUTPUT_JSON}")
    print(f"期号：{period} | 日期范围：{date_range}")
    print(f"请将执行摘要内容写入 /tmp/summary_ai.txt，然后运行 gen_report_index.py 完成首页生成")


if __name__ == "__main__":
    run()