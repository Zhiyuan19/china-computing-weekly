#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
gen_report_index.py - 使用骨架文件生成首页 report_index.html
"""

import os, json, re
from pathlib import Path

SKILL_DIR = Path(__file__).parent
SKELETON_FILE = SKILL_DIR / "skeleton.html"
REPORT_DIR = "/home/clawhelper/.openclaw/workspace/report"
OUTPUT_FILE = os.path.join(REPORT_DIR, "report_index.html")
SUMMARY_JSON = "/tmp/summary_data.json"
SUMMARY_AI_TXT = "/tmp/summary_ai.txt"


def read_file(path, default=""):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()
    return default


def build_kpi_card(kpi, index):
    label = kpi.get("label", "")
    value = kpi.get("value", "N/A")
    unit = kpi.get("unit", "")
    change = kpi.get("change", "")
    # 循环6色：不管什么指标，按顺序轮流配色
    colors = ["#667eea", "#0ea5e9", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444"]
    color = colors[index % len(colors)]
    change_html = f'<div style="font-size:0.75em;color:#888;margin-top:4px;">{change}</div>' if change else ""
    unit_html = f'<div class="kpi-unit">{unit}</div>' if unit else ""
    return (
        f'        <div class="kpi-card">\n'
        f'            <div class="kpi-label">{label}</div>\n'
        f'            <div class="kpi-value" style="color:{color}">{value}</div>\n'
        f'            {unit_html}\n'
        f'            {change_html}\n'
        f'        </div>'
    )


def build_chapter_item(num, title, filename, period=""):
    period_tag = f'<span style="color:#aaa;font-size:0.85em;">{period}</span>' if period else ""
    return (
        f'        <li class="toc-item">\n'
        f'            <a href="{filename}">\n'
        f'                <span><span class="toc-num">{num:02d}.</span>{title} {period_tag}</span>\n'
        f'                <span class="toc-arrow">→</span>\n'
        f'            </a>\n'
        f'        </li>'
    )


def inject_summary_colors(html):
    """将摘要中7个主题序号标签替换为彩色 HTML span。

    遍历 HTML 中的所有 **bold** 块，检测是否以序号①-⑦开头：
      - 若 bold_content 以 "①政策重磅**：" 结尾（冒号在bold内）→ 直接替换
      - 若 bold_content 为 "①政策重磅" 且后跟 "：" 或 "：**" → 先替换bold，
        然后处理后续冒号（避免重复输出）
    """
    topics = [
        ("①", "s-label-1", "①政策重磅"),
        ("②", "s-label-2", "②市场涨价"),
        ("③", "s-label-3", "③区域扩张"),
        ("④", "s-label-4", "④国产突破"),
        ("⑤", "s-label-5", "⑤推理主导"),
        ("⑥", "s-label-6", "⑥供应链博弈"),
        ("⑦", "s-label-7", "⑦应用商业化"),
        ("⑧", "s-label-8", "⑧广东智算"),
    ]

    result = []
    i = 0
    while i < len(html):
        star = html.find("**", i)
        if star == -1:
            result.append(html[i:])
            break
        result.append(html[i:star])
        star2 = html.find("**", star + 2)
        if star2 == -1:
            result.append(html[star:])
            break
        bold_content = html[star + 2:star2]
        after_close = html[star2 + 2:]

        matched = False
        for prefix, cls, _ in topics:
            if bold_content.startswith(prefix):
                # 取冒号前的全部内容（如"①政策重磅"）
                display = bold_content.split("：")[0].split(":")[0]
                if not display:
                    display = bold_content
                # 情况1：冒号在 bold_content 内部（如 **①政策重磅**：xxx）
                if "：" in bold_content or ":" in bold_content:
                    result.append(f'<span class="s-label {cls}">{bold_content}：</span>')
                    matched = True
                    i = star2 + 2
                    break
                # 情况2：bold块仅为序号如 **①政策重磅**，冒号在闭包之后
                if after_close.startswith("：") or after_close.startswith(":"):
                    # 替换 bold 块
                    result.append(f'<span class="s-label {cls}">{display}：</span>')
                    matched = True
                    i = star2 + 3   # 跳过闭合 ** 后的冒号
                    break
                # 情况3：bold块后直接是正文（无冒号）
                result.append(f'<span class="s-label {cls}">{display}</span>')
                matched = True
                i = star2 + 2
                break

        if not matched:
            # 关键词回退：不匹配①~⑦时，按内容关键词匹配颜色
            keyword_fallbacks = [
                (["政策", "监管", "数据", "国务院", "发改委", "工信部", "国家数据"], "s-label-1"),
                (["涨价", "市场", "价格", "Token"], "s-label-2"),
                (["区域", "枢纽", "东数西算", "集群", "和林格尔", "中卫", "庆阳"], "s-label-3"),
                (["国产", "芯片", "昇腾", "寒武纪", "突破", "昆仑芯", "国产替代"], "s-label-4"),
                (["推理", "技术", "液冷", "AI芯片"], "s-label-5"),
                (["供应链", "存储", "HBM", "博弈", "DRAM", "美光", "SK"], "s-label-6"),
                (["应用", "商业化", "Robotaxi", "L4", "具身智能", "智元"], "s-label-7"),
                (["广东", "韶关", "粤港澳", "武江", "浈江", "EPC", "联通粤港澳", "智算中心"], "s-label-8"),
            ]
            kw_matched = False
            for keywords, cls in keyword_fallbacks:
                if any(kw in bold_content for kw in keywords):
                    result.append(f'<span class="s-label {cls}">{bold_content}：</span>')
                    kw_matched = True
                    i = star2 + 2
                    break
            if not kw_matched:
                result.append(bold_content)
                i = star2 + 2

    return "".join(result)


def run():
    print("=" * 50)
    print("gen_report_index.py - 首页生成器")
    print("=" * 50)

    skeleton = read_file(str(SKELETON_FILE))
    if not skeleton:
        print(f"错误：找不到骨架文件 {SKELETON_FILE}")
        return

    kpi_data = []
    if os.path.exists(SUMMARY_JSON):
        with open(SUMMARY_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
            kpi_data = data.get("data_cards", [])

    summary_text = read_file(SUMMARY_AI_TXT)
    if not summary_text:
        print("警告：找不到 AI 摘要，摘要区域将留空")

    from datetime import datetime
    today = datetime.now().strftime("%Y.%m.%d")
    period = f"第 1 期 · {today}"
    date_range = f"{today} — {today}"
    footer = f"中国智算市场周报 · {period} · 每周三更新 · 数据截至 {today.replace('.', '-')}"

    if os.path.exists(SUMMARY_JSON):
        with open(SUMMARY_JSON, "r", encoding="utf-8") as f:
            meta = json.load(f)
            period = meta.get("period", period)
            date_range = meta.get("date_range", date_range)
            footer = meta.get("footer", "")

    import glob
    existing = glob.glob(os.path.join(REPORT_DIR, "*分析报告.html"))
    if existing:
        existing.sort(key=os.path.getmtime, reverse=True)
        m = re.search(r'第(\d+)期', existing[0])
        if m:
            period = f"第 {m.group(1)} 期 · {today}"

    if kpi_data:
        kpi_html = "\n".join(build_kpi_card(k, i) for i, k in enumerate(kpi_data))
    else:
        empty_kpis = [
            {"label": "智能算力总规模", "value": "N/A", "unit": "EFLOPS", "change": ""},
            {"label": "算力市场规模", "value": "N/A", "unit": "亿元", "change": ""},
            {"label": "国产AI芯片份额", "value": "N/A", "unit": "%", "change": ""},
            {"label": "DeepSeek相关Token", "value": "N/A", "unit": "万亿Token/日", "change": ""},
            {"label": "AI应用市场规模", "value": "N/A", "unit": "亿元", "change": ""},
            {"label": "万卡智算集群", "value": "N/A", "unit": "", "change": ""},
        ]
        kpi_html = "\n".join(build_kpi_card(k, i) for i, k in enumerate(empty_kpis))

    chapters = [
        (1, "一、政策环境分析", "政策环境分析报告.html"),
        (2, "二、市场规模分析", "市场规模发展分析报告.html"),
        (3, "三、区域算力发展分析", "区域算力发展分析报告.html"),
        (4, "四、竞争格局分析", "竞争格局发展分析报告.html"),
        (5, "五、技术趋势分析", "技术趋势发展分析报告.html"),
        (6, "六、供应商与产业格局", "供应商与产业格局分析报告.html"),
        (7, "七、应用场景分析", "应用场景分析报告.html"),
        (8, "八、广东智算中心建设", "广东智算中心建设分析报告.html"),
        (9, "九、结论与建议", "结论与建议报告.html"),
    ]

    period_tag = ""
    m = re.search(r'第(\d+)期', period)
    if m:
        period_tag = f"第{m.group(1)}期"

    chapter_items_html = "\n".join(
        build_chapter_item(num, title, fname, period_tag) for num, title, fname in chapters
    )

    html = skeleton
    html = html.replace("{{PERIOD}}", period)
    html = html.replace("{{DATE_RANGE}}", date_range)
    html = html.replace("{{KPI_CARDS}}", kpi_html)
    # 注意：skeleton.html 已用 <p class="summary-text">{{SUMMARY_TEXT}}</p> 包裹，
    # 不再嵌套 <p>（HTML5 解析器会自动闭合外层 <p>，导致 CSS .summary-text 失效）
    # 方案A 修复（LRN-20260731-001）：<br><br> → 单 <br>，配合 skeleton.html line-height 1.8，
    # 段间空行从 ≈ 2 行降至 ≈ 1 行（视觉空行减半），保留呼吸感
    parts = [p.strip() for p in summary_text.split("\n") if p.strip()]
    summary_html = "".join(p.replace("\n", " ") + "<br>" for p in parts).rstrip("<br>")
    html = html.replace("{{SUMMARY_TEXT}}", summary_html)
    html = html.replace("{{CHAPTER_ITEMS}}", chapter_items_html)
    html = html.replace("{{FOOTER}}", footer)

    html = inject_summary_colors(html)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"\n✅ 首页已生成：{OUTPUT_FILE}")
    print(f"   期号：{period}")
    print(f"   KPI卡片：{len(kpi_data)} 个")
    print(f"   摘要字数：{len(summary_text)} 字")


if __name__ == "__main__":
    run()
