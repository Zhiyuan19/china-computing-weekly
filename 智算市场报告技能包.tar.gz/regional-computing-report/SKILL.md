---
name: regional-computing-report
description: 生成中国智算市场报告第三章内容-中国区域算力发展分析周报（HTML格式）。触发条件：用户要求生成区域算力/数据中心枢纽/东数西算/算力集群相关的周报、分析报告。核心功能：(1) 检索最新一周（7-14天）权威信源动态；(2) 与上周数据进行对比，量化周变化；(3) 对周变化进行深度分析；(4) 生成结构化HTML周报并保存本周基准数据供下期对比。
metadata:
  clawdbot:
    emoji: 🗺️
    requires:
      anyBins:
        - python3
---

> ⚠️ **本 skill 的所有命令假设工作目录为 `~/.openclaw/workspace/`**（即 openclaw workspace 根目录）。如从其他目录运行，请先 `cd ~/.openclaw/workspace`。

# 区域算力发展分析周报生成技能

## 核心设计思路

本skill专为"周更"报告设计，**变化追踪 + 深度分析**是核心：
- 不只是罗列静态数据，而是找出"这一周发生了什么"
- 每个数据表都包含"上周数据"和"本周数据"两列，量化变化

---

## ⚠️ 绝对禁令：禁止写入参考示例内容

### 🚫 严格禁止的行为

**以下内容**：
- `template_body.html` 中的**任何数据**（时间线事件、枢纽数据、表格数字、要闻列表、数据来源等）
- `assets/template.html` 中 body 部分的**任何内容**
- 任何其他模板文件中的**示例数据**

**严禁直接写入最终报告HTML**。模板骨架文件的作用是**提供结构和格式**，不是提供内容来源。

**违规后果**：subagent 若直接从模板复制数据（即使改了日期），将被主agent 识别为"几乎无新检索"，报告作废。

---

## ⚠️ 文件写入策略（必须遵守）

**模型输出流截断阈值约1027字符**，超过后工具调用参数不完整。**禁止直接生成大段HTML作为write参数**，会因截断导致文件不完整。

**必须采用两阶段模式：**
```
子agent步骤：
  1. write → /tmp/report_args.json（数据JSON，小文件<10KB，不会截断）
  2. write → /tmp/content_3_1.html 等（HTML片段，每个2-3KB，不会截断）
  3. exec → python3 scripts/generate_report.py（读取小文件→脚本生成完整HTML）
  4. 验证输出文件 > 20KB
```

**核心规则：** 写文件的是Python脚本，不是模型输出流。模型只负责写小文件+调用脚本。

**⚠️ 写入协议一致性（强制）：** JSON数据文件用 `json.dump()` 写 + `json.load()` 读；HTML内容文件用 `f.write()` 写纯文本 + `f.read()` 读。**禁止**对内容字符串再次 `json.dumps()` 编码后传参。
**⚠️ 防御性清洗（硬约束，LRN-20260821-001）：**

1. **HTML 内容文件严禁使用 `json.dump()` 写入** —— 会导致真实换行 0x0A 被 JSON 规范转义为 `\n` 两字符（JSON 字符串内转义）；后续通过 `f.read()` 读取后传入脚本会注入转义符
2. **禁止用 `f.read()` 读取 JSON 文件作为 `--content_X` 参数** —— JSON 文件首尾自带外层引号（`"..."`），`f.read()` 会带入；脚本 `decode_arg` 已升级兜底
3. **HTML 内容写入前必须自检**：
   ```bash
   grep -c '\\n' /tmp/content_*.html  # 真实合法 \\n 数为 0（必须用 <br> 标签代替）
   head -c 1 /tmp/content_*.html | grep -c '"'  # 首字符不为 "（0 = 正确）
   ```
4. **脚本 `decode_arg` 防御性兜底**（已升级，LRN-20260821-001）：自动剥离首尾多余引号 + 把 `\n` 两字符还原为真实换行。即便 subagent 错误使用 `json.dump` 写入，依然不污染 HTML


---

## 模板文件说明

**模板是神圣的，所有生成报告的HTML/CSS必须与模板完全一致。**

- `assets/template.html` — 完整HTML模板（**只读，供人工审查参考，body部分含占位符数据，不可用作内容来源**）
- `assets/template.css` — CSS样式文件（只读，所有报告共用）
- `assets/template_body.html` — HTML body内容模板（**只读，含占位符数据，不可用作内容来源**）
- `scripts/generate_report.py` — Python生成脚本（读取数据注入模板）
- `scripts/run.sh` — 运行入口（接收数据JSON路径）

**模板是基准，所有生成的报告与模板的差异只能来自数据内容不同，布局/排版/CSS必须100%一致。**

## 工作流程

### 第一步：读取上周基准数据

读取 `report/weekly_data/last_week.json`，获得上周基准数据。
- 若文件不存在（首次生成），跳过对比，仅标注"基准数据待建立"
- 将上周数据作为"上周基准"列写入各表格

### 第二步：并行检索本周动态（最新7-14天）

使用 `tavily_search` 并行检索，每个检索词 `max_results=5`，`search_depth="advanced"`：

```
1. "和林格尔 算力 新增 {CURRENT_YEAR}年{CURRENT_MONTH}"
2. "中卫 宁夏 算力 新增 {CURRENT_YEAR}年{CURRENT_MONTH}"
3. "韶关 粤港澳 万卡集群 {CURRENT_YEAR}年{CURRENT_MONTH}"
4. "庆阳 甘肃 智算 {CURRENT_YEAR}年{CURRENT_MONTH}"
5. "乌兰察布 算力 {CURRENT_YEAR}年{CURRENT_MONTH}"
6. "算力 枢纽 项目 开工 投产 {CURRENT_YEAR}年{CURRENT_MONTH}"
7. "算力 政策 PUE 绿电 {CURRENT_YEAR}年{CURRENT_MONTH}"
8. "芜湖 长三角 算力 {CURRENT_YEAR}年{CURRENT_MONTH}"
```

**优先选择文章日期在最近7-14天内的结果。**

### 第三步：深度采集

对权威页面使用 `tavily_extract`（`max_results=5 chunks`）：
- 新增算力项目名称、规模（万P）、投资额、投产时间
- 新出台的政策、补贴、规划调整
- 电价、绿电比例、PUE的最新变化

### 第四步：构建数据JSON

将整理好的数据写入 `/tmp/regional_data.json`，格式如下：

```json
{
  "report_date": "{REPORT_DATE}",
  "period_text": "{WEEK_NUMBER}",
  "period": "{CURRENT_PERIOD}",
  "source_note": "信源：Tavily搜索 · 权威媒体 · 各地政府公告",
  "overview": "本章关键概述段落（支持<strong><em>标签）",
  "data_cards": [
    {"label": "标签", "value": "数值", "sub": "说明"},
    ...
  ],
  "timeline": [
    {"date": "05-08", "title": "事件标题", "source": "来源", "impact": "影响说明"},
    ...
  ],
  "summary_hubs": [
    {
      "name": "和林格尔",
      "last_week": "XX万P",
      "this_week": "XX万P",
      "change": "持平/+X万P/-X万P",
      "change_rate": "+X%/-X%/-",
      "green_pct": "XX%",
      "driver": "驱动因素",
      "highlight": false
    },
    ...
  ],
  "analysis_summary": "深度分析段落",
  "hubs": [
    {
      "name": "3-1. 和林格尔",
      "subtitle": "副标题",
      "overview": "概述段落",
      "metrics": [
        {"指标": "指标名", "当前值": "XX", "变化": "持平/NEW/+XX", "说明": "..."},
        ...
      ],
      "analysis": "深度解读段落",
      "analysis_title": "深度解读标题",
      "is_new": false
    },
    ...
  ],
  "policy_table": "<tr>...<td>西部枢纽...</td><td>≤1.20</td>...</tr>\n...",
  "news_table": "<tr><td>05-08</td><td>事件</td><td>主体</td><td>...</td></tr>\n...",
  "sources": [
    "来源1（日期）— 内容摘要",
    ...
  ]
}
```

### 第五步：生成HTML报告

```bash
cd ~/.openclaw/workspace
python3 skills/regional-computing-report/scripts/generate_report.py /tmp/regional_data.json
```

脚本会：
1. 读取 `assets/template.css` 和 `assets/template_body.html`
2. 将 `/tmp/regional_data.json` 的数据注入模板
3. 输出到 `report/区域算力发展分析报告.html`

### 第六步：保存本周基准数据

每次生成报告后必须执行，将本期关键数据写入：
`report/weekly_data/last_week.json`

格式：
```json
{
  "report_date": "<本周日期>",
  "report_period": "<起止日期>",
  "hubs": {
    "<枢纽名>": {
      "total_p": 数字,
      "racks": 数字,
      "pue": 数字,
      "green_power_pct": 数字,
      "price": 数字,
      "notes": "本周变化说明"
    }
  },
  "significant_news_this_week": [...],
  "next_week_focus": "下期重点关注"
}
```

### 第七步：验证交付

- 文件大小 > 20KB
- 页面布局与 `assets/template.html` 完全一致（CSS类名、结构顺序）
- 周变化表格中"上周"和"本周"两列均有数据
- 确认有5条以上本周新动态
- 深度分析部分有实质性内容

## HTML/CSS规范（必须与模板一致）

### 页面结构顺序
1. `<div class="header">` — 深蓝渐变背景，报告标题
2. `<div class="container">` — 主容器
3. `<div class="all-chapters-nav">` — 全章导航
4. `<div class="chapter-overview">` — 本章关键概述
5. `<div class="data-note">` — 数据说明（单层，不要重复嵌套）
6. `<div class="data-cards">` — 4个数据卡片
7. `<div class="section" id="timeline">` — 时间线
8. `<div class="section" id="summary">` — 八大枢纽汇总表
9. `<div class="section" id="detail">` — 重点枢纽深度分析
10. `<div class="section" id="policy">` — 政策动态
11. `<div class="section">` — 要闻汇总
12. `<div class="sources">` — 数据来源
13. `<div class="chapter-nav">` — 翻页导航

### 关键CSS类
| 类名 | 用途 |
|------|------|
| `.header` | 深蓝渐变头部 |
| `.data-cards` | 4列网格数据卡片 |
| `.data-card` | 单个数据卡片（紫渐变背景） |
| `.timeline` | 左侧灰线+蓝色圆点时间线 |
| `.timeline-item` | 单个时间线项目 |
| `.timeline-date` | 红色日期 |
| `.timeline-impact` | 紫左边框影响说明 |
| `.week-highlight` | 绿色背景本周显著变化行 |
| `.analysis-box` | 紫渐变深度分析卡片 |
| `.news-table` | 要闻汇总表格 |
| `.chapter-overview` | 本章概述白底卡片 |
| `.sources` | 数据来源（上方36px边距） |

### HTML标注规范
- 增长：`<span class="change-up">+5000P</span>`（绿色加粗）
- 下降：`<span class="change-down">-3.2%</span>`（红色加粗）
- 持平：`<span class="change-flat">-</span>`（灰色）
- 本周新动态：`<span class="tag-new">NEW</span>`（绿色小标签）
- 本周显著变化行：`<tr class="week-highlight">`（浅绿背景）

### 颜色体系
- 主色：`#1a1a2e`（深蓝黑）
- 辅色：`#0f3460`（深蓝）
- 强调红：`#e53935`
- 上涨绿：`#2e7d32`
- 下跌红：`#c62828`
- 渐变：`linear-gradient(135deg, #667eea 0%, #764ba2 100%)`（紫渐变，用于data-card和analysis-box）

## 信源优先级

1. **各地政府公告/新闻办**（最新项目、政策）
2. **国资委/人民网/新华网**（权威，时效性强）
3. **信通院CAICT**（数据权威，更新频率低）
4. **新浪财经/DTData/21经济网**（项目动态灵敏）
5. **IDC & 浪潮信息**（适合季度对比）

---

## 常见错误与防范

### 错误1：直接从模板复制数据而不检索
**现象**：时间线8条事件日期全是旧日期（如04-13~04-22），枢纽数据和要闻列表与模板完全相同。
**防范**：生成报告前必须执行 `tavily_search` 步骤，报告正文中每个数字必须是本次检索的结果。

### 错误2：data-note 重复嵌套
**现象**：生成报告出现两层 `<div class="data-note">`。
**防范**：模板中 data-note 是单层，生成脚本只替换内容不新增标签。

### 错误3：模板骨架日期未更新
**现象**：时间线标题写"04-13~04-22"但实际报告周期是"05-08~05-14"。
**防范**：生成脚本的 `inject_data()` 函数会替换 header 中的周期字符串，确保数据JSON中 `period` 字段正确。

### 错误4：输出文件过小（<20KB）
**现象**：文件只有几KB，说明数据没有正确注入。
**防范**：检查 `/tmp/regional_data.json` 是否存在且格式正确，检查 `generate_report.py` 是否正常执行。