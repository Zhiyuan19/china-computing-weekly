#!/bin/bash
# =============================================================================
# 区域算力发展分析周报生成运行脚本
# 用法: bash run.sh /path/to/data.json
#
# ⚠️ 注意：数据JSON中的所有内容必须来自本次Tavily检索结果
# ⚠️ 严格禁止从模板文件（template_body.html / template.html）中复制数据
# =============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(dirname "$SCRIPT_DIR")"
ASSETS_DIR="$SKILL_DIR/assets"
DATA_FILE="${1:-}"

if [ -z "$DATA_FILE" ]; then
    echo "用法: bash run.sh /path/to/data.json"
    echo "示例: bash run.sh /tmp/regional_data.json"
    exit 1
fi

if [ ! -f "$DATA_FILE" ]; then
    echo "错误: 数据文件不存在: $DATA_FILE"
    exit 1
fi

# 运行Python生成脚本
python3 "$SCRIPT_DIR/generate_report.py" "$DATA_FILE"