#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
区域算力发展分析报告生成器
从 data.json 读取数据，注入 template_body.html 生成最终报告
模板使用 {{PLACEHOLDER}} 风格占位符
"""

import os
import sys
import json

# === 路径配置 ===
SKILL_DIR = '/home/clawhelper/.openclaw/workspace/skills/regional-computing-report/assets'
OUTPUT_DIR = '/home/clawhelper/.openclaw/workspace/report'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, '区域算力发展分析报告.html')
DATA_FILE = '/tmp/regional_data.json'


def load_css():
    """加载CSS模板"""
    with open(os.path.join(SKILL_DIR, 'template.css'), 'r', encoding='utf-8') as f:
        return f.read()


def load_body():
    """加载Body模板"""
    with open(os.path.join(SKILL_DIR, 'template_body.html'), 'r', encoding='utf-8') as f:
        return f.read()


def build_data_cards(cards):
    """构建 data-cards HTML"""
    html = ''
    for c in cards:
        html += (
            f'<div class="data-card">'
            f'<div class="label">{c["label"]}</div>'
            f'<div class="value">{c["value"]}</div>'
            f'<div class="sub">{c["sub"]}</div>'
            f'</div>\n'
        )
    return html


def build_timeline(items):
    """构建时间线 HTML"""
    html = ''
    for item in items:
        html += (
            f'<div class="timeline-item">'
            f'<div class="timeline-date">{item["date"]}</div>'
            f'<div class="timeline-title">{item["title"]}</div>'
            f'<div class="timeline-source">来源：{item["source"]}</div>'
            f'<div class="timeline-impact">{item["impact"]}</div>'
            f'</div>\n'
        )
    return html


def build_hub_detail(hub):
    """构建单个枢纽深度分析 HTML"""
    metrics_html = hub.get('metrics_table', '')
    if not metrics_html:
        rows = ''
        for m in hub.get('metrics', []):
            change_val = m.get('变化', '持平')
            # 根据变化值决定样式
            if change_val.startswith('+'):
                change_cell = f'<span class="change-up">{change_val}</span>'
            elif change_val.startswith('-'):
                change_cell = f'<span class="change-down">{change_val}</span>'
            else:
                change_cell = f'<span class="change-flat">{change_val}</span>'
            rows += f'<tr><td>{m["指标"]}</td><td>{m["当前值"]}</td><td>{change_cell}</td><td>{m["说明"]}</td></tr>\n'
        metrics_html = (
            '<table style="margin-top:12px;">\n'
            '<tr><th>指标</th><th>当前值</th><th>变化</th><th>说明</th></tr>\n'
            + rows +
            '</table>'
        )

    tag_new = '<span class="tag-new">NEW</span>' if hub.get('is_new', False) else ''

    analysis_box = ''
    analysis = hub.get('analysis', '')
    if analysis:
        analysis_box = (
            '<div class="analysis-box">\n'
            f'<h3>💡 深度解读：{hub.get("analysis_title", "深度分析")}</h3>\n'
            f'<p>{analysis}</p>\n'
            '</div>'
        )

    return (
        f'<h3 style="color:#1e3a5f;border-left:3px solid #38bdf8;padding-left:8px;margin:20px 0 10px;">'
        f'{hub["name"]}：{hub["subtitle"]} {tag_new}</h3>\n'
        f'<p style="font-size:0.85em;line-height:1.8;">{hub["overview"]}</p>\n'
        + metrics_html + '\n'
        + analysis_box + '\n'
    )


def build_hubs_section(hubs):
    """构建重点枢纽深度分析节"""
    return '\n'.join(build_hub_detail(h) for h in hubs)


def build_summary_table_rows(data):
    """构建八枢纽周变化汇总表行"""
    rows = ''
    for hub in data.get('summary_hubs', []):
        change = hub.get('change', '')
        change_class = 'change-flat'
        if isinstance(change, str) and change.startswith('+'):
            change_class = 'change-up'
        elif isinstance(change, str) and change.startswith('-'):
            change_class = 'change-down'

        week_highlight = ' class="week-highlight"' if hub.get('highlight', False) else ''

        rows += (
            f'<tr{week_highlight}>'
            f'<td>{hub["name"]}</td>'
            f'<td>{hub["last_week"]}</td>'
            f'<td>{hub["this_week"]}</td>'
            f'<td><span class="{change_class}">{change}</span></td>'
            f'<td>{hub.get("change_rate", "-")}</td>'
            f'<td>{hub["green_pct"]}</td>'
            f'<td>{hub["driver"]}</td>'
            f'</tr>\n'
        )
    return rows


def build_sources_list(sources):
    """构建数据来源 HTML"""
    html = ''
    for s in sources:
        html += f'    <li>{s}</li>\n'
    return html


def build_policy_rows(data):
    """构建政策动态表格行"""
    rows = ''
    for row in data:
        if isinstance(row, dict):
            rows += f'<tr><td>{row.get("区域","")}</td><td>{row.get("pue","")}</td><td>{row.get("绿电","")}</td><td>{row.get("补贴","")}</td></tr>\n'
        else:
            rows += f'<tr>{row}</tr>\n'
    return rows


def inject_data(body, data):
    """将数据注入模板，使用 {{PLACEHOLDER}} 风格占位符"""

    # === Header 周期 ===
    period = data.get('period', 'XXXX年XX月XX日 — XXXX年XX月XX日')
    period_num = data.get('period_text', '第X期')
    body = body.replace('{{PERIOD_PLACEHOLDER}}', period)
    body = body.replace('{{PERIOD_NUM}}', period_num)

    # === 信源行（使用data自带或默认） ===
    source_note = data.get('source_note', 'Tavily搜索 · 权威媒体 · 各地政府公告')

    # === 本章关键概述 ===
    body = body.replace('{{OVERVIEW_PLACEHOLDER}}', data.get('overview', '（请检索本周数据后填写）'))

    # === 数据卡片 ===
    cards_html = build_data_cards(data.get('data_cards', []))
    body = body.replace('{{DATA_CARDS_PLACEHOLDER}}', cards_html)

    # === 时间线 ===
    timeline_range = data.get('timeline_range', data.get('period', 'XXXX-XX-XX ~ XXXX-XX-XX'))
    body = body.replace('{{TIMELINE_RANGE}}', timeline_range)
    timeline_html = build_timeline(data.get('timeline', []))
    body = body.replace('{{TIMELINE_PLACEHOLDER}}', timeline_html)

    # === 八大枢纽周变化汇总表 ===
    summary_range = data.get('summary_range', '上期 vs 本期')
    body = body.replace('{{SUMMARY_RANGE}}', summary_range)
    summary_rows = build_summary_table_rows(data)
    body = body.replace('{{SUMMARY_TABLE_PLACEHOLDER}}', summary_rows)

    # === 深度分析（周变化特征）===
    body = body.replace('{{ANALYSIS_SUMMARY_PLACEHOLDER}}', data.get('analysis_summary', '（请基于本周检索数据撰写）'))

    # === 重点枢纽深度分析 ===
    if 'hubs' in data:
        hubs_html = build_hubs_section(data['hubs'])
        body = body.replace('{{HUB_DETAIL_PLACEHOLDER}}', hubs_html)
    else:
        body = body.replace('{{HUB_DETAIL_PLACEHOLDER}}', '<p style="color:#999;">（请检索并填充枢纽数据）</p>')

    # === 政策动态 ===
    policy_intro = data.get('policy_intro', '本周无新增政策动态（请检索后填写）')
    body = body.replace('{{POLICY_INTRO_PLACEHOLDER}}', policy_intro)

    policy_data = data.get('policy_table', [])
    if isinstance(policy_data, list):
        policy_rows = build_policy_rows(policy_data)
        body = body.replace('{{POLICY_TABLE_PLACEHOLDER}}', policy_rows)
    else:
        body = body.replace('{{POLICY_TABLE_PLACEHOLDER}}', str(policy_data))

    # === 要闻汇总表 ===
    if 'news_table' in data:
        news_html = data['news_table']
        if isinstance(news_html, list):
            rows = ''
            for n in news_html:
                if isinstance(n, dict):
                    stars = '★' * n.get('importance', 3)
                    star_style = 'style="color:#f59e0b"' if stars else ''
                    rows += f'<tr><td>{n.get("date","")}</td><td>{n.get("event","")}</td><td>{n.get("subject","")}</td><td {star_style}>{stars}</td></tr>\n'
            news_html = rows
        body = body.replace('{{NEWS_TABLE_PLACEHOLDER}}', news_html)
    else:
        body = body.replace('{{NEWS_TABLE_PLACEHOLDER}}', '<tr><td colspan="4">（请检索并填写本周要闻）</td></tr>')

    # === 数据来源 ===
    sources_html = build_sources_list(data.get('sources', ['（请检索并填写数据来源）']))
    body = body.replace('{{SOURCES_PLACEHOLDER}}', sources_html)

    return body


def generate_html(data):
    """生成完整HTML报告"""
    css = load_css()
    body = load_body()

    body = inject_data(body, data)

    html = (
        '<!DOCTYPE html>\n'
        '<html lang="zh-CN>\n'
        '<head>\n'
        '    <meta charset="UTF-8">\n'
        '    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f'    <title>三、区域算力发展分析周报 | {data.get("period_text", "第X期")}</title>\n'
        '    <style>\n'
        + css + '\n'
        '    </style>\n'
        '</head>\n'
        '<body>\n'
        + body + '\n'
        '</body>\n'
        '</html>\n'
    )
    return html


def main():
    input_file = sys.argv[1] if len(sys.argv) > 1 else DATA_FILE

    if not os.path.exists(input_file):
        print(f"错误: 数据文件不存在: {input_file}")
        sys.exit(1)

    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    html = generate_html(data)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f'✅ 报告已生成: {OUTPUT_FILE} ({len(html)} bytes)')


if __name__ == '__main__':
    main()