---
name: china-computing-conclusions-weekly-report
description: 中国智算结论与建议周更报告生成技能。当用户要求生成智算/算力行业的结论与建议报告、战略建议、未来展望时调用。本技能综合前八章（政策/市场/区域/竞争/技术/供应商/应用/建设）的最新周报数据，提炼5大核心发现、3类主体（政府/运营商/企业）各3条战略建议、未来发展展望与本周总结，生成结构化的HTML结论报告。报告为某完整智算报告的第九章（结论与建议），因此所有章节编号均从9-1、9-2开始。
metadata:
  clawdbot:
    emoji: 💡
    requires:
      anyBins:
        - python3
---

# 中国智算结论与建议周更报告技能

## 核心定位

**模板文件（骨架基准）：**
```
skills/china-computing-conclusions-weekly-report/template/conclusions_skeleton.html
```

> ⚠️ **HTML布局排版规范：** 每周生成的报告 HTML 内容必须与 `conclusions_skeleton.html` 保持100%一致。骨架文件包含完整的 HTML/CSS 结构，所有数据插槽以 `{{FINDINGS_TABLE_ROWS}}`、`{{FORECAST_GRID}}` 等占位符标注，由脚本运行时填充。CSS 样式统一保存在 `template/conclusions_template.html`（内含完整 CSS 内容），不得自行修改样式规则。模板文件单独保存在 `template/` 目录，报告目录只存放每周生成的报告 HTML 文件。

---

## ⚠️ 文件写入策略（必须遵守）

**模型输出流截断阈值约1027字符**，超过后工具调用参数不完整。**禁止直接生成大段HTML作为write参数**，会因截断导致文件不完整。

**必须采用两阶段模式：**
```
子agent步骤：
  1. write → /tmp/report_args.json（数据JSON，小文件<10KB，不会截断）
  2. write → /tmp/content_9_1.html 等（HTML片段，每个2-3KB，不会截断）
  3. exec → python3 scripts/generate_weekly_report.py（读取小文件→脚本生成完整HTML）
  4. 验证输出文件 > 20KB
```

**核心规则：** 写文件的是Python脚本，不是模型输出流。模型只负责写小文件+调用脚本。

**⚠️ 写入协议一致性（强制）：** 写文件方式必须与读文件方式匹配，否则会导致 `\"` 转义残留：
- **JSON数据文件**（如 `chapter9_findings.json`）→ 用 `json.dump()` 写 + `json.load()` 读
- **HTML内容文件**（如 `chapter9_9_2_gov.html`）→ 用 `f.write()` 写纯文本 + `f.read()` 读
- **禁止**对HTML内容文件使用 `json.dump()` 写入，否则内容中的 `"` 会被转义为 `\"` 无法自动还原

---

## 报告结构

---

本技能生成**完整报告第九章的结论与建议周报**，章节序号从 **9-1、9-2、9-3…** 开始。HTML格式骨架基准为 `template/conclusions_skeleton.html`，严格保持结构一致；CSS 样式以 `template/conclusions_template.html` 为准。

**本技能的核心原则：**
- 结论与建议必须基于前八章（第一章政策环境、第二章市场规模、第三章区域算力、第四章竞争格局、第五章技术趋势、第六章供应商、第七章应用场景、第八章广东智算中心建设）的最新数据
- 每周从前八章周报中提取核心结论，形成本章综合分析
- 战略建议要有具体可操作性，不能空洞
- 未来展望需要量化预测，基于最新市场数据

---

## 报告结构（章节编号从9-1开始）

```
九、结论与建议（第X期）
├── 9-1 本周核心发现（从前八章提取的5大核心结论，findings-table格式）
├── 9-2 战略建议
│   ├── 9-2-1 对政府决策部门的建议（suggestion-box格式）
│   ├── 9-2-2 对电信运营商的建议
│   └── 9-2-3 对算力需求企业的建议
├── 9-3 未来发展展望
│   ├── 9-3-1 市场规模预测（未来5年，forecast-grid卡片格式）
│   ├── 9-3-2 技术发展趋势（highlight-box格式）
│   └── 9-3-3 产业发展趋势（highlight-box格式）
└── 9-4 本周总结（4个summary-box格式）
```

---

## 各章节内容规范

### 9-1 本周核心发现

**核心发现表格格式（findings-table）：**

每条发现包含：发现标题（第一列）+ 数据支撑（第二列）

| 发现标题 | 数据支撑 |
|---------|---------|
| 发现一：推理算力占比突破70%临界点 | AI推理算力占总算力需求达72.6%，较上周+3.3个百分点。全球Token年消耗量预计从2025年0.0005PetaTokens暴增至2030年15万PetaTokens，复合增长率超3000%。 |
| 发现二：全球Token调用量连续两周下滑 | 中国AI模型周调用量4.44万亿，环比-23.8%，美国4.91万亿反超。阿里云/腾讯/百度涨价约30%。 |
| 发现三：国产AI芯片份额有望首破50% | 2025年国产AI加速卡出货165万张（占比41%），DeepSeek V4预计4月下旬发布，将率先支持华为昇腾950PR。 |
| 发现四：L4自动驾驶从测试车队跃入消费级量产 | 小鹏GX发布（3000TOPS算力）、特斯拉Cybercab 4月量产（无方向盘，每公里1.4美元）、工信部L3/L4强制国标发布。 |
| 发现五：政策背书AI商业化元年 | 国内AI应用月活4.46亿（3月），豆包3月Token使用量120万亿（三个月翻倍）。 |

**⚠️ 建设类发现（必须至少1条来自第八章广东智算中心建设）：**

5大核心发现中**至少1条必须基于第八章数据**（广东智算建设），示例：

| 发现标题 | 数据支撑 |
|---------|---------|
| 发现X：广东智算基建进入"多期滚动发包"冲刺期 | 韶关集群电信/移动/联通三大运营商多期滚动发包（电信A3A4工程EPC约4.04亿、浈江/韶塘自建220kV变电站EPC、联通数据中心4机电EPC×3），信息表收录48条项目，韶关占38%。 |

**第八章数据来源指引**：从 `report/广东智算中心建设分析报告.html` 提取——
- **8-2 信息表**：项目数、投资额、运营商分布（电信/移动/联通各多少条）
- **8-3 按城市汇总**：韶关占比、广州/深圳/佛山等城市布局
- **8-4 按招标类型汇总**：土建EPC/机电EPC/外电/设备采购各类型数量
- **8-5 征地/土建/机电分类动态**：三类工程建设阶段

---

### 9-2 战略建议

**三类主体，每类3条建议，每条建议格式：**

```html
<div class="suggestion-box">
<h4>① 建议标题</h4>
<ul>
<li><strong>背景：</strong>背景说明</li>
<li><strong>建议：</strong>（1）建议内容；（2）建议内容；（3）建议内容</li>
<li><strong>量化目标：</strong>量化指标（可选）</li>
</ul>
</div>
```

**政府决策部门建议示例：**
```html
<div class="suggestion-box">
<h4>① 加速主权AI基础设施建设，布局太空算力</h4>
<ul>
<li><strong>背景：</strong>全球AI竞争已从模型参数比拼转向应用落地与算力自主，电力约束日益凸显（2030年单个AI训练点电力需求或达8GW）。</li>
<li><strong>建议：</strong>（1）加快本土AIDC高密度智算中心建设，液冷+PUE严控1.2以下；（2）布局天基算力，低轨算力网进入工程化阶段后将是全球主权竞争新赛道；（3）适度超前建设移动物联网、6G、卫星互联网，支撑边缘算力网络。</li>
<li><strong>量化目标：</strong>2027年前自主可控算力占比达60%以上。</li>
</ul>
</div>
```

---

### 9-3 未来发展展望

**9-3-1 市场规模预测卡片格式（forecast-grid）：**

```html
<div class="forecast-grid">
<div class="forecast-card">
    <div class="year">2026年</div>
    <div class="value">智算市场规模预测</div>
    <div class="note">中国AI算力市场规模预计达8000-10000亿元，推理算力占比突破75%。</div>
</div>
<div class="forecast-card">
    <div class="year">2027年</div>
    <div class="value">L3规模量产元年</div>
    <div class="note">L3自动驾驶渗透率突破30%。</div>
</div>
...
</div>
```

**9-3-2 和 9-3-3 技术/产业趋势格式（highlight-box）：**

```html
<div class="highlight-box">
<h4>三大技术趋势</h4>
<ul>
<li><strong>趋势一：推理算力主导化</strong> — 趋势说明文字。</li>
<li><strong>趋势二：VLA端到端大模型量产上车</strong> — 趋势说明文字。</li>
<li><strong>趋势三：液冷+光互联重塑AIDC</strong> — 趋势说明文字。</li>
</ul>
</div>
```

---

### 9-4 本周总结

**4个summary-box格式：**

```html
<div class="summary-box">
<h4>一、本周结论总述</h4>
<p>总结内容段落...</p>
</div>
<div class="summary-box">
<h4>二、关键数据回顾</h4>
<p><strong>市场规模：</strong>数据内容</p>
<p><strong>竞争格局：</strong>数据内容</p>
<p><strong>应用落地：</strong>数据内容</p>
</div>
<div class="summary-box">
<h4>三、下周重点关注</h4>
<p><strong>DeepSeek V4发布（预计4月下旬）：</strong>事件说明...</p>
</div>
<div class="summary-box">
<h4>四、风险提示</h4>
<p><strong>算力涨价持续：</strong>风险说明...</p>
</div>
```

---

## HTML格式规范（与 conclusions_skeleton.html 完全一致）

| 要素 | 规范 |
|------|------|
| header背景 | `linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)` |
| 章节h2 | `17px, #1a1a2e, 2px solid #0f3460底部边框` |
| 数据说明 | `data-note`, `#e8f4fd`背景, 左侧4px `#2196F3`边框 |
| 核心发现表格 | `findings-table`, 第一列120px宽, 加粗蓝色 |
| 建议卡片 | `suggestion-box`, `#f8f9fc`背景, 左侧4px `#2196F3`边框 |
| 预测卡片网格 | `forecast-grid`, `auto-fit minmax(220px,1fr)` |
| 深度专题 | `highlight-box`, `linear-gradient(135deg, #667eea 0%, #764ba2 100%)`, 白色文字 |
| 总结卡片 | `summary-box`, 渐变蓝白背景, 左侧5px `#2196F3`边框 |
| 表格表头 | `#1a1a2e` 背景 |
| 上涨标注 | `change-up`: `#2e7d32`（绿色） |
| 下跌标注 | `change-down`: `#c62828`（红色） |
| 持平标注 | `change-flat`: `#888`（灰色） |
| 来源标签 | `source-tag`, 圆角胶囊样式 |
| 全章导航 | `all-chapters-nav` + `chapter-tabs`, 8章横向跳转 |
| 翻页导航 | `chapter-nav`, 三个链接（上一章/首页/下一章） |

---

## 信息检索规范

### 必读前八章周报

生成本章前，必须读取前八章最新周报：
```
report/政策环境分析报告.html（第一章）
report/市场规模发展分析报告.html（第二章）
report/区域算力发展分析报告.html（第三章）
report/竞争格局发展分析报告.html（第四章）
report/技术趋势发展分析报告.html（第五章）
report/供应商与产业格局分析报告.html（第六章）
report/应用场景分析报告.html（第七章）
report/广东智算中心建设分析报告.html（第八章）
```

### 核心检索词

```
"IDC 中国智能算力 规模预测 2026"
"中国信通院 综合算力指数"
"运营商 云 营收 2026"
"国产芯片 昇腾 寒武纪 海光 进展"
"液冷数据中心 PUE 最新"
"AI Agent 应用落地 2026"
"具身智能 机器人 商业化"
"DeepSeek V4 发布 昇腾950PR"
"Token 词元 市场规模 2026"
```

---

## 完整工作流程

### 阶段1 — 读取前八章周报

读取前八章最新HTML报告（含第八章广东智算中心建设），提取核心数据和结论。

### 阶段2 — 数据编译

```json
{
  "findings": [
    {"finding": "发现标题", "data": "数据支撑内容", "source": "来源章节"},
    ...
  ],
  "suggestions_gov": ["<div class=suggestion-box>...</div>", ...],
  "suggestions_op": ["<div class=suggestion-box>...</div>", ...],
  "suggestions_ent": ["<div class=suggestion-box>...</div>", ...],
  "predictions": [
    {"year": "2026年", "value": "智算市场规模预测", "note": "预测说明"},
    ...
  ],
  "tech_trends": "<div class=highlight-box>...</div>",
  "industry_trends": "<div class=highlight-box>...</div>",
  "summary_9_4": "<div class=summary-box>...</div><div class=summary-box>...</div>...",
  "sources": ["来源1", "来源2", ...]
}
```

### 阶段3 — 调用生成脚本

```bash
python3 skills/china-computing-conclusions-weekly-report/scripts/generate_weekly_report.py \
  --date 2026-04-27 \
  --date_from 2026-04-20 \
  --week_number 第17期 \
  --findings_json '[{"finding":"发现一","data":"数据内容","source":"第二章"},{"finding":"发现二","data":"数据内容","source":"第三章"}]' \
  --content_9_2_gov '<div class="suggestion-box">...</div>' \
  --content_9_2_op '<div class="suggestion-box">...</div>' \
  --content_9_2_ent '<div class="suggestion-box">...</div>' \
  --predictions_json '[{"year":"2026年","value":"智算市场规模预测","note":"..."}]' \
  --content_9_3_tech '<div class="highlight-box">...</div>' \
  --content_9_3_industry '<div class="highlight-box">...</div>' \
  --content_9_4 '<div class="summary-box">...</div>' \
  --sources_json '["来源1","来源2"]' \
  --output report/结论与建议报告.html
```

### 阶段4 — 验证输出

- 文件存在且 > 20KB（内容过少说明分析不充分）
- 章节编号 9-1 ~ 9-4 全部存在
- 9-1核心发现表格有数据（≥5条）**且至少1条来自第八章（广东智算中心建设）**
- 9-2三类建议各3条（共9条）
- 9-3预测卡片4张 + 技术趋势 + 产业趋势
- 9-4总结有4个summary-box
- 全章导航（chapter-tabs）和翻页导航（chapter-nav）正常显示

---

## 关键规则

1. **章节编号：** 所有章节标题从 9-1、9-2… 开始
2. **结论必须有数据支撑：** 每条核心发现须有具体数字
3. **建议必须具体：** 禁止空洞表述，如"加强合作"等
4. **预测必须有依据：** 基于IDC、中国信通院等权威数据
5. **来源标注：** 结论数据须标注来自第几章
6. **报告期号：** 每期报告需有期号（如"第16期"）
7. **禁止空洞总结：** 9-4总结须有具体内容，不能只写"本周无重大变化"
8. **骨架文件不可修改：** CSS和HTML结构以 template/ 目录下的文件为准
9. **⚠️ 9-4下周重点关注严禁自行编造：** 必须从第一章"1-7 政策趋势与下周预判"和第二章"2-7 市场规模预测更新"的"重点关注事项"中提取，每条须标注"（来源：第X章X-?）"。若前八章均无相关预报，才可标注"暂无预报数据"，禁止凭空添加"预计""可能"类预测。