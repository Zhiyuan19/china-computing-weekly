#!/usr/bin/env python3
"""
中国智算结论与建议周报HTML生成脚本 v5
基准骨架：../template/conclusions_skeleton.html
基准样式：../template/conclusions_template.html（仅提取CSS）
运行时读取骨架，填充本周数据，输出干净HTML
"""

import argparse
import json
import os
import re
from datetime import datetime, timedelta

SCRIPT_DIR = os.path.dirname(__file__)
SKELETON_PATH = os.path.join(SCRIPT_DIR, "..", "template", "conclusions_skeleton.html")
CSS_PATH = os.path.join(SCRIPT_DIR, "..", "template", "conclusions_template.html")

# 从 conclusions_template.html 提取纯CSS（有<style>则提取内容，无则直接读取）
with open(CSS_PATH, "r", encoding="utf-8") as f:
    raw = f.read()
css_match = re.search(r'<style>(.*?)</style>', raw, re.DOTALL)
CSS_CONTENT = css_match.group(1).strip() if css_match else raw.strip()

# 读取骨架模板
with open(SKELETON_PATH, "r", encoding="utf-8") as f:
    SKELETON = f.read()


def build_findings_table(findings_data):
    """生成核心发现表格行"""
    rows = []
    for item in findings_data:
        finding = item.get("finding", "")
        data = item.get("data", "")
        rows.append(
            f"<tr>\n"
            f"    <td>{finding}</td>\n"
            f"    <td>{data}</td>\n"
            f"</tr>"
        )
    return "\n".join(rows)


def build_forecast_grid(predictions):
    """生成预测卡片网格"""
    cards = []
    for item in predictions:
        year = item.get("year", "")
        value = item.get("value", "")
        note = item.get("note", "")
        cards.append(
            f'<div class="forecast-card">\n'
            f'    <div class="year">{year}</div>\n'
            f'    <div class="value">{value}</div>\n'
            f'    <div class="note">{note}</div>\n'
            f'</div>'
        )
    return "\n".join(cards)


def build_sources(source_list):
    """生成来源标签 HTML"""
    return "\n".join(f'<span class="source-tag">{s}</span>' for s in source_list)


def fill_skeleton(
    week_number, date, date_from,
    findings_rows,
    content_9_2_gov, content_9_2_op, content_9_2_ent,
    forecast_grid_html,
    content_9_3_tech, content_9_3_industry,
    content_9_4,
    sources_list_html
):
    """将所有占位符替换为实际内容，生成最终HTML"""
    date_range = f"{date_from}—{date}"
    year = date[:4]

    replacements = {
        "{{WEEK_NUMBER}}": week_number,
        "{{DATE_RANGE}}": date_range,
        "{{DATE_FROM}}": date_from,
        "{{DATE}}": date,
        "{{FINDINGS_TABLE_ROWS}}": findings_rows,
        "{{CONTENT_9_2_GOV}}": content_9_2_gov or "<p>暂无建议。</p>",
        "{{CONTENT_9_2_OP}}": content_9_2_op or "<p>暂无建议。</p>",
        "{{CONTENT_9_2_ENT}}": content_9_2_ent or "<p>暂无建议。</p>",
        "{{FORECAST_GRID}}": forecast_grid_html,
        "{{CONTENT_9_3_TECH}}": content_9_3_tech or "<p>暂无展望。</p>",
        "{{CONTENT_9_3_INDUSTRY}}": content_9_3_industry or "<p>暂无展望。</p>",
        "{{CONTENT_9_4}}": content_9_4 or "<p>暂无总结。</p>",
        "{{SOURCES_LIST}}": sources_list_html,
        "{{YEAR}}": year,
        "{{STYLE_CSS}}": CSS_CONTENT,
    }

    html = SKELETON
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html


def main():
    parser = argparse.ArgumentParser(description="生成中国智算结论与建议周报HTML v5（基于骨架模板）")
    parser.add_argument("--date", required=True, help="报告日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD")
    parser.add_argument("--week_number", default="第X期", help="周报期号")
    parser.add_argument("--findings_json", default="[]", help="核心发现JSON [{finding, data, source}]")
    parser.add_argument("--content_9_2_gov", default="", help="9-2-1 政府建议HTML")
    parser.add_argument("--content_9_2_op", default="", help="9-2-2 运营商建议HTML")
    parser.add_argument("--content_9_2_ent", default="", help="9-2-3 企业建议HTML")
    parser.add_argument("--predictions_json", default="[]", help="预测数据JSON [{year, value, note}]")
    parser.add_argument("--content_9_3_tech", default="", help="9-3-2 技术趋势HTML")
    parser.add_argument("--content_9_3_industry", default="", help="9-3-3 产业趋势HTML")
    parser.add_argument("--content_9_4", default="", help="9-4 总结HTML")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON")
    parser.add_argument("--output", required=True, help="输出HTML路径")
    args = parser.parse_args()

    # 解析JSON
    findings_data = json.loads(args.findings_json)
    predictions_data = json.loads(args.predictions_json)
    sources_list = json.loads(args.sources_json)

    # 以下字符串参数从子进程传入（含JSON编码），需反序列化
    def decode_arg(s):
        if not s:
            return ""
        try:
            return json.loads(s)
        except Exception:
            return s

    content_9_2_gov = decode_arg(args.content_9_2_gov)
    content_9_2_op = decode_arg(args.content_9_2_op)
    content_9_2_ent = decode_arg(args.content_9_2_ent)
    content_9_3_tech = decode_arg(args.content_9_3_tech)
    content_9_3_industry = decode_arg(args.content_9_3_industry)
    content_9_4 = decode_arg(args.content_9_4)

    # 计算日期范围
    base_date = datetime.strptime(args.date, "%Y-%m-%d")
    prev_week_end = base_date - timedelta(days=1)
    prev_week_start = (prev_week_end - timedelta(days=6)).strftime("%Y-%m-%d")
    date_from = args.date_from or prev_week_start

    # 生成各模块HTML
    findings_rows = build_findings_table(findings_data)
    forecast_grid_html = build_forecast_grid(predictions_data)
    sources_html = build_sources(sources_list)

    # 填充骨架
    html = fill_skeleton(
        week_number=args.week_number,
        date=args.date,
        date_from=date_from,
        findings_rows=findings_rows,
        content_9_2_gov=content_9_2_gov,
        content_9_2_op=content_9_2_op,
        content_9_2_ent=content_9_2_ent,
        forecast_grid_html=forecast_grid_html,
        content_9_3_tech=content_9_3_tech,
        content_9_3_industry=content_9_3_industry,
        content_9_4=content_9_4,
        sources_list_html=sources_html,
    )

    # 检查未替换的占位符
    unfilled = re.findall(r'\{\{[\w_]+\}\}', html)
    if unfilled:
        print(f"⚠️ 警告：以下占位符未替换：{set(unfilled)}")

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"✅ 报告已生成：{args.output}")
    print(f"   文件大小：{len(html):,} bytes")


if __name__ == "__main__":
    main()