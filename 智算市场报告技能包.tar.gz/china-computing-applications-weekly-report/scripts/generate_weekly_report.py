#!/usr/bin/env python3
"""
中国智算应用场景分析周报HTML生成脚本
基于 skeleton.html 模板生成，章节编号从 7-1、7-2 开始
用法：
  python3 generate_weekly_report.py --date 2026-04-20 --week_number 第16期 \
    --overview_text "本周..." --data_cards "..." --data_table_rows "..." \
    --timeline_html "..." --content_7_3 "..." --content_7_4 "..." \
    --content_7_5 "..." --content_7_6 "..." --content_7_7 "..." \
    --news_table_html "..." --sources_html "..." --output report/应用场景分析报告.html
"""

import argparse
import json
import os
import re
from datetime import datetime, timedelta

# 技能目录
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH = os.path.join(SCRIPT_DIR, "..", "templates", "skeleton.html")

def load_template():
    """从模板文件加载骨架HTML"""
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        return f.read()

def build_data_cards(data_cards_json):
    """构建数据卡片HTML"""
    cards = []
    for item in data_cards_json:
        cards.append(f'''<div class="data-card">
    <div class="label">{item.get("label", "")}</div>
    <div class="value">{item.get("value", "")}<span class="unit">{item.get("unit", "")}</span></div>
    <div class="change">{item.get("change", "")}</div>
</div>''')
    return "\n".join(cards)

def build_data_table_rows(rows_json):
    """构建数据表格行HTML"""
    rows = []
    for row in rows_json:
        rows.append(f'''<tr>
    <td><strong>{row.get("label", "")}</strong></td>
    <td>{row.get("time_dim", "")}</td>
    <td>{row.get("prev", "")}</td>
    <td>{row.get("curr", "")} {row.get("unit", "")}</td>
    <td>{row.get("change_str", "")}</td>
    <td>{row.get("analysis", "")}</td>
</tr>''')
    return "\n".join(rows)

def parse_chinese_date(date_str):
    """解析中文日期字符串 '5月9日' 或 '5月13-14日' 或 '4月24-26日'，返回用于排序的(月, 日)元组"""
    import re
    m = re.search(r'(\d+)月(\d+)', date_str)
    if m:
        month = int(m.group(1))
        day_str = m.group(2).split('-')[0]  # 取范围起始日
        day = int(day_str)
        return (month, day)
    # 回退：提取所有数字排序
    nums = re.findall(r'\d+', date_str)
    if nums:
        return (int(nums[0]), int(nums[1]) if len(nums) > 1 else 0)
    return (0, 0)

def build_timeline(timeline_data):
    """构建时间线HTML，按日期降序排列（从新到旧）"""
    # 按日期降序排列（解析中文日期格式）
    sorted_data = sorted(timeline_data, key=lambda x: parse_chinese_date(x.get("date", "")), reverse=True)
    items = []
    for item in sorted_data:
        items.append(f'''<div class="timeline-item">
    <div class="timeline-date">{item.get("date", "")}</div>
    <div class="timeline-title">{item.get("title", "")}</div>
    <div class="timeline-source">{item.get("source", "")}</div>
    <div class="timeline-impact">{item.get("impact", "")}</div>
</div>''')
    return "\n".join(items)

def build_news_table(news_items):
    """构建要闻汇总表HTML，按日期降序排列（从新到旧）"""
    # 按日期降序排列（解析中文日期格式）
    sorted_items = sorted(news_items, key=lambda x: parse_chinese_date(x.get("date", "")), reverse=True)
    header = '''<table class="policy-table">
<thead>
<tr>
    <th>日期</th>
    <th>事件</th>
    <th>主体</th>
    <th>规模/数据</th>
    <th>重要度</th>
</tr>
</thead>
<tbody>
'''
    rows = []
    for item in sorted_items:
        stars = "★" * item.get("importance", 3)
        rows.append(f'''<tr>
    <td>{item.get("date", "")}</td>
    <td>{item.get("event", "")}</td>
    <td>{item.get("subject", "")}</td>
    <td>{item.get("scale", "—")}</td>
    <td><span class="change-new">{stars}</span></td>
</tr>''')
    footer = '''</tbody>
</table>'''
    return header + "\n".join(rows) + "\n" + footer

def build_sources(source_list):
    """构建数据来源标签HTML"""
    tags = [f'<span class="source-tag">{s}</span>' for s in source_list]
    return "\n".join(tags)

def render_template(
    week_number, date, date_from, date_range,
    overview_text,
    data_cards, data_table_rows,
    timeline_html,
    content_7_3, content_7_4, content_7_5, content_7_6, content_7_7,
    news_table_html, sources_html
):
    """将数据填充进骨架HTML模板"""
    template = load_template()

    # 计算上周日期范围
    base_date = datetime.strptime(date, "%Y-%m-%d")
    prev_week_end = base_date - timedelta(days=1)
    prev_week_start = prev_week_end - timedelta(days=6)
    prev_week_range = f"{prev_week_start.strftime('%Y-%m-%d')}—{prev_week_end.strftime('%Y-%m-%d')}"

    replacements = {
        "{{WEEK_NUMBER}}": week_number,
        "{{DATE}}": date,
        "{{DATE_FROM}}": date_from or prev_week_start.strftime("%Y-%m-%d"),
        "{{DATE_RANGE}}": date_range,
        "{{OVERVIEW_TEXT}}": overview_text or "<p>本周暂无概述。</p>",
        "{{DATA_CARDS}}": data_cards or "",
        "{{DATA_TABLE_ROWS}}": data_table_rows or "",
        "{{TIMELINE_HTML}}": timeline_html or "",
        "{{CONTENT_7_3}}": content_7_3 or "<p>本周暂无深度解读。</p>",
        "{{CONTENT_7_4}}": content_7_4 or "<p>本周暂无算力需求分析。</p>",
        "{{CONTENT_7_5}}": content_7_5 or "<p>本周暂无趋势变化分析。</p>",
        "{{CONTENT_7_6}}": content_7_6 or "<p>本周暂无驱动因素变化。</p>",
        "{{CONTENT_7_7}}": content_7_7 or "<p>本周暂无预判更新。</p>",
        "{{NEWS_TABLE_HTML}}": news_table_html or "<p>本周暂无要闻。</p>",
        "{{SOURCES_HTML}}": sources_html or "",
        "{{YEAR}}": date[:4] if date else "2026",
    }

    html = template
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html

def main():
    parser = argparse.ArgumentParser(description="生成中国智算应用场景分析周报HTML")
    parser.add_argument("--date", required=True, help="报告结束日期 YYYY-MM-DD")
    parser.add_argument("--date_from", default=None, help="报告开始日期 YYYY-MM-DD（本周起始）")
    parser.add_argument("--week_number", default="第16期", help="周报期号")
    parser.add_argument("--date_range", default=None, help="完整日期范围字符串（如不填则自动计算）")
    parser.add_argument("--overview_text", default="", help="本章关键概述文字")
    parser.add_argument("--data_cards_json", default="[]", help="数据卡片JSON数组")
    parser.add_argument("--data_table_json", default="[]", help="数据表格行JSON数组")
    parser.add_argument("--timeline_json", default="[]", help="时间线数据JSON数组")
    parser.add_argument("--news_json", default="[]", help="要闻JSON数组")
    parser.add_argument("--sources_json", default="[]", help="数据来源JSON数组")
    parser.add_argument("--content_7_3", default="", help="7-3章节HTML内容")
    parser.add_argument("--content_7_4", default="", help="7-4章节HTML内容")
    parser.add_argument("--content_7_5", default="", help="7-5章节HTML内容")
    parser.add_argument("--content_7_6", default="", help="7-6章节HTML内容")
    parser.add_argument("--content_7_7", default="", help="7-7章节HTML内容")
    parser.add_argument("--output", required=True, help="输出HTML路径")
    args = parser.parse_args()

    # 计算日期范围
    if args.date_from:
        date_from_str = args.date_from
    else:
        base_date = datetime.strptime(args.date, "%Y-%m-%d")
        prev_week_end = base_date - timedelta(days=1)
        prev_week_start = prev_week_end - timedelta(days=6)
        date_from_str = prev_week_start.strftime("%Y-%m-%d")

    if args.date_range:
        date_range = args.date_range
    else:
        date_range = f"{date_from_str}—{args.date}"

    # 解析JSON数据
    data_cards_json = json.loads(args.data_cards_json)
    data_table_json = json.loads(args.data_table_json)
    timeline_data = json.loads(args.timeline_json)
    news_items = json.loads(args.news_json)
    sources_list = json.loads(args.sources_json)

    # 以下字符串参数从子进程传入（含JSON编码），需反序列化
def decode_arg(s):
        """反序列化通过JSON编码传入的字符串参数；防御性清洗 \\n 两字符 + 残留外层引号

        LRN-20260821-001: subagent 误用 json.dump 写 HTML 内容文件，导致真换行 0x0A
        被 JSON 规范转义为 \\n 两字符；f.read() 读 JSON 文件时带入外层引号。
        decode_arg 防御性兜底：剥离外层引号 + 还原 \\n → 真实换行。
        """
        if not s:
            return ""
        try:
            result = json.loads(s)
        except Exception:
            result = s

        # 防御性清洗：消除 JSON 残留转义
        if isinstance(result, str):
            # 1. 剥离首尾多余引号（subagent 用 f.read() 读 JSON 文件时带入）
            if result.startswith('"') and result.endswith('"'):
                inner = result[1:-1]
                # 内部引号成对（偶数）才剥离
                if inner.count('\\"') % 2 == 0 and inner.count('"') % 2 == 0:
                    result = inner
            # 2. JSON 字符串内的 \\n 转义（两字符）→ 真实换行
            result = result.replace('\\n', '\n')

        return result
if __name__ == "__main__":
    main()
