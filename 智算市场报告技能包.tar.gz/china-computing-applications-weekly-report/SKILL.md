---
name: china-computing-applications-weekly-report
description: 中国智算应用场景分析周更报告生成技能。当用户要求生成智算/算力/AI应用场景等行业的应用周度分析报告、应用场景报告、应用周报时调用。本技能专注于检索最新一周（7-14天）内各行业（金融/医疗/自动驾驶/制造业/互联网/AI推理/AI训练）的AI应用算力需求变化，进行深度对比分析，生成结构化的HTML周报报告。报告为某完整智算报告的第七章（应用场景分析），因此所有章节编号均从7-1、7-2开始。
metadata:
  clawdbot:
    emoji: 🎯
    requires:
      anyBins:
        - python3
---

# 中国智算应用场景分析周更报告技能

## 核心定位

本技能生成**完整报告第七章的应用场景周报**，章节序号从 **7-1-、7-2、7-3…** 开始。

---

## ⚠️ 文件写入策略（必须遵守）

**模型输出流截断阈值约1027字符**，超过后工具调用参数不完整。**禁止直接生成大段HTML作为write参数**，会因截断导致文件不完整。

**必须采用两阶段模式：**
```
子agent步骤：
  1. write → /tmp/report_args.json（数据JSON，小文件<10KB，不会截断）
  2. write → /tmp/content_7_1.html 等（HTML片段，每个2-3KB，不会截断）
  3. exec → python3 scripts/generate_weekly_report.py（读取小文件→脚本生成完整HTML）
  4. 验证输出文件 > 20KB
```

**核心规则：** 写文件的是Python脚本，不是模型输出流。模型只负责写小文件+调用脚本。

**⚠️ 写入协议一致性（强制）：** 写文件方式必须与读文件方式匹配，否则会导致 `\"` 转义残留：
- **JSON数据文件**（如 `data_cards.json`）→ 用 `json.dump()` 写 + `json.load()` 读
- **HTML内容文件**（如 `content_7_3.html`）→ 用 `f.write()` 写纯文本 + `f.read()` 读
- **禁止**对HTML内容文件使用 `json.dump()` 写入，否则内容中的 `"` 会被转义为 `\"` 无法自动还原

---

**⚠️ 防御性清洗（硬约束，LRN-20260821-001）：**

1. **HTML 内容文件严禁使用 `json.dump()` 写入** —— 会导致真实换行 0x0A 被 JSON 规范转义为 `\n` 两字符（JSON 字符串内转义）；后续通过 `f.read()` 读取后传入脚本会注入转义符
2. **禁止用 `f.read()` 读取 JSON 文件作为 `--content_X` 参数** —— JSON 文件首尾自带外层引号（`"..."`），`f.read()` 会带入；脚本 `decode_arg` 已升级兜底
3. **HTML 内容写入前必须自检**：
   ```bash
   grep -c '\\n' /tmp/content_*.html  # 真实合法 \\n 数为 0（必须用 <br> 标签代替）
   head -c 1 /tmp/content_*.html | grep -c '"'  # 首字符不为 "（0 = 正确）
   ```
4. **脚本 `decode_arg` 防御性兜底**（已升级，LRN-20260821-001）：自动剥离首尾多余引号 + 把 `\n` 两字符还原为真实换行。即便 subagent 错误使用 `json.dump` 写入，依然不污染 HTML

## 模板文件

## 模板文件（最重要参考）

本技能目录下有 `templates/` 目录，保存两份关键模板：

| 文件 | 作用 |
|------|------|
| `templates/reference.html` | **最新已验证的真实报告**（47KB），所有CSS/布局的最终基准，任何新生成报告必须与此文件结构一致 |
| `templates/skeleton.html` | **生成脚本使用的骨架模板**，含 `{{PLACEHOLDER}}` 标记，脚本运行时替换这些标记生成最终HTML |

> ⚠️ **重要原则**：所有未来生成的HTML，CSS样式、class命名、HTML结构必须与 `reference.html` 完全一致。模板即标准，不得自行更改样式。

---

## 报告结构（章节编号从7-1开始）

```
七、应用场景分析（第X期）
├── 7-1 本周应用场景核心数据速览（含周环比变化表）
├── 7-2 一周应用场景动态综述（时间线）
├── 7-3 本周应用场景深度解读（1-2个专题）
├── 7-4 应用场景算力需求周变化分析
│   ├── 7-4-1 大模型训练场景
│   ├── 7-4-2 AI推理场景
│   ├── 7-4-3 金融行业场景
│   ├── 7-4-4 医疗行业场景
│   ├── 7-4-5 自动驾驶场景
│   ├── 7-4-6 制造业场景
│   └── 7-4-7 互联网行业场景
├── 7-5 应用场景趋势周变化对比分析（核心！含周变化表格）
├── 7-6 应用场景驱动因素周变化分析
├── 7-7 下周趋势预判
└── 7-8 一周要闻汇总表（含重要度星级标注）
```

---

## 完整工作流程

### 阶段1 — 信息检索

覆盖：最新应用场景动态（≤2周）、行业数据（≤1个月）、历史基线数据

### 阶段2 — 准备数据

按下面JSON格式准备数据，通过命令行参数传入脚本。

### 阶段3 — 调用生成脚本

```bash
python3 skills/china-computing-applications-weekly-report/scripts/generate_weekly_report.py \
  --date {REPORT_DATE} \
  --date_from {PERIOD_START} \
  --week_number {WEEK_NUMBER} \
  --overview_text "本周是AI应用从'堆量'向'提效'的结构性转变节点..." \
  --data_cards_json '[{"label":"...","value":"...","unit":"...","change":"..."},...]' \
  --data_table_json '[{"label":"...","time_dim":"周环比/月环比/季环比/年同比","prev":"上期数据（如5.80万亿Token（4/6-12））","curr":"本期数据","unit":"单位","change_str":"变化幅度HTML","analysis":"趋势分析"},...]' \
  --timeline_json '[{"date":"...","title":"...","source":"来源","impact":"影响说明"},...]' \
  --content_7_3 '<h3>专题一：...</h3><div class="deep-event">...</div>' \
  --content_7_4 '<h3>7-4-1 大模型训练场景</h3>...' \
  --content_7_5 '...' \
  --content_7_6 '...' \
  --content_7_7 '...' \
  --news_json '[{"date":"...","event":"...","subject":"...","scale":"...","importance":5},...]' \
  --sources_json '["来源1","来源2"]' \
  --output report/应用场景分析报告.html
```

#### data_table_json 字段说明（关键更新）

| 字段 | 说明 | 示例 |
|------|------|------|
| `label` | 指标名称 | `OpenRouter中国模型周调用量` |
| `time_dim` | **时间维度**（必填） | `周环比`、`日环比`、`月环比`、`季环比`、`年同比` |
| `prev` | 上期数据（含时间戳） | `5.80万亿Token（4/6-12）`、`27.2%（Q4 2025）` |
| `curr` | 本期数值（不含单位） | `4.44`、`30` |
| `unit` | 单位 | `万亿Token`、`%` |
| `change_str` | 变化幅度HTML | `<span class="change-up">↑ 23.8%</span>` |
| `analysis` | 趋势分析（原因说明） | `Claude系列拉动美国周调用量回升` |

#### data_cards change 字段格式

change字段需标注时间维度，格式：`时间戳 上期值 | ↑/↓ 幅度（时间维度）`

示例：`4/6-12 5.80万亿 | ↓23.8%（周变化）`、`Q4 2025 38.5% | ↑9.1%（年同比）`

**时间维度优先级（从高到低）：**
> **周环比 > 月环比 > 季环比 > 年同比**

周报以**本期所在的周期**为锚点，优先与**紧接的前一个同周期**进行对比：本周 vs 上周 > 本月 vs 上月 > 本季度 vs 上季度 > 今年 vs 去年。**年同比仅在无其他对比数据时才使用。**

**数据一致性原则：**
- change字段中的"上期值"必须与当前值来自**同一个数据源**
- 不得混用不同数据源（如季度数据源的当前值 + 周数据源的上期值）
- 若同一数据源的上期数据无法获取，change字段应**仅保留当前值，不编造不可比的上期数据**
- 上期值必须与当前值的时间粒度一致（周数据对周数据、季度数据对季度数据）

**错误示例（子agent常犯）：**
- `4/13-19 135亿美元 | ↑8.9%（季环比）` ← 4月中旬的周数据不是Q3季度数据，不可比
- `Q4 2025 147亿美元 | ↑26%（年同比）` ← 年同比对周报读者参考价值最低，不应在有其他数据时优先使用

**正确示例：**
- `Q3 2025 134亿美元 | ↑9.7%（季环比）` ← 同一数据源（Omdia）、同为季度粒度、紧邻前序周期

### 阶段4 — 验证输出

- 文件存在且 > 20KB
- 章节编号 7-1 ~ 7-8 全部存在
- 7-1周对比表有数据
- 7-3深度解读有≥1个完整专题
- 7-5趋势对比表有数据

---

## HTML/CSS规范（必须严格遵守）

所有生成的HTML必须与 `templates/reference.html` 完全一致，包括但不限于：

### CSS样式关键点
- header渐变：`linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)`
- data-card渐变：`linear-gradient(135deg, #667eea 0%, #764ba2 100%)`
- deep-event渐变：`linear-gradient(135deg, #667eea 0%, #764ba2 100%)`
- section h2：`font-size: 17px; color: #1a1a2e; border-bottom: 2px solid #0f3460`
- timeline圆点：`background: #0f3460`
- timeline-impact：`border-left: 3px solid #667eea; background: #f8f9fc`
- change-up：`color: #2e7d32`
- change-down：`color: #c62828`
- change-flat：`color: #888`
- 导航chapter-tabs：`display: flex; flex-wrap: wrap; gap: 4px 0; align-items: center; justify-content: center`
- 导航active态：`background: linear-gradient(135deg, #667eea 0%, #764ba2 100%)`
- chapter-overview：`background: #ffffff; border-radius: 12px; padding: 24px 32px; margin: 20px 16px`
- data-card `.value` 数字：`font-size: 22px; font-weight: 700`
- data-card `.label`：`font-size: 11px; opacity: 0.85`
- week-badge：`background: #e53935; font-size: 11px; padding: 3px 10px; border-radius: 10px`

### HTML结构关键点
- container：单一 `<div class="container">` 包裹所有内容，唯一 `</div><!-- end container -->`
- all-chapters-nav + chapter-tabs：横向排列8章导航
- chapter-overview：嵌在 all-chapters-nav 关闭标签之后、data-note 之前
- 导航关闭标签：chapter-tabs 先关闭，all-chapters-nav 再关闭
- data-cards：在 section 内部，table 之前
- 时间线每条：所有字段（date/title/source/impact）在一行内，无换行无缩进；**按日期降序排列（从新到旧）**
- 要闻汇总表：按日期降序排列（从新到旧）

---

## 应用场景知识库

### 核心场景数据基线

| 场景 | 算力规模 | 占比 | 年增速 | 延迟要求 |
|------|---------|------|-------|---------|
| 大模型训练 | ~1200亿元 | ~40% | 30% | 无 |
| AI推理 | ~1412亿元 | ~50%+ | 50%+ | <100ms |
| 金融AI | ~200亿元 | ~7% | 35% | <10ms |
| 医疗AI | ~150亿元 | ~5% | 40% | <3s |
| 自动驾驶 | ~180亿元 | ~6% | 45% | <20ms |
| 制造业AI | ~160亿元 | ~5.5% | 38% | <50ms |
| 互联网AI | ~800亿元 | ~28% | 42% | <3s |

---

## 信息检索规范

### 必检信源（每周固定检索）
- 各厂商AI应用落地最新公告
- 医学影像AI、质检AI、自动驾驶AI等垂直领域新闻
- 大模型日Token消耗数据（DeepSeek/豆包等）
- IDC中国、艾瑞咨询、赛迪顾问报告

### 核心检索词
```
"AI应用场景 算力需求 {CURRENT_YEAR}年{CURRENT_MONTH}"
"DeepSeek 豆包 Token消耗 最新"
"金融AI 智能风控 量化交易 最新动态"
"医疗AI AI辅助诊断 药物研发 最新"
"自动驾驶 L4 L5 最新进展 2026"
"智能质检 制造业AI 边缘算力 最新"
"AI推理算力 边缘算力 占比 最新"
"大模型训练 推理算力 规模变化"
```

---

## 关键规则

1. **章节编号：** 所有章节标题从 7-1、7-2… 开始
2. **数据必须标注来源**，无来源数据需注明"根据公开信息整理"
3. **变化类型标注：** ↑上涨（绿色）、↓下跌（红色）、→持平（灰色）
4. **时间维度标注（核心规则）：**
   - 表格列：**时间维度** = 日环比/周环比/月环比/季环比/年同比
   - 上期数据列：必须含具体时间戳，如 `5.80万亿Token（4/6-12）`、`27.2%（Q4 2025）`
   - 数据卡片change字段：格式为 `时间戳 上期值 | ↑/↓ 幅度（时间维度）`
   - 当多项数据时间维度不同时，禁止混用"上周""周环比"等不严谨措辞
5. **禁止空洞表述：** 所有分析段落必须>50字，有具体数据支撑
6. **报告期号：** 每期报告需有期号（如"第16期"）
7. **7-8一周要闻汇总表：** 必须包含≥5条本周要闻，重要度用★标注（1-5星）
8. **CSS一致性：** 生成的HTML必须与 `templates/reference.html` 完全一致，禁止自行修改任何CSS样式
9. **skeleton.html表头结构：** 7-5表格列名为"指标、时间维度、上期数据、本期数据、变化幅度、趋势分析"，不得使用"上周/本周/周环比"等不严谨列名
